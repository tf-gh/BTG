{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | Dividends functionality.
module Lorentz.Contracts.BTG.Dividends
  ( module Exports
  ) where

import Lorentz.Contracts.BTG.Dividends.Impl as Exports
