{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | Token API for shares management.
module Lorentz.Contracts.BTG.Token
  ( module Exports
  ) where

import Lorentz.Contracts.BTG.Token.Impl as Exports
