{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | Whitelist implementation.
module Lorentz.Contracts.BTG.Whitelist.Impl
  ( Submap
  , mkSubmap

  , StorageC
  , Deps (..)

    -- * Entrypoints implementation
  , addToWhitelist
  , removeFromWhitelist
  , checkWhitelisted
  , addToWhitelistBatch
  , removeFromWhitelistBatch

    -- * Internal functions
  , ensureWhitelisted
  ) where

import Lorentz

import Lorentz.Contracts.BTG.Common
import Lorentz.Contracts.BTG.Whitelist.Doc
import Lorentz.Contracts.BTG.Whitelist.Types

----------------------------------------------------------------------------
-- Entrypoints implementation
----------------------------------------------------------------------------

addToWhitelist
  :: forall store.
      StorageC store
  => Deps store -> Entrypoint Address store
addToWhitelist deps = do
  doc $ DDescription addToWhitelistDoc
  dip $ dAuthorizeAdmin deps
  dip $ unit
  stInsert #whitelist
  nil; pair

removeFromWhitelist
  :: forall store.
      StorageC store
  => Deps store -> Entrypoint Address store
removeFromWhitelist deps = do
  doc $ DDescription removeFromWhitelistDoc
  dip $ dAuthorizeAdmin deps
  stDelete #whitelist
  nil; pair

checkWhitelisted
  :: forall store. StorageC store => Entrypoint (Void_ Address Bool) store
checkWhitelisted = void_ $ do
  doc $ DDescription checkWhitelistedDoc
  stMem #whitelist

addToWhitelistBatch
  :: forall store.
      StorageC store
  => Deps store -> Entrypoint (List Address) store
addToWhitelistBatch deps = do
  doc $ DDescription addToWhitelistBatchDoc
  dip $ dAuthorizeAdmin deps
  -- add all elements from list to Set
  iter (do
    dip $ unit
    stInsert #whitelist
    )
  nil; pair

removeFromWhitelistBatch
  :: forall store.
      StorageC store
  => Deps store -> Entrypoint (List Address) store
removeFromWhitelistBatch deps = do
  doc $ DDescription removeFromWhitelistBatchDoc
  dip $ dAuthorizeAdmin deps
  -- remove all elements of list from Set
  dip $ nil @ Address
  stackType @[List Address, List Address, store]
  iter (do
    stackType @[Address, List Address, store]
    swap
    dip (do
      dup
      dip $ dip $ dup
      stackType @[Address, Address, store, store]
      dip $ stMem #whitelist)
    stackType @[List Address, Address, Bool, store]
    dip swap; swap
    stackType @[Bool, List Address, Address, store]
    if_
      (dip $ stDelete #whitelist)
      (do swap; cons)
    stackType @[List Address, store]
    )
  ifCons (do cons
             nil; swap; iter cons -- revert the list
             failCustom #notWhitelisted)
         nop
  nil; pair

----------------------------------------------------------------------------
-- Helpers
----------------------------------------------------------------------------

ensureWhitelisted ::
  forall store s.
  StorageC store
  => Text
  -> Address : store : s :-> store : s
ensureWhitelisted requredToBeWhitelisted = do
  doc $ DWhitelisted requredToBeWhitelisted
  dip dup
  dup
  stackType @(Address : Address : store : store : s)
  dip $ stMem #whitelist
  stackType @(Address : Bool : store : s)
  swap
  if_ drop (do dip nil; cons; failCustom #notWhitelisted)
