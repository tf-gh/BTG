{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}

{-# OPTIONS_GHC -Wno-orphans #-}

module Lorentz.Contracts.BTG.Whitelist.Types
  ( Submap
  , mkSubmap

  , StorageC

  , Deps (..)
  ) where

import Lorentz
import Prelude (fmap)

import qualified Data.Map.Strict as Map
import Fmt (Buildable(..), listF, (+|), (|+))

----------------------------------------------------------------------------
-- Storage
----------------------------------------------------------------------------

-- | Submap of the main contract's storage.
type Submap = BigMap Address ()

mkSubmap :: [Address] -> Submap
mkSubmap = BigMap . Map.fromList . fmap toWhitelistEntry
  where
    toWhitelistEntry addr = (addr, ())

type StorageC storage =
  StorageContains storage
   '[ "whitelist" := Address ~> ()
    ]


----------------------------------------------------------------------------
-- Deps
----------------------------------------------------------------------------

data Deps storage = Deps
  { dAuthorizeAdmin
      :: forall s. storage : s :-> storage : s
  }

----------------------------------------------------------------------------
-- Errors
----------------------------------------------------------------------------

type instance ErrorArg "notWhitelisted" = [Address]

instance Buildable (CustomError "notWhitelisted") where
  build (CustomError _ addrs) =
    "Wallets not on whitelist " +|
    listF addrs |+ ""

instance (CustomErrorHasDoc "notWhitelisted") where
  customErrClass = ErrClassActionException

  customErrDocMdCause =
    "One or more supplied wallets are not whitelisted"

  customErrArgumentSemantics =
    Just "wallets found to be non whitelisted"
