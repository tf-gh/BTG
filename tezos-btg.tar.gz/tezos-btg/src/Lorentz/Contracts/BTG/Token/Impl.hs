{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | Token implementation.
module Lorentz.Contracts.BTG.Token.Impl
  ( StorageFields (..)
  , mkStorageFields
  , Submap
  , mkSubmap

  , StorageC
  , Deps (..)

    -- * Entrypoints implementation
  , transfer
  , approve
  , getAllowance
  , getBalance
  , getTotalSupply
  , setPause
  , getPaused
  , setAdministrator
  , getAdministrator
  , mint
  , mintBatch
  , burn

    -- * Internal functions
  , authorizeAdmin
  , creditTo
  , checkPause
  , getBalanceInternal
  , getTotalSupplyInternal
  ) where

import Lorentz

import Lorentz.Contracts.BTG.Common
import Lorentz.Contracts.BTG.Token.Doc
import Lorentz.Contracts.BTG.Token.Primitives
import Lorentz.Contracts.BTG.Token.Types
import qualified Lorentz.Contracts.ManagedLedger.Impl as ML

{-# ANN mint ("HLint: ignore Reduce duplication" :: Text) #-}
{-# ANN mintBatch ("HLint: ignore Reduce duplication" :: Text) #-}
----------------------------------------------------------------------------
-- Entrypoints implementation
----------------------------------------------------------------------------

-- | This is a slightly more general version of 'transfer' which is
-- needed to implement 'transferViaProxy'. It does not use 'sender'.
transfer
  :: forall store. StorageC store
  => Deps store -> Entrypoint TransferParams store
transfer Deps{..} = do
  dup; dip $ do
    dup; dip $ toField #to >> dEnsureWhitelisted "to"
    dup; dip $ toField #from >> dEnsureWhitelisted "from"
    dup; dip $ toField #to >> dUpdateAccount
    toField #from >> dUpdateAccount
  ML.transfer

-- | This is a slightly more general version of 'approve' which is
-- needed to implement 'approveViaProxy'. It does not use 'sender'.
approve
  :: forall store. StorageC store
  => Deps store -> Entrypoint ApproveParams store
approve Deps{..} = do
  dip $ sender >> dEnsureWhitelisted "sender"
  dup; dip $ toField #spender >> dEnsureWhitelisted "spender"
  ML.approve

getAllowance
  :: StorageC store
  => Entrypoint (View GetAllowanceParams Natural) store
getAllowance = ML.getAllowance

getBalance :: StorageC store => Entrypoint (View GetBalanceParams Natural) store
getBalance = ML.getBalance

getTotalSupply :: StorageC store => Entrypoint (View () Natural) store
getTotalSupply = ML.getTotalSupply

setPause :: StorageC store => Entrypoint Bool store
setPause = ML.setPause

getPaused :: StorageC store => Entrypoint (Void_ () Bool) store
getPaused = void_ $ do
  doc $ DDescription pausedDoc
  drop @()
  stGetField #paused

setAdministrator :: forall store. StorageC store => Entrypoint Address store
setAdministrator = ML.setAdministrator

getAdministrator :: StorageC store => Entrypoint (View () Address) store
getAdministrator = ML.getAdministrator

mint :: StorageC store => Deps store -> Entrypoint MintParams store
mint Deps{..} = do
  -- Duplicating call of 'authorizeAdmin' because this thing apparently
  -- should be checked first (there is one another call in 'ML.mint').
  dip (authorizeAdmin >> ML.ensureNotPaused)
  dup; dip (toField #to >> dEnsureWhitelisted "to")
  dup; dip (toField #to >> dUpdateAccount)
  ML.mint

mintBatch
  :: forall store. StorageC store => Deps store -> Entrypoint [MintParams] store
mintBatch Deps{..} = do
  doc $ DDescription mintBatchDoc
  dip authorizeAdmin

  iter $ do
    dup; dip (toField #to >> dEnsureWhitelisted "all accounts from list")
    dup; dip (toField #to >> dUpdateAccount)

    ML.creditTo
    drop
  nil; pair

burn :: StorageC store => Deps store -> Entrypoint BurnParams store
burn deps = do
  dip (authorizeAdmin >> ML.ensureNotPaused)
  dup; dip (toField #from >> dUpdateAccount deps)
  ML.burn

----------------------------------------------------------------------------
-- Helpers
----------------------------------------------------------------------------

authorizeAdmin ::
  StorageC store => store : s :-> store : s
authorizeAdmin = ML.authorizeAdmin

creditTo
  :: ( param `HasFieldsOfType` ["to" := Address, "value" := Natural]
     , StorageC store
     )
  => '[param, store] :-> '[param, store]
creditTo = ML.creditTo

checkPause :: StorageC store => Bool -> store : s :-> store : s
checkPause False = ML.ensureNotPaused
checkPause True = do
  stGetField #paused
  if_ nop (failCustom_ #tokenOperationsAreNotPaused)

getBalanceInternal
  :: StorageC store
  => Address : store : s :-> Natural : s
getBalanceInternal = do
  stGet #ledger
  ifSome (toField #balance) (push 0)

getTotalSupplyInternal
  :: StorageC store
  => store : s :-> Natural : s
getTotalSupplyInternal = stToField #totalSupply
