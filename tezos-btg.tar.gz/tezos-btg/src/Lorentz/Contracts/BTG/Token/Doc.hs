{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}

module Lorentz.Contracts.BTG.Token.Doc
  ( pausedDoc
  , mintBatchDoc
  ) where

import Lorentz

import Text.InterpolatedString.QM (qnb)

-- import Util.Markdown

pausedDoc :: Markdown
pausedDoc = [qnb|
  Returns paused state as `Void`.
  |]

mintBatchDoc :: Markdown
mintBatchDoc = [qnb|
  Produces tokens on every account assosiated with given address in list.
  |]
