{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}

module Lorentz.Contracts.BTG.Doc
  ( btgTokenContractDoc
  , btgRepoSettings
  ) where

import Lorentz

import Text.InterpolatedString.QM (qnb)

btgTokenContractDoc :: Markdown
btgTokenContractDoc = [qnb|
  The main feature of the token is an efficient implementation of dividend payments. An efficient
  implementation means that the dividend payment is split into several steps and it uses
  computation amortization which helps to meet GAS requirements. Amortization of computations looks
  like this: distribution of a new portion of dividends doesn't update a state associated with of
  each account right away. Instead, it updates only some state common for all account. Dividends
  for each account are computed only by an explicit request to withdraw dividends or when the
  amount of shares for the account should be changed.\


  The typical usage of the contract to distribute dividends:
  1. send the desired amount of XTZ to the contract
  2. call `addDividends` method
  3. call `disburse` or `withdraw` to send XTZ to the requested accounts.
  |]

btgRepoSettings :: GitRepoSettings
btgRepoSettings = GitRepoSettings $ \commit ->
  "https://github.com/serokell/tezos-btg/commit/" <> commit
