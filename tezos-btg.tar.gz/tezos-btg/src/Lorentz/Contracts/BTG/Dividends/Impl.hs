{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | Dividends implementation.
module Lorentz.Contracts.BTG.Dividends.Impl
  ( StorageFields (..)
  , mkStorageFields
  , Submaps (..)
  , mkSubmaps

  , StorageC
  , Deps (..)

  -- * Entrypoints implementation
  , disburse
  , withdraw
  , collect
  , dividendsOwing
  , addDividends

  -- * Internal functions
  , updateAccount
  , updateAccountLogic
  , disburseOneLogic
  ) where

import Lorentz

import Lorentz.Contracts.BTG.Common
import Lorentz.Contracts.BTG.Dividends.Types
import Lorentz.Contracts.BTG.Dividends.Doc

-- The constant needs a good balance of being big enough but not so much to prevent extra gas
-- consumption.
precisionMult :: Natural
precisionMult = 16777216 -- 2^24

----------------------------------------------------------------------------
-- Entrypoints
----------------------------------------------------------------------------

-- | Distribute pending dividends between the given list of shareholders
--
-- Can be called:
--
-- * only by the admin
--
-- Can fail if the contract has less money than the requested payment (this situation is possible
-- after a call of the 'collect' method).
--
-- Skips sending 0tz transactions.
disburse
  :: forall store.
      StorageC store
  => Deps store -> Entrypoint [Address] store
disburse deps = do
  let updateAllAccounts :: [[Address],  store] :-> [[Address], store]
      updateAllAccounts = do
        dip $ (dup >> loadStoredCode (updateAccountLogic deps) >> swap)
        stackType @[[Address], store, (Lambda (Address, store) store)]
        dup; dip $ do
          iter $ do
            pair
            dip dup
            exec
            stackType @[store, (Lambda (Address, store) store)]
          dip (drop @(Lambda (Address, store) store))

  let loadDisburseOne :: [[Address], store] :-> [[Address], store, Lambda (Address, store) (Maybe Operation, store)]
      loadDisburseOne =
        dip $ do
          dup
          loadStoredCode disburseOneLogic
          swap

  let callDisburseOne :: [Address, store, Lambda (Address, store) (Maybe Operation, store)]
                      :-> [Maybe Operation, store, Lambda (Address, store) (Maybe Operation, store)]
      callDisburseOne = do
        pair
        dip dup
        exec
        unpair

  doc $ DDescription disburseDoc
  dip $ dAuthorizeAdmin deps

  -- GAS consumption is minimized by moving loading and deserializing of stored code out of loops.
  updateAllAccounts
  loadDisburseOne

  dip (nil @Operation)
  iter $ do
    stackType @[Address, List Operation, store, Lambda _ _]
    swap
    dip callDisburseOne

    stackType @[List Operation, Maybe Operation, store, Lambda _ _]
    swap
    ifSome cons nop

  pair
  dip (drop @(Lambda _ _))

addressToContract  :: forall s . (Address ': s) :-> (ContractAddr () ': s)
addressToContract = do
  dup
  contract @()
  ifSome
    (swap >> drop @Address)
    (do stackType @(Address ': s)
        failCustom #notAUnitContract)

disburseOneLogic
  :: forall store.
      StorageC store
  => StoredCode "disb1" (Address, store) (Maybe Operation, store)
disburseOneLogic = StoredCode $ do
    unpair
    dup; dip $ do
      takeAndDiscardUnpayedBalance
    dip $ do
      dup; dip updateUnclaimendDividends
    swap; dup
    push @Natural 0
    if IsEq
      then drop >> drop >> none
      else do
        natToMutez
        dip addressToContract
        unit; transferTokens
        some
    pair
  where
    takeAndDiscardUnpayedBalance :: forall w. Address ': store ': w :-> Natural ': store ': w
    takeAndDiscardUnpayedBalance = do
      dip dup
      dup; dip $ do
        stGet #pendingPayment
        ifSome nop (push 0)
      stackType @(Address ': Natural ': store : w)
      swap; dip $ do
        push 0
        some
        swap
        stUpdate #pendingPayment

    updateUnclaimendDividends :: forall w . (Natural ': store ': w) :-> (store ': w)
    updateUnclaimendDividends = do
      dip (stGetField #totalUnclaimedDividends)
      swap; sub; isNat; assertSome [mt|totalUnclaimedDividends is negative|]
      stSetField #totalUnclaimedDividends

disburseOne
  :: forall store s.
      StorageC store
  => Address ': store ': s :-> Maybe Operation ': store ': s
disburseOne = do
  dip dup; pair
  callStoredCode disburseOneLogic
  unpair

-- | Similar to the 'disburse' method but only for one account
--
-- Skips sending 0tz transaction.
withdraw
  :: forall store.
      StorageC store
  => Deps store -> Entrypoint () store
withdraw deps = do
  doc $ DDescription withdrawDoc
  drop @()
  sender
  dup; dip $ updateAccount deps
  disburseOne
  ifSome (nil >> swap >> cons) nil
  pair

-- | Send all funds owned by the contract to the admin
--
-- Can be called only by the admin
collect
  :: forall store.
     Deps store -> Entrypoint () store
collect deps = do
  doc $ DDescription collectDoc
  drop @()
  dAuthorizeAdmin deps
  sender; addressToContract
  balance
  unit
  transferTokens
  nil; swap; cons
  pair

-- | Amount of pending dividends owed to the given account
dividendsOwing
  :: forall store.
      StorageC store
  => Deps store
  -> Entrypoint (Void_ Address Natural) store
dividendsOwing deps = void_ $ do
  doc $ DDescription dividendsOwingDoc
  dividendsOwing' deps
  dip drop

lazyPendingDividends
  :: forall store s.
      StorageC store
  => Deps store
  -> (Address ': store ': s) :-> (Natural ': store ': s)
lazyPendingDividends deps = do
    dup; dip computeNewDp
    swap; dip (dip dup >> dGetBalance deps)
    mul
    push precisionMult; swap
    ediv; ifSome car (failUnexpected [mt|Negative precisionMult|])
  where
    computeNewDp :: forall w . (Address ': store ': w) :-> (Natural ': store ': w)
    computeNewDp = do
      dip dup
      stGet #lastDividendPoints; ifSome nop (push 0)
      dip $ stGetField #totalDividendPoints
      swap
      sub; isNat; ifSome nop (failUnexpected [mt|Negative new dividend points|])

dividendsOwing'
  :: forall store s.
      StorageC store
  => Deps store
  -> (Address ': store ': s) :-> (Natural ': store ': s)
dividendsOwing' deps = do
  dip dup
  dup; dip $ do
    stGet #pendingPayment
    ifSome nop (push 0)
  swap
  dip $ lazyPendingDividends deps
  add

-- | Update account is an internal method which forces computation of lazy dividends
--
-- There are two "types" of pending dividends:
--
-- * "lazy computation" using math like @(totalDividendPoints - lastDividendPoints) * accountShares@
-- * "saved value" in the 'pendingPayment' field for each account.
--
-- 'updateAccount' computes "lazy dividends" and adds that value to the "saved value" (i.e.
-- 'pendingDividends'). So that after the call amount of "lazy dividends" is zero and hence the
-- amount of shares owned by the account can be safely changed.
updateAccountLogic
  :: forall store.
      StorageC store
  => Deps store
  -> StoredCode "updAcc" (Address, store) store
updateAccountLogic deps = StoredCode $ do
    unpair
    dup
    dip $ lazyPendingDividends deps
    stackType @(Address ': Natural ': store ': _)
    swap; dup; push 0; ifEq
      (drop @Natural >> drop @Address)
      (do swap
          dup; dip (swap >> updatePendingPayment)
          updateLastDp)
  where
    updateLastDp :: forall w . (Address ': store ': w) :-> (store ': w)
    updateLastDp = do
      dip $ do stGetField #totalDividendPoints; some
      stUpdate #lastDividendPoints

    updatePendingPayment :: forall w . (Natural ': Address ': store ': w) :-> (store ': w)
    updatePendingPayment = do
      duupX @2
      stackType @(Address ': Natural ': Address ': store ': w)
      dip (dip $ do
              dip (dup);
              stGet #pendingPayment;
              ifSome nop (push 0))
      stackType @(Address ': Natural ': Natural ': store ': w)
      dip $ add >> some
      stUpdate #pendingPayment

updateAccount
  :: forall store s.
      (StorageC store)
  => Deps store -> (Address ': store ': s) :-> (store ': s)
updateAccount deps = do
  dip dup; pair
  callStoredCode (updateAccountLogic deps)

natToMutez :: Natural ': s :-> Mutez ': s
natToMutez = do
  push (toMutez 1)
  mul

mutezToNat :: Mutez ': s :-> Natural ': s
mutezToNat = do
  push (toMutez 1)
  swap
  ediv
  assertSome [mt|impossible|]
  car

-- | Register a new portion of dividends
--
-- Can be called only by the admin.
--
-- Amount of new dividends is computed as a difference of 'unclaimedDividends' and the current
-- balance of the contract. That means that if there were no 'collect' calls, then each call of
-- 'addDividends' will register XTZ received by the contract since the last 'addDividends' call.
-- However, if there were a 'collect' call, 'addDividends' calls will do nothing until the balance
-- of the contract becomes larger than the saved 'unclaimedDividends' value.
addDividends
  :: forall store.
      StorageC store
  => Deps store -> Entrypoint () store
addDividends Deps{..} = do
  doc $ DDescription addDividendsDoc
  dip (dAuthorizeAdmin >> dCheckPause True)
  drop @()
  getNewDividends
  isNat; ifSome
    (do dup; dip updateTotalDP
        updateUnclaimendDividends)
    nop
  nil; pair
  where
    getNewDividends :: forall w . (store ': w) :-> (Integer ': store ': w)
    getNewDividends = do
      stGetField #totalUnclaimedDividends
      balance;
      mutezToNat
      sub

    updateTotalDP :: forall w . (Natural ': store ': w) :-> (store ': w)
    updateTotalDP = do
      push precisionMult; mul
      dip (dup >> dGetTotalSupply)
      ediv; ifSome car (failUnexpected [mt|Zero totalSupply of shares|])
      dip (stGetField #totalDividendPoints)
      add
      stSetField #totalDividendPoints

    updateUnclaimendDividends :: forall w . (Natural ': store ': w) :-> (store ': w)
    updateUnclaimendDividends = do
      dip (stGetField #totalUnclaimedDividends)
      add
      stSetField #totalUnclaimedDividends
