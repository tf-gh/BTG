{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}

{-# OPTIONS_GHC -Wno-orphans #-}

module Lorentz.Contracts.BTG.Dividends.Types
  ( StorageFields (..)
  , mkStorageFields
  , Submaps (..)
  , mkSubmaps

  , StorageC

  , Deps (..)
  ) where

import Lorentz

import Fmt (Buildable(..), (+|), (|+))

----------------------------------------------------------------------------
-- Storage
----------------------------------------------------------------------------

data StorageFields = StorageFields
  { sTotalDividendPoints :: Natural
  , sTotalUnclaimedDividends  :: Natural
  } deriving stock Generic
    deriving anyclass IsoValue

instance (field ~ Natural) =>
         StoreHasField StorageFields "totalDividendPoints" field where
  storeFieldOps = storeFieldOpsReferTo #sTotalDividendPoints storeFieldOpsADT

instance (field ~ Natural) =>
         StoreHasField StorageFields "totalUnclaimedDividends" field where
  storeFieldOps = storeFieldOpsReferTo #sTotalUnclaimedDividends storeFieldOpsADT

mkStorageFields :: StorageFields
mkStorageFields = StorageFields
  { sTotalDividendPoints = 0
  , sTotalUnclaimedDividends = 0
  }

data Submaps = Submaps
  { sLastDividendPoints :: BigMap Address Natural
  , sPendingPayment :: BigMap Address Natural
  } deriving stock Generic
    deriving anyclass IsoValue

mkSubmaps :: Submaps
mkSubmaps = Submaps mempty mempty

instance (key ~ Address, value ~ Natural) =>
  StoreHasSubmap Submaps "lastDividendPoints" key value where
  storeSubmapOps = storeSubmapOpsTopLevelStorage #sLastDividendPoints

instance (key ~ Address, value ~ Natural) =>
  StoreHasSubmap Submaps "pendingPayment" key value where
  storeSubmapOps = storeSubmapOpsTopLevelStorage #sPendingPayment

type StorageC store =
  ( KnownValue store
  , StorageContains store
      [ "totalDividendPoints" := Natural
      , "totalUnclaimedDividends" := Natural
      , "lastDividendPoints" := Address ~> Natural
      , "pendingPayment" := Address ~> Natural
      , "entrypoints" := MText ~> ByteString
      ]
  )


----------------------------------------------------------------------------
-- Deps
----------------------------------------------------------------------------

data Deps storage = Deps
  { dAuthorizeAdmin
      :: forall s. storage : s :-> storage : s
  , dGetBalance
      :: forall s. Address : storage : s :-> Natural : s
  , dGetTotalSupply
      :: forall s. storage : s :-> Natural : s
  , dCreditTo
      :: forall param.
         (param `HasFieldsOfType` ["to" := Address, "value" := Natural]) =>
         [param, storage] :-> [param, storage]
  , dCheckPause
      :: forall s. Bool -> storage : s :-> storage : s
  , dEnsureWhitelisted
      :: forall s. Text -> Address : storage : s :-> storage : s
  }

----------------------------------------------------------------------------
-- Errors
----------------------------------------------------------------------------

type instance ErrorArg "notAUnitContract" = Address

instance Buildable (CustomError "notAUnitContract") where
  build (CustomError _ addr) =
    "Cannot convert " +| addr |+ " to contract Unit"

instance (CustomErrorHasDoc "notAUnitContract") where
  customErrClass = ErrClassBadArgument

  customErrDocMdCause =
    "Supplied address is not a `contract ()`"

  customErrArgumentSemantics =
    Just "contract address"
