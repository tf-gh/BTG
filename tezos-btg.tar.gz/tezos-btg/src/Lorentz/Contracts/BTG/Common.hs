{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}

-- | Common primitives used in BTG implementation.

module Lorentz.Contracts.BTG.Common
  ( -- * General
    Entrypoint

    -- * Storing code
  , StoredCode (..)
  , loadStoredCode
  , callStoredCode
  , storedCodeToPair
  ) where

import Lorentz

import GHC.TypeLits (Symbol, KnownSymbol)

import Michelson.Interpret.Pack
import Michelson.Text

----------------------------------------------------------------------------
-- General
----------------------------------------------------------------------------

type Entrypoint param store = '[ param, store ] :-> ContractOut store

----------------------------------------------------------------------------
-- Storing code
----------------------------------------------------------------------------

-- | A piece of code to be fetched from storage.
--
-- This code is not supposed to be included directly at call site rather
-- be put in storage on contract initialization and then fetched from storage
-- on demand. This allows decreasing the overall contract size and makes sense
-- when given code is used often and the contract does not fit into operation
-- size limit.
--
-- Note that calling stored code is not fully free, very small pieces of code
-- are cheaper to include as is.
newtype StoredCode (name :: Symbol) inp out =
  StoredCode { unStoredCode :: Lambda inp out }

-- | Call the code kept in storage.
loadStoredCode
  :: forall name inp out store s.
     ( StoreHasSubmap store "entrypoints" MText ByteString
     , KnownSymbol name, KnownValue inp, KnownValue out
     )
  => (StoredCode name inp out) -> store : s :-> Lambda inp out : s
loadStoredCode code = do
  inheritDocs code
  -- Note: further using internal errors here because they are impossible when
  -- contract is initialized correctly.
  -- Also, keeping messages short, as this function is supposed to be used
  -- often due to its purpose.
  push name
  stGet #entrypoints
  assertSome (name <> [mt| EP not init|])
  unpack @(Lambda inp out)
  assertSome ([mt|Bad EP type: |] <> name)
  where
    name = symbolToMText @name
    inheritDocs = cutLorentzNonDoc . unStoredCode

-- | Call the code kept in storage.
callStoredCode
  :: forall name inp out store s.
     ( StoreHasSubmap store "entrypoints" MText ByteString
     , KnownSymbol name, KnownValue inp, KnownValue out
     )
  => (StoredCode name inp out) -> inp : store : s :-> out : s
callStoredCode code = do
  dip (loadStoredCode code)
  exec

-- | Turn stored code into a pair that can be put to storage.
storedCodeToPair
  :: forall name inp out.
     ( KnownSymbol name, KnownValue inp, KnownValue out
     )
  => StoredCode name inp out -> (MText, ByteString)
storedCodeToPair (StoredCode code) =
  (symbolToMText @name, packValue' (toVal code))
