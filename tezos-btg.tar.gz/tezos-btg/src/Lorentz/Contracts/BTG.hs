{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | BTG Token.
--
-- The main feature of the token is an efficient implementation of dividend payments. An efficient
-- implementation means that the dividend payment is split into several steps and it uses
-- computation amortization which helps to meet GAS requirements. Amortization of computations looks
-- like this: distribution of a new portion of dividends doesn't update a state associated with of
-- each account right away. Instead, it updates only some state common for all account. Dividends
-- for each account are computed only by an explicit request to withdraw dividends or when the
-- amount of shares for the account should be changed.
--
-- All formulas behind this implementation are described in [the document](./docs/dividends.pdf). In
-- short, 'addDividends' method accumulates @(newDividends / totalSupply)@ value in the
-- 'totalDividendPoints'. Increasing 'totalDividendPoints' means that all shareholders own some new
-- dividends. Amount of "unclaimed" or "pending" dividends is determined as new dividend points of
-- an account multiplied by its the amount of shares. 'lastDividendPoints' value associated with
-- each account allows keeping track of new dividends points (and hence, new pending dividends) for
-- each account.
--
-- The Token API is used to keep track of shares.
--
-- To change the amount of shares for an account the implementation should force computation of
-- pending dividends for that account. This is done internally by the 'updateAccount' method and all
-- methods which modify shares has appropriate 'updateAccount' calls in place. However,
-- 'updateAccount' doesn't send any transactions to pay money, instead, it accumulates the amount of
-- already computed but not yet paid dividends in the 'pendingPayment' mapping.
--
-- The typical usage of the contract to distribute dividends:
--
-- 1. send the desired amount of XTZ to the contract
-- 2. call @addDividends@ method
-- 3. call @disburse@ or @withdraw@ to send XTZ to the requested accounts.
module Lorentz.Contracts.BTG
  ( Parameter (..)

  , Storage (..)
  , mkStorage
  , btgTokenContract
  , btgTokenDocumentation

  , module Lorentz.Contracts.BTG.Primitives
  ) where

import Lorentz
import Prelude (LText)

import qualified Data.Map.Strict as Map
import Fmt (Buildable(..), listF, listF', tupleF, (+|), (|+))

import Lorentz.Macro (buildViewTuple)
import qualified Michelson.Doc as Doc
import Michelson.Optimizer (OptimizerConf(..))
import Util.Instances ()
import Util.Named ()

import Lorentz.Contracts.BTG.Common
import qualified Lorentz.Contracts.BTG.Dividends as Dividends
import Lorentz.Contracts.BTG.Doc
import Lorentz.Contracts.BTG.Primitives
import qualified Lorentz.Contracts.BTG.Token as Token
import qualified Lorentz.Contracts.BTG.Whitelist as Whitelist

{-# ANN module ("HLint: ignore Reduce duplication" :: Text) #-}

----------------------------------------------------------------------------
-- Parameter
----------------------------------------------------------------------------

data Parameter
    -- Token --
  = Transfer                 !TransferParams
  | Approve                  !ApproveParams
  | GetAllowance             !(View GetAllowanceParams Natural)
  | GetBalance               !(View GetBalanceParams Natural)
  | GetTotalSupply           !(View () Natural)
  | SetPause                 !Bool
  | GetPaused                !(Void_ () Bool)
  | SetAdministrator         !Address
  | GetAdministrator         !(View () Address)
  | Mint                     !MintParams
  | MintBatch                ![MintParams]
  | Burn                     !BurnParams
    -- Whitelist --
  | AddToWhitelist           !Address
  | RemoveFromWhitelist      !Address
  | CheckWhitelisted         !(Void_ Address Bool)
  | AddToWhitelistBatch      !(List Address)
  | RemoveFromWhitelistBatch !(List Address)
    -- Dividends --
  | Disburse                 ![Address]
  | Withdraw                 !()
  | Collect                  !()
  | AddDividends             !()
  deriving stock Generic
  deriving anyclass IsoValue

instance Buildable Parameter where
  build = \case
    Transfer params ->
      "Transfer " +| tupleF params |+ ""
    Approve params ->
      "Approve " +| tupleF params |+ ""
    GetAllowance view ->
      "GetAllowance " +| buildViewTuple view |+ ""
    GetBalance view ->
      "GetBalance " +| view |+ ""
    GetTotalSupply view ->
      "GetTotalSupply " +| view |+ ""
    SetPause bool ->
      "SetPause " +| bool |+ ""
    GetPaused _ ->
      "GetPaused"
    SetAdministrator addr ->
      "SetAdministrator " +| addr |+ ""
    GetAdministrator view ->
      "GetAdministrator " +| view |+ ""
    Mint params ->
      "Mint " +| tupleF params |+ ""
    MintBatch params ->
      "MintBatch " +| listF' tupleF params |+ ""
    Burn params ->
      "Burn " +| tupleF params |+ ""
    AddToWhitelist addr ->
      "AddToWitelist " +| addr |+ ""
    RemoveFromWhitelist addr ->
      "RemoveFromWhitelist " +| addr |+ ""
    CheckWhitelisted void ->
      "CheckWhitelisted " +| void |+ ""
    AddToWhitelistBatch lst ->
      "AddToWhitelistBatch " +| listF lst |+ ""
    RemoveFromWhitelistBatch lst ->
      "RemoveFromWhitelistBatch " +| listF lst |+ ""
    Disburse params ->
      "Disburse (#accounts :! " +| listF params |+ ")"
    Withdraw () ->
      "Withdraw ()"
    Collect () ->
      "Collect ()"
    AddDividends () ->
      "AddDividends ()"
----------------------------------------------------------------------------
-- Storage
----------------------------------------------------------------------------

data Storage = Storage
  {
    -- Storage maps
    smToken :: Token.Submap
  , smWhitelist :: Whitelist.Submap
  , smDividends :: Dividends.Submaps
  , smEntrypoints :: BigMap MText ByteString

    -- Storage fields
  , sfToken :: Token.StorageFields
  , sfDividends :: Dividends.StorageFields
  } deriving stock Generic
    deriving anyclass IsoValue

-- | Create a default storage with ability to set some balances to
-- non-zero values and whitelist some addresses.
mkStorage :: Address -> [(Address, Natural)] -> [Address] -> Storage
mkStorage adminAddress balances whitelist = Storage
  { smToken = Token.mkSubmap balances
  , smWhitelist = Whitelist.mkSubmap whitelist
  , smDividends = Dividends.mkSubmaps
  , smEntrypoints = BigMap . Map.fromList $
    [ storedCodeToPair (Dividends.updateAccountLogic dividendsDeps)
    , storedCodeToPair (Dividends.disburseOneLogic @Storage)
    ]

  , sfToken = Token.mkStorageFields adminAddress balances
  , sfDividends = Dividends.mkStorageFields
  }

-- Instances for submaps

instance (key ~ Address, value ~ LedgerValue) =>
  StoreHasSubmap Storage "ledger" key value where
  storeSubmapOps = storeSubmapOpsTopLevelStorage #smToken

instance (key ~ Address, value ~ ()) =>
  StoreHasSubmap Storage "whitelist" key value where
  storeSubmapOps = storeSubmapOpsTopLevelStorage #smWhitelist

instance  (key ~ Address, value ~ Natural) =>
  StoreHasSubmap Storage "lastDividendPoints" key value where
  storeSubmapOps = storeSubmapOpsTopLevelStorage #smDividends

instance  (key ~ Address, value ~ Natural) =>
  StoreHasSubmap Storage "pendingPayment" key value where
  storeSubmapOps = storeSubmapOpsTopLevelStorage #smDividends

instance {-# OVERLAPPING #-}
         (key ~ MText, value ~ ByteString) =>
         StoreHasSubmap Storage "entrypoints" key value where
  storeSubmapOps = storeSubmapOpsTopLevelStorage #smEntrypoints

-- Instances for fields

instance StoreHasField Token.StorageFields "admin" field =>
         StoreHasField Storage "admin" field where
  storeFieldOps = composeStoreFieldOps #sfToken storeFieldOpsADT storeFieldOps

instance StoreHasField Token.StorageFields "paused" field =>
         StoreHasField Storage "paused" field where
  storeFieldOps = composeStoreFieldOps #sfToken storeFieldOpsADT storeFieldOps

instance StoreHasField Token.StorageFields "totalSupply" field =>
         StoreHasField Storage "totalSupply" field where
  storeFieldOps = composeStoreFieldOps #sfToken storeFieldOpsADT storeFieldOps

instance StoreHasField Dividends.StorageFields "totalDividendPoints" field =>
         StoreHasField Storage "totalDividendPoints" field where
  storeFieldOps = composeStoreFieldOps #sfDividends storeFieldOpsADT storeFieldOps

instance StoreHasField Dividends.StorageFields "totalUnclaimedDividends" field =>
         StoreHasField Storage "totalUnclaimedDividends" field where
  storeFieldOps = composeStoreFieldOps #sfDividends storeFieldOpsADT storeFieldOps

----------------------------------------------------------------------------
-- Implementation
----------------------------------------------------------------------------

btgTokenContract :: Contract Parameter Storage
btgTokenContract =
  optimizeLorentzWithConf (def {gotoValues = True}) btgTokenContractRaw

btgTokenContractRaw :: Contract Parameter Storage
btgTokenContractRaw = contractName "BTG Token" $ do
  doc $ DDescription btgTokenContractDoc
  doc $ $mkDGitRevision btgRepoSettings
  unpair
  entryCase @Parameter (Proxy @PlainEntryPointsKind)
    ( #cTransfer /-> Token.transfer tokenDeps
    , #cApprove /-> Token.approve tokenDeps
    , #cGetAllowance /-> Token.getAllowance
    , #cGetBalance /-> Token.getBalance
    , #cGetTotalSupply /-> Token.getTotalSupply
    , #cSetPause /-> Token.setPause
    , #cGetPaused /-> Token.getPaused
    , #cSetAdministrator /-> Token.setAdministrator
    , #cGetAdministrator /-> Token.getAdministrator
    , #cMint /-> Token.mint tokenDeps
    , #cMintBatch /-> Token.mintBatch tokenDeps
    , #cBurn /-> Token.burn tokenDeps
    , #cAddToWhitelist /-> Whitelist.addToWhitelist whitelistDeps
    , #cRemoveFromWhitelist /-> Whitelist.removeFromWhitelist whitelistDeps
    , #cCheckWhitelisted /-> Whitelist.checkWhitelisted
    , #cAddToWhitelistBatch /-> Whitelist.addToWhitelistBatch whitelistDeps
    , #cRemoveFromWhitelistBatch /-> Whitelist.removeFromWhitelistBatch whitelistDeps
    , #cDisburse /-> Dividends.disburse dividendsDeps
    , #cWithdraw /-> Dividends.withdraw dividendsDeps
    , #cCollect /-> Dividends.collect dividendsDeps
    , #cAddDividends /-> Dividends.addDividends dividendsDeps
    )

----------------------------------------------------------------------------
-- Dependencies
----------------------------------------------------------------------------

whitelistDeps :: Whitelist.Deps Storage
whitelistDeps = Whitelist.Deps
  { Whitelist.dAuthorizeAdmin = Token.authorizeAdmin
  }

tokenDeps :: Token.Deps Storage
tokenDeps = Token.Deps
  { Token.dEnsureWhitelisted = Whitelist.ensureWhitelisted
  , Token.dUpdateAccount = Dividends.updateAccount dividendsDeps
  }

dividendsDeps :: Dividends.Deps Storage
dividendsDeps = Dividends.Deps
  { Dividends.dAuthorizeAdmin = Token.authorizeAdmin
  , Dividends.dGetBalance = Token.getBalanceInternal
  , Dividends.dGetTotalSupply = Token.getTotalSupplyInternal
  , Dividends.dCreditTo = Token.creditTo
  , Dividends.dCheckPause = Token.checkPause
  , Dividends.dEnsureWhitelisted = Whitelist.ensureWhitelisted
  }

----------------------------------------------------------------------------
-- Misc
----------------------------------------------------------------------------

instance ParameterEntryPoints Parameter where
  parameterEntryPoints = pepPlain

btgTokenDocumentation :: LText
btgTokenDocumentation =
  Doc.contractDocToMarkdown $ buildLorentzDoc btgTokenContract
