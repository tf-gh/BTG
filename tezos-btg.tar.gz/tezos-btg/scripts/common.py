# SPDX-FileCopyrightText: 2019 Tocqueville Group, 2019 BTG Pactual
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import os
import subprocess
import re
import sys

babylonnet_sh = "./babylonnet.sh"

babylonnet_client = [
    babylonnet_sh, "client", "-A", os.getenv('NODE', "jupiter.serokell.io"), "-P", os.getenv('NODE_PORT', "8732"),
    ]

def print_cmd(cmd):
    head = cmd[0]
    quoted_args = " ".join(f"'{x}'" for x in cmd[1:])
    print(f'{head} {quoted_args}')

def transfer(source, dest, param, burn_cap="20", amount="0", dry_run=False, capture_result=False):
    cmd = babylonnet_client + [
        "transfer", amount, "from", source, "to", dest,
        "--burn-cap", burn_cap, "--arg", param,
        ]
    print_cmd(cmd)
    if not dry_run:
        try:
            process = subprocess.run(cmd, check=True, capture_output=capture_result)
            if process.stdout is not None:
                output = process.stdout.decode("utf-8")
            if capture_result:
                consumed_gas = re.search("Estimated gas: (\d+)", output).group(1)
                storage_size = re.search("Estimated storage: ([\w\d]+) bytes", output).group(1)
                if storage_size == "no":
                    storage_size = "0"
                fee = re.search("Fee to the baker: ꜩ((\d|[.])+)", output).group(1)
                return {
                    "consumed_gas": int(consumed_gas),
                    "storage_size": int(storage_size),
                    "fee": float(fee)
                    }
        except subprocess.CalledProcessError as e:
            if e.output is not None:
                output = e.output.decode("unicode_escape")
            else:
                output = None
            red_color = "\033[1;31m"
            reset_color = "\033[0;0m"
            sys.stderr.write(f"{red_color}Transfer failed{reset_color}, babylonnet output:\n{output}")
            raise e

def get_balance_str(addr, dry_run=False):
    cmd = babylonnet_client + [
        "get", "balance", "for", addr
        ]
    if dry_run:
        print(cmd)
        return "0"
    else:
        print("> Retreiving the balance for {}".format(addr))
        res = subprocess.run(cmd, check=True, capture_output=True).stdout

        xs = res.split()
        idx = xs.index(b'\xea\x9c\xa9') # 'ꜩ'
        balance = xs[idx - 1]
        return str(balance, "utf-8")

def get_git_revision():
    process = subprocess.run(["git", "rev-parse", "--short", "HEAD"]
                            , check=True, capture_output=True)
    sha = process.stdout.decode("utf-8").strip()
    process = subprocess.run(["git", "rev-list", "--count", "HEAD"]
                            , check=True, capture_output=True)
    commits_count = process.stdout.decode("utf-8").strip()
    return commits_count + "_" + sha
