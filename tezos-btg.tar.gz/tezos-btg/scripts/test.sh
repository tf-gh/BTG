#!/usr/bin/env bash

# SPDX-FileCopyrightText: 2019 BTG Pactual
# SPDX-License-Identifier: LicenseRef-Proprietary

set -e

PYTHON=$(nix-shell --command "which python3")
ADMIN=tz1N7gkZuCcHSQ8kJxAyvx6aFsDM5nHphzYD
NODE=jupiter.serokell.io
NODE_PORT=8732
TEST_SCENARIO="gas-test-scenario"

# Parse arguments
POSITIONAL=()
while [[ $# -gt 0 ]]
do
    key="$1"

    case $key in
        --admin)
            ADMIN="$2"
            shift
            shift
            ;;
        --node)
            NODE="$2"
            shift
            shift
            ;;
        --port)
            NODE_PORT="$2"
            shift
            shift
            ;;
        --help)
            echo "Parameters and default values:"
            echo "  --admin tz1N7gkZuCcHSQ8kJxAyvx6aFsDM5nHphzYD :: an account with enough funds"
            echo "  --node jupiter.serokell.io"
            echo "  --port 8732"
            exit 0
            ;;
        --test-scenario)
            TEST_SCENARIO="$2"
            shift
            shift
            ;;
        *)
            printf "Unexpected argument $1"
            exit 1
            ;;
    esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters

echo "python: $PYTHON"
echo "admin: $ADMIN"
export NODE=$NODE
export NODE_PORT=$NODE_PORT

# Instantiate a new contract
CONTRACT=$($PYTHON ./scripts/deploy.py --admin $ADMIN | grep "New contract" | awk '{print $3}')
echo $CONTRACT

# Create a fresh set of accounts
./babylonnet.sh client -A $NODE -P $NODE_PORT gen keys acc1 --force
./babylonnet.sh client -A $NODE -P $NODE_PORT gen keys acc2 --force
./babylonnet.sh client -A $NODE -P $NODE_PORT gen keys acc3 --force
ADDRESSES=$(./babylonnet.sh client -A $NODE -P $NODE_PORT list known addresses | grep acc | awk '{print $2}')
echo $ADDRESSES

# Run the test
stack build

echo "=== run tests ==="
echo $PYTHON ./scripts/test.py --admin $ADMIN --contract $CONTRACT --test-scenario $TEST_SCENARIO --address $ADDRESSES
echo "==="
$PYTHON ./scripts/test.py --admin $ADMIN --contract $CONTRACT --test-scenario $TEST_SCENARIO --address $ADDRESSES
