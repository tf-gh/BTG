{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
module Main
  ( main
  ) where

import Prelude

import Control.Lens (ix)
import qualified Data.Text.Lazy.IO as TL
import Data.Version (showVersion)
import Fmt (Buildable, Builder, fmt, pretty, (+|), (|+))
import Options.Applicative (execParser, fullDesc, header, help, helper, info, infoOption, long)

import qualified Lorentz as L
import Michelson.Runtime.GState (genesisAddress2, genesisAddress3)
import Tezos.Address (Address(..), mkContractAddressRaw)
import Util.IO (hSetTranslit, writeFileUtf8)
import Util.Named ((.!))

import CLI.Parser (argParser)
import qualified CLI.Parser as P
import Lorentz.Contracts.BTG (btgTokenContract)
import qualified Lorentz.Contracts.BTG as B
import Paths_btg (version)

data TestCmd param =
  CmdContractCall Address param Text
  | CmdCheckBalance Address Text
  | CmdTransfer Address Address Text
  | CmdComment Text

type TestScenario param = [TestCmd param]

showTestScenario
  :: (Buildable param, L.NicePrintedValue param)
  => TestScenario param -> Text
showTestScenario = fmt . foldMap formatParam
  where
     formatParam
       :: (Buildable param, L.NicePrintedValue param)
       => TestCmd param -> Builder
     formatParam (CmdContractCall addr param amount) =
       "\n# " +| param |+ "\n" +|
       addr |+ " " +| amount |+ "\n" +|
       L.printLorentzValue True param |+ "\n"
     formatParam (CmdCheckBalance addr amount) = "check-balance " +| addr |+ " " +| amount |+ "\n"
     formatParam (CmdTransfer from to amount) = "transfer " +| from |+ " " +| to |+ " " +| amount |+ "\n"
     formatParam (CmdComment msg) = "\n### " +| msg |+ "\n"

main :: IO ()
main = do
  hSetTranslit stdout
  hSetTranslit stderr
  run `catchAny` (die . displayException)
  where
    run :: IO ()
    run = do
      cmd <- execParser programInfo
      case cmd of
        P.AddToWl addr -> printParam (B.AddToWhitelist addr)
        P.AddToWlBatch addrs -> printParam (B.AddToWhitelistBatch addrs)
        P.RemoveFromWl addr -> printParam (B.RemoveFromWhitelist addr)
        P.RemoveFromWlBatch addrs -> printParam (B.RemoveFromWhitelistBatch addrs)
        P.CheckWhitelisted addr -> printParam (B.CheckWhitelisted $ L.mkVoid addr)
        P.Transfer transferParam -> printParam (B.Transfer transferParam)
        P.Approve approveParam -> printParam (B.Approve approveParam)
        P.Contract mOut -> printContract mOut
        P.Document mOut ->
          let write = maybe putStrLn writeFileUtf8 mOut
          in write B.btgTokenDocumentation
        P.Storage adminAddr ->
          TL.putStrLn $
          L.printLorentzValue True $
            B.mkStorage adminAddr [] []
        P.ParseParam param -> TL.putStrLn $ pretty param
        P.TestScenario P.TestScenarioOptions {..} -> do
          let
            write = maybe putStrLn writeFileUtf8 tsoOutput
          maybe (die "Not enough addresses") write $
            showTestScenario <$> mkTestScenario tsoAdmin tsoContract tsoAddresses
        P.GasTestScenario P.GasTestScenarioOptions {..} -> do
          let
            write = maybe putStrLn writeFileUtf8 gtsoOutput
          maybe (die "Not enough addresses") write $
            showTestScenario <$> mkGasTestScenario gtsoAdmin gtsoAddresses

    printContract mOut = maybe putStrLn writeFileUtf8 mOut $
      L.printLorentzContract False btgTokenContract

    printParam = TL.putStrLn . L.printLorentzValue True


    programInfo =
      info (helper <*> versionOption <*> argParser) $
      mconcat
        [ fullDesc
        , header "BTG Token Tools"
        ]

    versionOption =
      infoOption
        ("btg-" <> showVersion version)
        (long "version" <> help "Show version")

call :: Address -> param -> TestCmd param
call a b = CmdContractCall a b "0"

call1000 :: Address -> param -> TestCmd param
call1000 a b = CmdContractCall a b "1000"

transfer :: Address -> Address -> Text -> TestCmd param
transfer a b c = CmdTransfer a b c

balance :: Address -> Text -> TestCmd param
balance a b = CmdCheckBalance a b

comment :: Text -> TestCmd param
comment a = CmdComment a

mkTestScenario :: Address -> Address -> [Address] -> Maybe (TestScenario B.Parameter)
mkTestScenario admin contract addresses = do
  addr1 <- addresses ^? ix 0
  addr2 <- addresses ^? ix 1
  addr3 <- addresses ^? ix 2
  pure
    [ comment "We require 3 empty accounts"
    , comment "Ensure all given addresses were empty and initiate them with some XTZ"
    , transfer admin addr1 "1"
    , transfer admin addr2 "1"
    , transfer admin addr3 "1"
    , balance addr1 "1"
    , balance addr2 "1"
    , balance addr3 "1"

    , comment "Dividends test"
    , call admin (B.AddToWhitelistBatch [addr1, addr2])
    , call admin (B.Mint (#to .! addr1, #value .! 4))
    , call admin (B.Mint (#to .! addr2, #value .! 6))
    , balance contract "0"
    , comment "Distribute 1000 dividends"
    , call1000 admin (B.SetPause True)
    , call admin (B.AddDividends ())
    , call admin (B.Disburse [addr1, addr2, addr3])
    , balance addr1 "401"
    , balance addr2 "601"
    , call admin (B.SetPause False)

    , comment "Whitelist test"
    , call admin (B.AddToWhitelist addr3)
    , call admin (B.Mint (#to .! addr3, #value .! 100500))
    , call admin (B.AddToWhitelistBatch [admin, genesisAddress2, genesisAddress3])
    , call addr3 (B.Transfer (#from addr3, #to .! genesisAddress3, #value .! 500))
    , call admin (B.RemoveFromWhitelistBatch [genesisAddress2])
    , call addr3 (B.Approve (#spender .! admin, #value .! 500))
    , call admin (B.Transfer (#from addr3, #to .! genesisAddress3, #value .! 400))

    , call admin (B.SetAdministrator addr3)
    , call addr3 (B.Burn (#from genesisAddress3, #value .! 20))
    , call addr3 (B.SetPause True)
    ]

mkGasTestScenario :: Address -> [Address] -> Maybe (TestScenario B.Parameter)
mkGasTestScenario admin addresses = do
  addr1 <- addresses ^? ix 0
  let addr2 = mkContractAddressRaw "-"
  let dummyAddrs = mkContractAddressRaw . show <$> [1 :: Int ..]
  pure
    [ comment "Test on gas consumption initiated"
    , comment "Ensure given address has some funds"
    , transfer admin addr1 "1"

    , comment "Whitelist modification"
    , call admin (B.AddToWhitelist addr1)
    , call admin (B.RemoveFromWhitelist addr1)

    , comment "Whitelist modification batched"
    , call admin (B.AddToWhitelistBatch [])
    , call admin (B.RemoveFromWhitelistBatch [])
    , call admin (B.AddToWhitelistBatch (take 1 dummyAddrs))
    , call admin (B.RemoveFromWhitelistBatch (take 1 dummyAddrs))
    , call admin (B.AddToWhitelistBatch (take 5 dummyAddrs))
    , call admin (B.RemoveFromWhitelistBatch (take 5 dummyAddrs))

    , comment "Prerequisites for further testing"
    , call admin (B.AddToWhitelistBatch [addr1, addr2])

    , comment "Token operations"
    , call admin (B.Mint (#to .! addr1, #value 100))
    , call admin (B.Burn (#from .! addr1, #value 5))
    , call addr1 (B.Transfer (#from .! addr1, #to .! addr2, #value 10))

    , comment "Token operations batched"
    , call admin (B.MintBatch [])
    , call admin (B.MintBatch $ replicate 5 (#to .! addr2, #value .! 1))

    , comment "Dividends operations"
    , call1000 admin $ B.MintBatch [(#to .! addr1, #value .! 1000)]
    , call admin $ B.AddDividends ()
    , call addr1 $ B.Withdraw ()
    , call admin $ B.Collect ()
    ]
