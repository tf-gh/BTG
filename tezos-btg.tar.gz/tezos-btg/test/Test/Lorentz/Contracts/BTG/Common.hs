{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | Common stuff for BTG tests.

module Test.Lorentz.Contracts.BTG.Common
  ( -- * Utilities
    NiceParameter
  , lCall1000

    -- * Constants
  , wallet1
  , wallet2
  , wallet3
  , admin

    -- * Contract origination
  , ManagedLedger (..)
  , ApprovableLedger (..)
  , BtgLedger (..)
  , btgLedger
  ) where

import Prelude

import qualified Lorentz as L
import Lorentz.Constraints
import qualified Lorentz.Contracts.ApprovableLedgerInterface as AL
import qualified Lorentz.Contracts.BTG as BTG
import Lorentz.Test
import Lorentz.Value
import qualified Michelson.Typed as T
import Tezos.Core (unsafeMkMutez)
import Util.Named ((.!))

----------------------------------------------------------------------------
-- Utilities
----------------------------------------------------------------------------

-- | Call a contract from genesis address sending 1000 mutez to it.
lCall1000
  :: (NiceParameter cp)
  => T.ContractAddr cp -> cp -> IntegrationalScenarioM ()
lCall1000 contract param =
  lTransfer (#from .! genesisAddress) (#to .! contract)
    (unsafeMkMutez 1000) param

----------------------------------------------------------------------------
-- Constants
----------------------------------------------------------------------------

wallet1, wallet2, wallet3, admin :: Address
wallet1 = genesisAddress1
wallet2 = genesisAddress2
wallet3 = genesisAddress3
admin = genesisAddress4

----------------------------------------------------------------------------
-- Contract origination
----------------------------------------------------------------------------

-- | Originate one of the managed ledger contracts with a storage
-- returned created by given function which takes admin address and
-- initial balances.
-- If initial balance is 0, ledger is empty.
originateBtgLedger
  :: forall param storage.
     (NiceParameter param, NiceStorage storage)
  => (Address -> [(Address, Natural)] -> [Address] -> storage)
  -> L.Contract param storage
  -> Natural
  -> [Address]
  -> IntegrationalScenarioM (ContractAddr param)
originateBtgLedger mkStorage contract initMoney whitelist =
  lOriginate contract "Managed ledger"
    (mkStorage admin balances whitelist) (toMutez 1000)
  where
    balances
      | initMoney == 0 = mempty
      | otherwise = someBalances

    someBalances :: [(Address, Natural)]
    someBalances =
      [ (wallet1, initMoney)
      , (wallet2, initMoney)
      ]

-- | This data type allows is an abstraction layer for all contracts
-- which implement approvable ledger interface. Since
-- 'Proxy.SaneParameter' contains exactly FA1.2 methods we require
-- parameter to be constructible from it.
data ApprovableLedger param = ApprovableLedger
  { alOriginate :: Natural -> IntegrationalScenarioM (ContractAddr param)
  -- ^ The argument denotes initial balances (can be 0).
  , alMkParam :: AL.Parameter -> param
  }

alBTG :: ApprovableLedger BTG.Parameter
alBTG = ApprovableLedger
  { alOriginate =
     flip (originateBtgLedger
             BTG.mkStorage
             BTG.btgTokenContract
          ) $ [wallet1, wallet2, wallet3]

  , alMkParam = \case
      AL.Transfer tp -> BTG.Transfer tp
      AL.Approve tp -> BTG.Approve tp
      AL.GetAllowance tp -> BTG.GetAllowance tp
      AL.GetBalance tp -> BTG.GetBalance tp
      AL.GetTotalSupply tp -> BTG.GetTotalSupply tp
  }

-- | This data type allows is an abstraction layer for all contracts
-- which implement managed ledger interface. Since
-- 'BTG.Parameter' contains managed ledger methods we require
-- parameter to be constructible from it.
data ManagedLedger param = ManagedLedger
  { mlApprovable :: ApprovableLedger param
  -- ^ Managed ledger always implements approvable ledger.
  , mlMkParam :: BTG.Parameter -> param
  }

mlBTG :: ManagedLedger BTG.Parameter
mlBTG = ManagedLedger
  { mlApprovable = alBTG
  , mlMkParam = id
  }

data BtgLedger param = BtgLedger
  { btgManaged :: ManagedLedger param
  -- ^ Btg ledger implements managed ledger
  , btgOriginate :: Natural -> [Address] -> IntegrationalScenarioM (ContractAddr param)
  , btgMkParam :: BTG.Parameter -> param
  }

btgLedger :: BtgLedger BTG.Parameter
btgLedger = BtgLedger
  { btgManaged = mlBTG
  , btgOriginate = originateBtgLedger BTG.mkStorage BTG.btgTokenContract
  , btgMkParam = id
  }
