{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | Tests for each requirement from the spec

module Test.Lorentz.Contracts.BTG.Acceptance
  ( spec_BTG
  ) where

-- Import Prelude to make intero calm
import Prelude

import Test.Hspec (Spec, SpecWith, describe, it)

import Lorentz (View(..), VoidResult(..))
import qualified Lorentz as L
import qualified Lorentz.Contracts.BTG as BTG
import Lorentz.Contracts.Consumer
import Lorentz.Test
import Lorentz.Value
import Michelson.Test (expectBalance, transfer)
import qualified Michelson.Untyped as Untyped
import Tezos.Address (mkKeyAddress)
import Tezos.Core (unsafeMkMutez)
import Tezos.Crypto (detSecretKey, toPublic)
import Util.Named ((.!))

import Test.Lorentz.Contracts.BTG.Common

{-# ANN module ("HLint: ignore Reduce duplication" :: Text) #-}

spec_BTG :: Spec
spec_BTG = btgAcceptanceSpec btgLedger

it' :: String -> IntegrationalScenario -> SpecWith ()
it' x = it x . integrationalTestExpectation

btgAcceptanceSpec ::
  forall param. NiceParameter param => BtgLedger param -> Spec
btgAcceptanceSpec BtgLedger
  { btgManaged = ManagedLedger { mlApprovable = ApprovableLedger {..} , ..}
  , ..
  } = do
  let genKey seed = mkKeyAddress . toPublic . detSecretKey $ seed
  let w1 = genKey "w1"
  let w2 = genKey "w2"
  let w3 = genKey "w3"
  let registerWallets = do
        let reg = transfer (TxData genesisAddress (Untyped.ValueUnit) (unsafeMkMutez 0))
        reg w1;reg w2; reg w3
  let lCallBtg addr = lCall addr . btgMkParam
  let originate value wl = registerWallets >> btgOriginate value wl

  let call contract sender = withSender sender . lCallBtg contract

  let addShares amounts btgl =
        let xs = fmap (\(a, b) -> (#to .! a, #value .! b)) amounts in
        (withSender admin . lCallBtg btgl $ BTG.MintBatch xs) >> return btgl

  let originateNatConsumer :: IntegrationalScenarioM (ContractAddr Natural)
        = lOriginateEmpty contractConsumer "nat consumer"

  let callPaused btgl currAdmin code = do
        call btgl currAdmin $ BTG.SetPause True
        call btgl currAdmin code
        call btgl currAdmin $ BTG.SetPause False

  let checkVoid res code = do
        validate $ Right expectAnySuccess
        code
        validate . Left $
          lExpectError (== VoidResult res)

  describe "Standard Token Functions" $ do

    describe "transfer" $ do

      it' "Transfers given amount between accounts" $ do
        btgl  <- (originate 0 [w1, w2]
                 >>= addShares [ (w1, 5)
                               , (w2, 5)])

        call btgl w1 $ BTG.Transfer (#from .! w1 , #to .! w2, #value .! 5)

        consumer <- originateNatConsumer
        lCallBtg btgl $ BTG.GetBalance (View (#owner .! w1) consumer)
        lCallBtg btgl $ BTG.GetBalance (View (#owner .! w2) consumer)
        validate . Right $ lExpectViewConsumerStorage consumer [0, 10]

      describe "Sender and receiver must be whitelisted" $ do

        it' "from not whitelisted" $ do
          btgl <- ( originate 10 [w2]
                  >>= addShares [(w2, 5)])

          call btgl w1 $ BTG.Transfer (#from .! w1 , #to .! w2, #value .! 5)

          validate . Left $ lExpectCustomError #notWhitelisted [w1]

        it' "to not whitelisted" $ do
          btgl <- ( originate 10 [w1]
                  >>= addShares [(w1, 5)])

          call btgl w1 $ BTG.Transfer (#from .! w1 , #to .! w2, #value .! 5)

          validate . Left $ lExpectCustomError #notWhitelisted [w2]

    describe "approve" $ do

      describe "Enables spender to withdraw given amount from sender" $ do

        it' "transfer fails without allowance" $ do
          btgl  <- (originate 0 [w1, w2]
                  >>= addShares [ (w1, 5)
                                , (w2, 5)])

          call btgl w2 $ BTG.Transfer (#from .! w1 , #to .! w2, #value .! 5)

          validate . Left $
            lExpectCustomError #notEnoughAllowance (#required .! 5, #present .! 0)

        it' "transfer works with allowance" $ do
          btgl  <- (originate 0 [w1, w2]
                  >>= addShares [ (w1, 5)
                                , (w2, 5)])

          call btgl w1 $
            BTG.Approve (#spender .! w2, #value .! 5)

          call btgl w2 $
            BTG.Transfer (#from .! w1 , #to .! w2, #value .! 5)

          consumer <- originateNatConsumer
          lCallBtg btgl $ BTG.GetBalance (View (#owner .! w1) consumer)
          lCallBtg btgl $ BTG.GetBalance (View (#owner .! w2) consumer)
          validate . Right $ lExpectViewConsumerStorage consumer [0, 10]

      describe "Sender and spender must be whitelisted" $ do
        it' "sender is not whitelisted" $ do
          btgl  <- (originate 0 [w2]
                  >>= addShares [ (w1, 5)
                                , (w2, 5)])

          call btgl w1 $
            BTG.Approve (#spender .! w2, #value .! 5)

          validate . Left $ lExpectCustomError #notWhitelisted [w1]

        it' "spender is not whitelisted" $ do
          btgl  <- (originate 0 [w1]
                  >>= addShares [ (w1, 5)
                                , (w2, 5)])

          call btgl w1 $
            BTG.Approve (#spender .! w2, #value .! 5)

          validate . Left $ lExpectCustomError #notWhitelisted [w2]

    describe "getAllowance" $ do

      it' "Returns approval value between two given addresses" $ do
        btgl  <- (originate 0 [w1, w2]
                >>= addShares [ (w1, 5)
                              , (w2, 5)])

        call btgl w1 $
          BTG.Approve (#spender .! w2, #value .! 5)

        consumer <- originateNatConsumer
        call btgl w2 $
          BTG.GetAllowance (View (#owner .! w1 , #spender .! w2) consumer)
        validate . Right $ lExpectViewConsumerStorage consumer [5]

    describe "getBalance" $ do

      it' "Returns balance of address" $ do
        btgl  <- (originate 0 [w1, w2]
                >>= addShares [ (w1, 5)
                              , (w2, 0)])

        consumer <- originateNatConsumer
        call btgl w1 $
          BTG.GetBalance (View (#owner .! w1) consumer)
        validate . Right $ lExpectViewConsumerStorage consumer [5]

    describe "getTotalSupply" $ do

      it' "Returns total number of tokens" $ do
        btgl  <- (originate 0 [w1, w2]
                >>= addShares [ (w1, 5)
                              , (w2, 5)])

        consumer <- originateNatConsumer
        call btgl w1 $ BTG.GetTotalSupply (View () consumer)

        call btgl admin $ BTG.Mint (#to .! w1, #value .! 1)
        call btgl w1 $ BTG.GetTotalSupply (View () consumer)

        call btgl admin $ BTG.Burn (#from .! w2, #value .! 2)
        call btgl w1 $ BTG.GetTotalSupply (View () consumer)

        call btgl w1 $ BTG.Transfer (#from .! w1, #to .! w2, #value .! 1)
        call btgl w1 $ BTG.GetTotalSupply (View () consumer)

        validate . Right $ lExpectViewConsumerStorage consumer [10, 11, 9, 9]

  describe "Managed Ledger Functions" $ do

    describe "setPause" $ do

      describe "Pauses certain operations ... All other operations remain unaffected" $ do

        it' "operations that change RBZ amounts (mint, burn, transfer) cannot be performed" $ do
          btgl  <- ( originate 0 [w1, w2]
                   >>= addShares [ (w1, 5)
                                 , (w2, 5)])

          call btgl admin $ BTG.SetPause True

          validate $ Right expectAnySuccess
          call btgl admin $ BTG.Mint (#to .! w1, #value .! 5)
          validate . Left $ lExpectCustomError #tokenOperationsArePaused ()

          validate $ Right expectAnySuccess
          call btgl admin $ BTG.Burn (#from .! w1, #value .! 5)
          validate . Left $ lExpectCustomError #tokenOperationsArePaused ()

          validate $ Right expectAnySuccess
          call btgl admin $ BTG.Transfer (#from .! w1, #to .! w2, #value .! 5)
          validate . Left $ lExpectCustomError #tokenOperationsArePaused ()

        it' "All other operations remain unaffected" $ do
          consumer <- originateNatConsumer
          addrConsumer :: ContractAddr Address <- lOriginateEmpty contractConsumer "addr consumer"

          btgl  <- originate 0 []

          call btgl admin $ BTG.SetPause True
          call btgl admin $ BTG.AddToWhitelist w1
          call btgl admin $ BTG.AddToWhitelistBatch [w1, w2, w3]
          call btgl admin $ BTG.SetPause False

          call btgl admin $ BTG.MintBatch [(#to .! w1, #value 5), (#to .! w2, #value 5)]

          call btgl admin $ BTG.SetPause True
          -- TODO: this is different from discussion in the Slack and from Managed Ledger behavior
          -- call btgl w1 $ BTG.Approve (#spender .! w2, #value 1)
          call btgl w1 $ BTG.GetAllowance (View (#owner .! w1, #spender .! w2) consumer)
          call btgl w1 $ BTG.GetBalance (View (#owner .! w1) consumer)
          call btgl w1 $ BTG.GetTotalSupply (View () consumer)
          call btgl w1 $ BTG.GetTotalSupply (View () consumer)
          checkVoid True (call btgl w1 $ BTG.GetPaused (L.mkVoid ()))
          call btgl w1 $ BTG.GetAdministrator (View () addrConsumer)
          call btgl admin $ BTG.SetAdministrator w1
          call btgl w1 $ BTG.SetAdministrator admin
          call btgl admin $ BTG.RemoveFromWhitelist w2
          call btgl admin $ BTG.RemoveFromWhitelistBatch [w3]
          checkVoid True (call btgl admin $ BTG.CheckWhitelisted (L.mkVoid w1))
          call btgl w1 $ BTG.Withdraw ()
          call btgl admin $ BTG.Collect ()
          call btgl admin $ BTG.AddDividends ()

          validate $ Right expectAnySuccess

        describe "Sender must be token administrator" $ do

          it' "works if sender is admin" $ do
            btgl  <- originate 0 []
            call btgl admin $ BTG.SetPause True
            validate $ Right expectAnySuccess

          it' "fails if sender is not admin" $ do
            btgl  <- originate 0 []
            call btgl w1 $ BTG.SetPause True
            validate . Left $ lExpectCustomError #senderIsNotAdmin ()

    describe "getPaused()" $ do

      it' "Returns pause status" $ do
        btgl  <- originate 0 []

        call btgl admin $ BTG.SetPause True
        checkVoid True (call btgl w1 $ BTG.GetPaused (L.mkVoid ()))

        call btgl admin $ BTG.SetPause False
        checkVoid False (call btgl w1 $ BTG.GetPaused (L.mkVoid ()))

    describe "getAdministrator " $ do

      it' "Returns token admin" $ do
        addrConsumer :: ContractAddr Address <- lOriginateEmpty contractConsumer "addr consumer"
        btgl  <- originate 0 []
        call btgl w1 $ BTG.GetAdministrator (View () addrConsumer)
        validate . Right $ lExpectViewConsumerStorage addrConsumer [admin]

    describe "setAdministrator :address" $ do
      it' "Sets token administrator" $ do
        addrConsumer :: ContractAddr Address <- lOriginateEmpty contractConsumer "addr consumer"
        btgl  <- originate 0 []
        call btgl admin $ BTG.SetAdministrator w1
        call btgl w1 $ BTG.GetAdministrator (View () addrConsumer)
        validate . Right $ lExpectViewConsumerStorage addrConsumer [w1]

      describe "Sender must be current token admin" $ do

        it' "works is sender is admin" $ do
          btgl  <- originate 0 []
          call btgl admin $ BTG.SetAdministrator w1
          validate $ Right expectAnySuccess

        it' "fails is sender is not admin" $ do
          btgl  <- originate 0 []
          call btgl w1 $ BTG.SetAdministrator w1
          validate . Left $ lExpectCustomError #senderIsNotAdmin ()

    describe "mint" $ do

      it' "Produces tokens to the wallet associated with the given address" $ do
          consumer <- originateNatConsumer
          btgl  <- originate 0 [w1]
          call btgl admin $ BTG.Mint (#to .! w1, #value .! 5)
          call btgl admin $ BTG.GetBalance (View (#owner .! w1) consumer)
          validate . Right $ lExpectViewConsumerStorage consumer [5]

      describe "Receiving address must be whitelisted" $ do

        it' "works if sender is whitelisted" $ do
          btgl  <- originate 0 [w1]
          call btgl admin $ BTG.Mint (#to .! w1, #value .! 5)
          validate $ Right expectAnySuccess

        it' "fails if sender is whitelisted" $ do
          btgl  <- originate 0 []
          call btgl admin $ BTG.Mint (#to .! w1, #value .! 5)
          validate . Left $ lExpectCustomError #notWhitelisted [w1]

      describe "Sender must be token admin" $ do

        it' "works if sender is admin" $ do
          btgl  <- originate 0 [w1]
          call btgl admin $ BTG.Mint (#to .! w1, #value .! 5)
          validate $ Right expectAnySuccess

        it' "fails if sender is not admin" $ do
          btgl  <- originate 0 [w1]
          call btgl w1 $ BTG.Mint (#to .! w1, #value .! 5)
          validate . Left $ lExpectCustomError #senderIsNotAdmin ()

    describe "mintBatch" $ do

      it' "Produces tokens on the account associated with the given address" $ do
          consumer <- originateNatConsumer
          btgl  <- originate 0 [w1, w2]
          call btgl admin $ BTG.MintBatch [ (#to .! w1, #value .! 1)
                                              , (#to .! w2, #value .! 2)]
          call btgl admin $ BTG.GetBalance (View (#owner .! w1) consumer)
          call btgl admin $ BTG.GetBalance (View (#owner .! w2) consumer)
          validate . Right $ lExpectViewConsumerStorage consumer [1, 2]

      describe "Receiving address must be whitelisted" $ do

        it' "workds if addresses are whitelisted" $ do
          btgl  <- originate 0 [w1, w2]
          call btgl admin $ BTG.MintBatch [ (#to .! w1, #value .! 1)
                                              , (#to .! w2, #value .! 2)]
          validate $ Right expectAnySuccess

        it' "fails if one of addresses is not whitelisted" $ do
          btgl  <- originate 0 [w1]
          call btgl admin $ BTG.MintBatch [ (#to .! w1, #value .! 1)
                                              , (#to .! w2, #value .! 2)]
          validate . Left $ lExpectCustomError #notWhitelisted [w2]

      describe "Sender must be token admin" $ do

        it' "works if sender is admin" $ do
          btgl  <- originate 0 [w1]
          call btgl admin $ BTG.MintBatch [(#to .! w1, #value .! 5)]
          validate $ Right expectAnySuccess

        it' "fails if sender is not admin" $ do
          btgl  <- originate 0 [w1]
          call btgl w1 $ BTG.MintBatch [(#to .! w1, #value .! 5)]
          validate . Left $ lExpectCustomError #senderIsNotAdmin ()

    describe "burn" $ do
      it' "Destroys the given amount of tokens on the account associated with the given address" $ do
        consumer <- originateNatConsumer
        btgl  <- ( originate 0 [w1]
                  >>= addShares [(w1, 5)])

        call btgl admin $ BTG.Burn (#from .! w1, #value .! 1)
        call btgl admin $ BTG.GetBalance (View (#owner .! w1) consumer)
        validate . Right $ lExpectViewConsumerStorage consumer [4]

      describe "Sender must be token admin" $ do

        it' "works if sender is admin" $ do
          btgl  <- ( originate 0 [w1]
                    >>= addShares [(w1, 5)])
          call btgl admin $ BTG.Burn (#from .! w1, #value .! 1)
          validate $ Right expectAnySuccess

        it' "fails if sender is not admin" $ do
          btgl  <- ( originate 0 [w1]
                    >>= addShares [(w1, 5)])
          call btgl w1 $ BTG.Burn (#from .! w1, #value .! 1)
          validate . Left $ lExpectCustomError #senderIsNotAdmin ()

      it' "and account must have sufficient funds to be destroyed" $ do
        btgl  <- ( originate 0 [w1]
                  >>= addShares [(w1, 5)])
        call btgl admin $ BTG.Burn (#from .! w1, #value .! 10)
        validate . Left $
          lExpectCustomError #notEnoughBalance (#required .! 10, #present .! 5)

  describe "Token White List" $ do
    describe "addToWhitelist" $ do
      it' "Adds wallet to whitelist, enabling it to transfer and approve tokens as well as modify allowances" $ do
        btgl  <- originate 0 []
        call btgl admin $ BTG.AddToWhitelist w1
        call btgl admin $ BTG.AddToWhitelist w2

        call btgl admin $ BTG.MintBatch [ (#to .! w1, #value .! 5)
                                            , (#to .! w2, #value .! 5)]

        call btgl w1 $ BTG.Transfer (#from .! w1, #to .! w2, #value .! 1)
        call btgl w1 $ BTG.Approve (#spender .! w2, #value .! 5)
        validate $ Right expectAnySuccess

      describe "Sender must be token administrator" $ do
        it' "works if sender is admin" $ do
          btgl  <- originate 0 []
          call btgl admin $ BTG.AddToWhitelist w1
          validate $ Right expectAnySuccess

        it' "fails if sender is not admin" $ do
          btgl  <- originate 0 []
          call btgl w1 $ BTG.AddToWhitelist w1
          validate . Left $ lExpectCustomError #senderIsNotAdmin ()

    describe "addToWhitelistBatch" $ do

      it' "Adds wallet to whitelist, enabling it to transfer and approve tokens as well as modify allowances" $ do
        btgl  <- originate 0 []
        call btgl admin $ BTG.AddToWhitelistBatch [w1, w2, w3]

        call btgl admin $ BTG.MintBatch [ (#to .! w1, #value .! 5)
                                            , (#to .! w2, #value .! 5)]

        call btgl w1 $ BTG.Transfer (#from .! w1, #to .! w2, #value .! 1)
        call btgl w1 $ BTG.Approve (#spender .! w2, #value .! 5)
        call btgl w2 $ BTG.Transfer (#from .! w2, #to .! w3, #value .! 1)
        call btgl w2 $ BTG.Approve (#spender .! w3, #value .! 5)
        validate $ Right expectAnySuccess

      describe "Sender must be token administrator" $ do
        it' "works if sender is admin" $ do
          btgl  <- originate 0 []
          call btgl admin $ BTG.AddToWhitelistBatch [w1]
          validate $ Right expectAnySuccess

        it' "fails if sender is not admin" $ do
          btgl  <- originate 0 []
          call btgl w1 $ BTG.AddToWhitelistBatch [w1]
          validate . Left $ lExpectCustomError #senderIsNotAdmin ()


    describe "removeFromWhitelist" $ do
      it' "Removes wallet from whitelist" $ do
        btgl  <- originate 0 [w1]
        checkVoid True (call btgl admin $ BTG.CheckWhitelisted (L.mkVoid w1))
        call btgl admin $ BTG.RemoveFromWhitelist w1
        checkVoid False (call btgl admin $ BTG.CheckWhitelisted (L.mkVoid w1))

      describe "Sender must be token administrator" $ do
        it' "works if sender is admin" $ do
          btgl  <- originate 0 [w1]
          call btgl admin $ BTG.RemoveFromWhitelist w1
          validate $ Right expectAnySuccess

        it' "fails if sender is not admin" $ do
          btgl  <- originate 0 []
          call btgl w1 $ BTG.RemoveFromWhitelist w1
          validate . Left $ lExpectCustomError #senderIsNotAdmin ()


    describe "removeFromWhitelistBatch" $ do
      it' "Removes wallet from whitelist" $ do
        btgl  <- originate 0 [w1, w2]
        checkVoid True (call btgl admin $ BTG.CheckWhitelisted (L.mkVoid w1))
        checkVoid True (call btgl admin $ BTG.CheckWhitelisted (L.mkVoid w2))
        call btgl admin $ BTG.RemoveFromWhitelistBatch [w1, w2]
        checkVoid False (call btgl admin $ BTG.CheckWhitelisted (L.mkVoid w1))
        checkVoid False (call btgl admin $ BTG.CheckWhitelisted (L.mkVoid w2))


      it' "If some of specified wallets are not in whitelist, fails (returning list of those wallets)" $ do
        btgl  <- originate 0 [w2]
        call btgl admin $ BTG.RemoveFromWhitelistBatch [w1, w2, w3]
        validate . Left $ lExpectCustomError #notWhitelisted [w1, w3]

      describe "Sender must be token administrator" $ do
        it' "works if sender is admin" $ do
          btgl  <- originate 0 [w1]
          call btgl admin $ BTG.RemoveFromWhitelistBatch [w1]
          validate $ Right expectAnySuccess

        it' "fails if sender is not admin" $ do
          btgl  <- originate 0 []
          call btgl w1 $ BTG.RemoveFromWhitelistBatch [w1]
          validate . Left $ lExpectCustomError #senderIsNotAdmin ()

    describe "checkWhitelisted" $ do
      it' "method exists" $ do
        btgl  <- originate 0 [w1]
        checkVoid True (call btgl admin $ BTG.CheckWhitelisted (L.mkVoid w1))

  describe "Dividend Management" $ do
    describe "disburse" $ do
      it' "Send dividends which belong to the account token addresses" $ do
        btgl  <- ( originate 0 [w1, w2]
                 >>= addShares [ (w1, 1)
                               , (w2, 3)])

        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        callPaused btgl admin $ BTG.AddDividends ()

        call btgl admin $ BTG.Disburse [w1, w2]

        validate . Right $ expectBalance w1 (unsafeMkMutez 250)
        validate . Right $ expectBalance w2 (unsafeMkMutez 750)

      describe "Sender must be token admin" $ do

        it' "works if sender is admin" $ do
          btgl  <- originate 0 [w1]
          call btgl admin $ BTG.Disburse [w1]
          validate $ Right expectAnySuccess

        it' "fails if sender is not admin" $ do
          btgl  <- originate 0 []
          call btgl w1 $ BTG.Disburse [w1]
          validate . Left $ lExpectCustomError #senderIsNotAdmin ()

    describe "withdraw" $ do

      it' "Send dividends which belong to the sender" $ do
        btgl  <- ( originate 0 [w1, w2]
                 >>= addShares [ (w1, 1)
                               , (w2, 3)])

        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        callPaused btgl admin $ BTG.AddDividends ()

        call btgl w1 $ BTG.Withdraw ()

        validate . Right $ expectBalance w1 (unsafeMkMutez 250)
        validate . Right $ expectBalance w2 (unsafeMkMutez 0)

        call btgl w2 $ BTG.Withdraw ()
        validate . Right $ expectBalance w1 (unsafeMkMutez 250)
        validate . Right $ expectBalance w2 (unsafeMkMutez 750)

    describe "collect" $ do
      it' "Send all dividends from token contract regardless of who they belong to, including unclaimed dividends, to the sender" $ do
        btgl  <- ( originate 0 [w1, w2]
                 >>= addShares [ (w1, 1)
                               , (w2, 3)])

        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        callPaused btgl admin $ BTG.AddDividends ()

        call btgl admin $ BTG.SetAdministrator w1
        call btgl w1 $ BTG.Collect ()
        validate . Right $ expectBalance w1 (unsafeMkMutez 1000)

      describe "Sender must be token admin" $ do

        it' "works if sender is admin" $ do
          btgl  <- originate 0 [w1]
          call btgl admin $ BTG.Collect ()
          validate $ Right expectAnySuccess

        it' "fails if sender is not admin" $ do
          btgl  <- originate 0 []
          call btgl w1 $ BTG.Collect ()
          validate . Left $ lExpectCustomError #senderIsNotAdmin ()

    describe "addDividends" $ do

      it' "Register dividends for given addresses" $ do
        btgl  <- ( originate 0 [w1, w2]
                 >>= addShares [ (w1, 1)
                               , (w2, 3)])

        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        callPaused btgl admin $ BTG.AddDividends ()

        call btgl w1 $ BTG.Withdraw ()

        validate . Right $ expectBalance w1 (unsafeMkMutez 250)
        validate . Right $ expectBalance w2 (unsafeMkMutez 0)

        call btgl w2 $ BTG.Withdraw ()
        validate . Right $ expectBalance w1 (unsafeMkMutez 250)
        validate . Right $ expectBalance w2 (unsafeMkMutez 750)

      describe "Sender must be token admin" $ do

        it' "works if sender is admin" $ do
          btgl  <- (originate 0 [w1] >>= addShares [(w1, 1)])
          callPaused btgl admin $ BTG.AddDividends ()
          validate $ Right expectAnySuccess

        it' "fails if sender is not admin" $ do
          btgl  <- (originate 0 [w1] >>= addShares [(w1, 1)])
          callPaused btgl w1 $ BTG.AddDividends ()
          validate . Left $ lExpectCustomError #senderIsNotAdmin ()

      describe "Can only be called while the token contract is paused" $ do

        it' "works if paused" $ do
          btgl  <- (originate 0 [w1] >>= addShares [(w1, 1)])
          callPaused btgl admin $ BTG.AddDividends ()
          validate $ Right expectAnySuccess

        it' "fails if not paused" $ do
          btgl  <- (originate 0 [w1] >>= addShares [(w1, 1)])
          call btgl admin $ BTG.AddDividends ()
          validate . Left $ lExpectCustomError #tokenOperationsAreNotPaused ()
