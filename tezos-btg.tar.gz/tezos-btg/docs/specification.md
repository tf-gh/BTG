<!--
 - SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -->

**Overview**
------------

These specifications were assembled with the following references:

- Tezos Token Standard:
  [*FA1.2*](https://gitlab.com/tzip/tzip/blob/master/A/FA1.2.md) and
  [*ManagedLedger*](https://gitlab.com/tzip/tzip/blob/master/assets/FA1.2/ManagedLedger.md)

- [*Solidity
  contracts*](https://drive.google.com/a/tqgroup.io/file/d/1qkwL1CYxUQw9fcFhHMabr8PYqxOKiGoG/view?usp=drive_web)
  for the ReitBZ implementation

- [*Ethereum’s ERC-20*](https://eips.ethereum.org/EIPS/eip-20) Token Standard

- [*Michelson Contract Interfaces and Conventions*](https://gitlab.com/tzip/tzip/blob/master/A/A1.md) TZIP which defines `view` and `void` type synonyms

**General Requirements**
------------------------

- The token(s) must be FA1.2 compatible as to facilitate listing on
  exchanges and interaction with services which support FA1.2

**Token Functions**
===================

**Standard Token Functions**
----------------------------

Functions for the ReitBZ implementation which are common to the [*FA1.2 Tezos
Token Standard*](https://gitlab.com/tzip/tzip/blob/master/A/FA1.2.md)

**transfer** (address :from, address :to, nat :value)

- Transfers given amount between accounts

- Sender and receiver must be whitelisted

**approve** (address :spender, nat :value)

- Enables spender to withdraw given amount from sender

- Sender and spender must be whitelisted

**getAllowance** (view (address :owner, address :spender) nat)

- Returns approval value between two given addresses

**getBalance** (view (address :owner) nat)

- Returns balance of address

**getTotalSupply** (view unit nat)

- Returns total number of tokens

**Managed Ledger Functions**
----------------------------

Functions for the ReitBZ implementation found in Tezos’ [*ManagedLedger*](https://gitlab.com/tzip/tzip/blob/master/assets/FA1.2/ManagedLedger.md)

**setPause** bool

- Pauses certain operations when the parameter is True, and resumes
  them when the parameter is False. During the pause, operations
  that change RBZ amounts (mint, burn, transfer) cannot be
  performed. All other operations remain unaffected.

- Sender must be token administrator

**getPaused** (void unit bool)

- Returns pause status

- *Note: Not a part of ManagedLedger*

**getAdministrator** (view unit address)

- Returns token admin

**setAdministrator** address

- Sets token administrator

- Sender must be current token admin

**mint** (address :to, nat :value)

- Produces tokens to the wallet associated with the given address

- Receiving address must be whitelisted

- Sender must be token admin

**mintBatch** (list (address :to, nat :value))

- Produces tokens on the account associated with each given address

- Receiving address must be whitelisted

- Sender must be token admin

**burn** (address :from, nat :value)

- Destroys the given amount of tokens on the account associated with the given
  address

- Sender must be token admin and account must have sufficient funds to be
  destroyed

**Custom Token Functions**
--------------------------

Functions for the ReitBZ implementation which are outside the FA1.2 Tezos Token
Standard. These functions were found on the Solidity implementation.

### **Token White List**

**addToWhitelist** address

- Adds wallet to whitelist, enabling it to transfer and approve tokens as well
  as modify allowances

- Sender must be token administrator

**addToWhitelistBatch** (list address)

- Adds each wallet to whitelist, enabling it to transfer and approve tokens as well
  as modify allowances

- Sender must be token administrator

**removeFromWhitelist** address

- Removes wallet from whitelist

- Sender must be token administrator

**removeFromWhitelistBatch** (list address)

- Removes wallet from whitelist

- If some of specified wallets are not in whitelist, fails (returning list of
  those wallets)

- Sender must be token administrator

**checkWhitelisted** (void address bool)

### **Dividend Management**

**disburse** (list address)

- Send dividends which belong to the account token addresses

- Sender must be token admin

**withdraw** unit

- Send dividends which belong to the sender

**collect** unit

- Send all dividends from token contract regardless of who they belong to,
  including unclaimed dividends, to the admin

- Sender must be token admin

**addDividends** unit

- Register dividends for given addresses

- Sender must be token admin

- Can only be called while the token contract is paused
