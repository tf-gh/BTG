<!--
 - SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -->

0.2.1
==========

* [#61](https://github.com/serokell/tezos-btg/pull/61)
Add command for printing BTG specialized multisig wrapper contract.

0.2.0
=====

* Small optimizations of low-level Michelson code caused by `morley` dependency update (removal of redundant `DIP` before `DROP`).
* [#59](https://github.com/serokell/tezos-btg/pull/58)
Add `setMintingCap` and `getMintingCap` entrypoints.
* [#58](https://github.com/serokell/tezos-btg/pull/58)
Deconstruct administrator ownership transfer into a 2-step process.
* [#57](https://github.com/serokell/tezos-btg/pull/57)
Add `approveCAS` entrypoint.
* [#51](https://github.com/serokell/tezos-btg/pull/51)
Use more efficient `duupX` implementation when its parameter is greater than 2.

0.1.0
=====

MVP release.
Contract code in this version is the same as in the revision submitted for the audit (db12fa0).
