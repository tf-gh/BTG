<!--
 - SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -->

**Overview**
------------

These specifications were assembled with the following references:

- Tezos Token Standard:
  [*FA1.2*](https://gitlab.com/tzip/tzip/blob/ae2f1e7ebb3454d811a2bea3cd0698b0e64ccea5/proposals/tzip-7/tzip-7.md) and
  [*ManagedLedger*](https://gitlab.com/tzip/tzip/blob/ae2f1e7ebb3454d811a2bea3cd0698b0e64ccea5/proposals/tzip-7/ManagedLedger.md)

- [*Solidity
  contracts*](https://drive.google.com/a/tqgroup.io/file/d/1qkwL1CYxUQw9fcFhHMabr8PYqxOKiGoG/view?usp=drive_web)
  for the ReitBZ implementation

- [*Ethereum’s ERC-20*](https://eips.ethereum.org/EIPS/eip-20) Token Standard

- [*Michelson Contract Interfaces and Conventions*](https://gitlab.com/tzip/tzip/blob/ae2f1e7ebb3454d811a2bea3cd0698b0e64ccea5/proposals/tzip-4/tzip-4.md) TZIP which defines `view` and `void` type synonyms

**General Requirements**
------------------------

- The token(s) must be FA1.2 compatible as to facilitate listing on
  exchanges and interaction with services which support FA1.2

**Token Functions**
===================

**Standard Token Functions**
----------------------------

Functions for the ReitBZ implementation which are common to the [*FA1.2 Tezos
Token Standard*](https://gitlab.com/tzip/tzip/blob/ae2f1e7ebb3454d811a2bea3cd0698b0e64ccea5/proposals/tzip-7/tzip-7.md)

**transfer** (address :from, address :to, nat :value)

- Transfers given amount between accounts

- Sender and receiver must be whitelisted

**approve** (address :spender, nat :value)

- Enables spender to withdraw given amount from sender

- Sender and spender must be whitelisted

**getAllowance** (view (address :owner, address :spender) nat)

- Returns approval value between two given addresses

**getBalance** (view (address :owner) nat)

- Returns balance of address

**getTotalSupply** (view unit nat)

- Returns total number of tokens

**Custom Functions**
--------------------------

**approveCAS** (address :spender, nat :value, nat :expected)

- Enables spender to withdraw given amount from sender

- Sender and spender must be whitelisted

- Expected value must match the current allowance value

**setMintingCap** nat

- Set minting capacity for the whole token

- Sender must be token admin

**getMintingCap** (void unit natural)

- Returns current minting capacity

**getTotalMinted** (void unit natural)

- Returns current amount of minted coins

**Managed Ledger Functions**
----------------------------

Functions for the ReitBZ implementation found in Tezos’ [*ManagedLedger*](https://gitlab.com/tzip/tzip/blob/ae2f1e7ebb3454d811a2bea3cd0698b0e64ccea5/proposals/tzip-7/ManagedLedger.md)

**setPause** bool

- Pauses certain operations when the parameter is True, and resumes
  them when the parameter is False. During the pause, operations
  that change RBZ amounts (`mint`, `burn`, `transfer`) and
  allowance (`approve`, `approveCAS`) cannot be performed.
  All other operations remain unaffected.

- Sender must be token administrator

**getPaused** (void unit bool)

- Returns pause status

- *Note: Not a part of ManagedLedger*

**getAdministrator** (view unit address)

- Returns token admin

**setAdministrator** address

- Sets token administrator

- Sender must be current token admin

- The current administrator retains his priveleges up until
  `acceptOwnership` is called

- Can be called multiple times, each call replaces pending
  administrator with the new one. Note, that if proposed administrator
  is the same as the current one, then the call is simply invalidated

**acceptOwnership** unit

- Accept owner privileges and make sure that the new administrator is
  able to send transactions

- Sender must be a pending administrator

**mint** (address :to, nat :value)

- Produces tokens to the wallet associated with the given address

- Receiving address must be whitelisted

- Sender must be token admin

- The total amount of minted coins must not exceed the current minting cap

**mintBatch** (list (address :to, nat :value))

- Produces tokens on the account associated with each given address

- Receiving addresses must be whitelisted

- Sender must be token admin

- The total amount of minted coins must not exceed the current minting cap

**burn** (address :from, nat :value)

- Destroys the given amount of tokens on the account associated with the given
  address

- Sender must be token admin and account must have sufficient funds to be
  destroyed

**Custom Token Functions**
--------------------------

Functions for the ReitBZ implementation which are outside the FA1.2 Tezos Token
Standard. These functions were found on the Solidity implementation.

### **Token White List**

**addToWhitelist** address

- Adds wallet to whitelist, enabling it to transfer and approve tokens as well
  as modify allowances

- Sender must be token administrator

**addToWhitelistBatch** (list address)

- Adds each wallet to whitelist, enabling it to transfer and approve tokens as well
  as modify allowances

- Sender must be token administrator

**removeFromWhitelist** address

- Removes wallet from whitelist

- Sender must be token administrator

**removeFromWhitelistBatch** (list address)

- Removes wallet from whitelist

- If some of specified wallets are not in whitelist, fails (returning list of
  those wallets)

- Sender must be token administrator

**checkWhitelisted** (void address bool)

### **Dividend Management**

**disburse** (list address)

- Send dividends which belong to the account token addresses

- Sender must be token admin

**withdraw** unit

- Send dividends which belong to the sender

**collect** unit

- Send all dividends from token contract regardless of who they belong to,
  including unclaimed dividends, to the admin

- Sender must be token admin

**addDividends** unit

- Register dividends for given addresses

- Sender must be token admin

- Can only be called while the token contract is paused
