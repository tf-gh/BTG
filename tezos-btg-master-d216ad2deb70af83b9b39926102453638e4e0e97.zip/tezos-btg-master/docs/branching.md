<!--
 - SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -->

This project uses a variation of the [OneFlow](https://www.endoflineblog.com/oneflow-a-git-branching-model-and-workflow) branching model with two branches. Naming of long-lived branches is different:
* `develop` branch from OneFlow is called `master` in this repository.
* `master` branch from OneFlow is called `production` in this repository.

So code in the `master` branch represents latest development version and code in the `production` branch represents latest stable version.
