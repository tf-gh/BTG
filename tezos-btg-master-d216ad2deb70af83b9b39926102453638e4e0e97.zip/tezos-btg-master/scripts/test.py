#!/usr/bin/env python3.7

# SPDX-FileCopyrightText: 2019 Tocqueville Group, 2019 BTG Pactual
#
# SPDX-License-Identifier: AGPL-3.0-or-later

# This script calls some entrypoints of our contract using `babylonnet.sh`.
# Unless `--dry-run` is passed it assumes that:
# • `babylonnet.sh` can be executed.

import argparse
import os
import subprocess
import time

from common import (babylonnet_client, transfer, get_balance_str, get_git_revision)

class DummyStatisticsFile:
    def report(self, comment, res): pass

class CsvStatisticsFile:
    def __init__(self, f):
        self.f = f
        self.f.write("Action,Gas consumption\n")

    def report(self, comment, res):
        self.f.write(f"\"{truncate(comment[2:], 60)}\",{res['consumed_gas']}\n")
        self.f.flush()

def truncate(s, n):
    return (s[:n] + '...') if len(s) > n + 3 else s

def interpret_scenario(f, rf):
    lines = list(f.readlines())
    i = 0
    def preview():
        return lines[i].strip()
    def eat():
        nonlocal i
        i = i + 1
        return lines[i - 1].strip()
    def contract_call_cmd():
        comment = eat()
        addr, amount = eat().split()
        param = eat()

        print(comment)
        print('Addr:', addr)
        print('Param:', param)

        res = transfer(
            source=addr, dest=contract_addr, amount=amount, param=param,
            burn_cap="25", capture_result=True, dry_run=args.dry_run,
            )
        print(res)
        rf.report(comment, res)

    def transfer_cmd():
        _, from_, to, amount = eat().split()
        print("> Transfer {} {} {}".format(from_, to, amount))
        transfer(
            source=from_, dest=to, amount=amount, param="Unit",
            burn_cap="25", dry_run=args.dry_run,
            )
    def check_balance_cmd():
        _, addr, amount = eat().split()
        balance = get_balance_str(addr, dry_run=args.dry_run)
        if not args.dry_run:
            print("expecting {} == {}".format(balance, amount))
            assert(balance == amount)

    while i < len(lines):
        free = False
        op = preview()
        if not op or op.startswith("###"):
            print(eat())
        elif op.startswith("check-balance"):
            check_balance_cmd()
        else:
            if op.startswith("transfer"):
                transfer_cmd()
            else:
                contract_call_cmd()

            if not args.dry_run:
                time.sleep(6)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Test our contract')
    # We can add more if necessary (e. g. for babylonnet_sh)
    parser.add_argument('--admin', required=True,
        metavar='ADDRESS', help="Admin address")
    parser.add_argument('--contract', required=True,
        metavar='ADDRESS', help="Contract address")
    parser.add_argument('--address', nargs='+',
        metavar='ADDRESS', help="Additional owned addresses")
    parser.add_argument('--dry-run', action='store_true',
        help="Do not submit transactions")
    parser.add_argument('--test-scenario',
        default='gas-test-scenario',
        help="gas-test-scenario | test-scenario")
    parser.add_argument('--our-exe',
        default='stack exec -- btg',
        help="How to launch our executable")

    args = parser.parse_args()
    admin = args.admin
    contract_addr = args.contract
    our_exe = args.our_exe.split()

    # Print scenario
    scenario = "scenario.txt"
    if args.test_scenario == 'gas-test-scenario':
        subprocess.run(our_exe +
            ["gas-test-scenario", "-o", scenario, "--admin", admin] +
            [arg for addr in args.address for arg in ["--address", addr]]
            )
    elif args.test_scenario == 'test-scenario':
        subprocess.run(our_exe +
            ["test-scenario", "-o", scenario, "--admin", admin, "--contract", contract_addr] +
            [arg for addr in args.address for arg in ["--address", addr]]
            )
    else:
        print("Invalid --test-scenario argument")
        sys.exit(1)

    with open(scenario, mode="r") as f:
        # don't write statistics in dry-run mode
        if args.dry_run:
            interpret_scenario(f, DummyStatisticsFile())
        else:
            results_table = f"gas_consumption_{get_git_revision()}.csv"
            with open(results_table, mode="w") as rf:
                interpret_scenario(f, CsvStatisticsFile(rf))

    print("Finished running scenario")
    os.remove(scenario)
