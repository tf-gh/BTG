<!--
 - SPDX-FileCopyrightText: 2019 Tocqueville Group, 2019 BTG Pactual
 -
 - SPDX-License-Identifier: AGPL-3.0-or-later
 -->

# Scripts

Here we store scripts for various purposes.
Brief overview is provided below.

## Development

* `lint.hs` calls `hlint` for source files with proper arguments.

## Testing

* `deploy.py` can be used to deploy our contract.
* `test.py` can be used to test our contract on a real network.
* `test.sh` deploys the contract, creates a set of new addresses and runs the test.

Please refer to their CLI help and comments for more information, they are pretty simple.

There are two possible workflows:

### Automated

using a single `test.sh` script. It deploys the contract, creates a set of new
addresses and runs the tests.

1. Put `babylonnet.sh` into root of the repo (maybe as a symlink).
2. Prepare one address with enough XTZ to deploy the contract and run tests; pass it as an --admin parameter
3. Run the script like this, substituting suitable arguments:

         scripts/test.sh --admin tz1N7gkZuCcHSQ8kJxAyvx6aFsDM5nHphzYD --node obsidian.webhop.org --port 9112

The script is quite fragile and has no proper errors reporting mechanism :(

### Manuall

Using 2 scripts to deploy the contract and run tests.

Here is a common workflow:
1. Put `babylonnet.sh` into root of the repo (maybe as a symlink).
2. Make sure you have one address with some XTZ to deploy the contract.
3. Run `scripts/deploy.py --owner OWNER_ADDR`.
Find the address of the contract in the output.
To test the contract you need to provide at least two owned addresses.
4. Run `scripts/test.py --owner OWNER_ADDR --contract CONTRACT_ADDR --address OWNED_ADDR1 [OWNED_ADDR2 ...]`.

## CI

CI runs some executable to test them.
We put all these calls into `ci-test.sh`.
Note that for now we do not use Tezos network there at all and do not use `tezos-client` or similar software.
It runs the above scripts in `--dry-run` mode.
