#!/usr/bin/env python3

# SPDX-FileCopyrightText: 2019 Tocqueville Group, 2019 BTG Pactual
#
# SPDX-License-Identifier: AGPL-3.0-or-later


# This script deploys our contract to a real network using `babylonnet.sh`.
# Unless `--dry-run` is passed it assumes that:
# • `babylonnet.sh` can be executed;
# • the secret key of the originator address is known and the address has
#   enough XTZ to perform all these operations.

import argparse
import os
import random
import subprocess
import time

from common import (babylonnet_client, transfer)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Deploy our contract')
    # We can add more if necessary (e. g. for babylonnet_sh)
    parser.add_argument('--admin', required=True,
        metavar='ADDRESS', help="Admin's address")
    parser.add_argument('--dry-run', action='store_true',
        help="Do not submit transactions/originations")
    parser.add_argument('--our-exe',
        default='stack exec -- btg',
        help="How to launch our executable")

    args = parser.parse_args()
    admin = args.admin
    our_exe = args.our_exe.split()

    # Print contract
    contract_tz = "btg.tz"
    subprocess.run(our_exe + ["contract", "-o", contract_tz], capture_output=True)

    # Get initial storage
    initial_storage = subprocess.run(
        our_exe + ["storage", admin],
        capture_output=True).stdout

    # Originate
    contract_alias = "btg" + str(random.randrange(100500))
    originate_cmd = babylonnet_client + [
        "originate", "contract", contract_alias, "transferring",
        "0", "from", admin, "running", "container:" + contract_tz,
        "--init", initial_storage.strip(),
        "--burn-cap", "22",
        ]
    if args.dry_run:
        print(originate_cmd)
    else:
        subprocess.run(originate_cmd, check=True)

    os.remove(contract_tz)
