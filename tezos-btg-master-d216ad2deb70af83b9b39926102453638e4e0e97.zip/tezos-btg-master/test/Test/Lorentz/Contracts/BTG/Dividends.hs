{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | Tests for BTG Dividends part.

module Test.Lorentz.Contracts.BTG.Dividends
  ( spec_Dividends
  ) where

-- Import Prelude to make intero calm
import Prelude

import Test.Hspec (Spec, describe, it)

import Lorentz (mkView)
import qualified Lorentz.Contracts.BTG as BTG
import Lorentz.Test
import Lorentz.Value
import Michelson.Runtime (ExecutorError'(..))
import Tezos.Address (detGenKeyAddress)
import Tezos.Core (unsafeMkMutez)
import Util.Named ((.!))

import Test.Lorentz.Contracts.BTG.Common

{-# ANN module ("HLint: ignore Reduce duplication" :: Text) #-}

spec_Dividends :: Spec
spec_Dividends = btgDividendsSpec btgLedger

btgDividendsSpec :: BtgLedger BTG.Parameter -> Spec
btgDividendsSpec BtgLedger
  { btgManaged = ManagedLedger { mlApprovable = ApprovableLedger {..} , ..}
  , ..
  } = do
  let w1 = detGenKeyAddress "w1"
  let w2 = detGenKeyAddress "w2"
  let w3 = detGenKeyAddress "w3"
  let lCallBtg addr = lCallDef addr . btgMkParam
  let lCallBtg1000 addr = lCall1000 addr . btgMkParam
  let originate = btgOriginate

  let addShares amounts btgl =
        let xs = fmap (\(a, b) -> (#to .! a, #value .! b)) amounts in
        (withSender admin . lCallBtg btgl $ BTG.Token . BTG.MintBatch $ xs) >> return btgl

  let forceAccountUpdate btgl w = do
        withSender admin . lCallBtg btgl $ BTG.Token . BTG.Mint $ ( #to .! w , #value .! 1)
        withSender admin . lCallBtg btgl $ BTG.Token . BTG.Burn $ ( #from .! w , #value .! 1)

  let originateNatConsumer :: IntegrationalScenarioM (TAddress Natural)
        = lOriginateEmpty contractConsumer "nat consumer"

  let call contract sender = withSender sender . lCallBtg contract

  let callPaused btgl currAdmin code = do
        call btgl currAdmin $ BTG.Token . BTG.SetPause $ True
        call btgl currAdmin code
        call btgl currAdmin $ BTG.Token . BTG.SetPause $ False

  describe "Dividends" $ do

    it "DividendsOwing splits dividends equally between equal shares" $
      integrationalTestExpectation $ do
        btgl  <- ( originate 0 [w1, w2]
                 >>= addShares [ (w1, 5)
                               , (w2, 5)])

        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)

        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()

        call btgl admin $ BTG.Dividends . BTG.Disburse $ [w1, w2]
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 500)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 500)

    it "DividendsOwing with unequal shares" $
      integrationalTestExpectation $ do
        btgl  <- originate 0 [w1, w2, w3]

        withSender admin . lCallBtg btgl $ BTG.Token . BTG.Mint $ ( #to .! w1 , #value .! 10)
        withSender admin . lCallBtg btgl $ BTG.Token . BTG.Mint $ ( #to .! w2 , #value .! 30)

        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()

        call btgl admin $ BTG.Dividends . BTG.Disburse $ [w1, w2, w3]
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 250)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 750)
        validate . Right $ lExpectBalance w3 (unsafeMkMutez 0)

    it "Withdraw with a single shareholder" $
      integrationalTestExpectation $ do
        btgl  <- ( originate 0 [w1, w2]
                 >>= addShares [(w1, 1)])

        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()

        withSender w1 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 1000)

    it "Withdraw with two shareholders" $
      integrationalTestExpectation $ do
        btgl  <- ( originate 0 [w1, w2]
                 >>= addShares [ (w1, 1)
                               , (w2, 3)])

        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()

        withSender w1 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()

        validate . Right $ lExpectBalance w1 (unsafeMkMutez 250)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 0)

        withSender w2 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 250)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 750)

    it "Add dividends several times" $
      integrationalTestExpectation $ do
        btgl  <- ( originate 0 [w1, w2]
                 >>= addShares [ (w1, 1)
                               , (w2, 3)])

        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()

        -- Distribute the first portion of dividends
        withSender w1 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()
        withSender w2 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 250)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 750)

        -- Ensure Dividends contract has sent all it's funds
        validate . Right $ lExpectBalance btgl (unsafeMkMutez 0)

        -- Add 1000 more XTZ as dividends and ensure the contract doesn't send funds immediately
        withSender admin . lCallBtg1000 btgl $ BTG.Token . BTG.SetPause $ False
        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 250)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 750)

        -- Withdraw second portion of dividends
        withSender w1 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()
        withSender w2 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 500)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 1500)

    it "Add dividends several times but don't withdraw immediately" $
      integrationalTestExpectation $ do
        btgl  <- ( originate 0 [w1, w2, w3]
                 >>= addShares [ (w1, 2)
                               , (w2, 3)
                               , (w3, 5)])

        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()

        -- Distribute the first portion of dividends
        withSender w1 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 200)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 0)
        validate . Right $ lExpectBalance w3 (unsafeMkMutez 0)

        -- Ensure Dividends contract has some funds
        validate . Right $ lExpectBalance btgl (unsafeMkMutez 800)

        -- Add 1000 more XTZ as dividends and ensure the contract doesn't send funds immediately
        withSender admin . lCallBtg1000 btgl $ BTG.Token . BTG.SetPause $ False
        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1800)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 200)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 0)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 0)

        -- Withdraw second portion of dividends by first two accounts
        withSender w1 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()
        withSender w2 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 400)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 600)
        validate . Right $ lExpectBalance w3 (unsafeMkMutez 0)

        -- .. and then by the last one
        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        withSender w3 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()
        validate . Right $ lExpectBalance w3 (unsafeMkMutez 1000)
        validate . Right $ lExpectBalance btgl (unsafeMkMutez 0)

    it "Collect" $
      integrationalTestExpectation $ do
        btgl  <- ( originate 0 [w1, w2]
                 >>= addShares [(w1, 1)])

        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()

        withSender admin . lCallBtg btgl $ BTG.Token . BTG.SetAdministrator $ (#newAdmin .! w2)
        withSender w2 . lCallBtg btgl $ BTG.Token . BTG.AcceptOwnership $ ()
        withSender w2 . lCallBtg btgl $ BTG.Dividends . BTG.Collect $ ()
        validate . Right $ lExpectBalance btgl (unsafeMkMutez 0)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 1000)

        callPaused btgl w2 $ BTG.Dividends . BTG.AddDividends $ ()
        validate . Right $ expectAnySuccess

        withSender w1 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()
        let expectNotEnoughFunds (EENotEnoughFunds _ _) = True
            expectNotEnoughFunds _ = False
        validate (Left expectNotEnoughFunds)

    it "Transfer shares without pending dividends" $
      integrationalTestExpectation $ do
        btgl  <- ( originate 0 [w1, w2]
                 >>= addShares [ (w1, 5)
                               , (w2, 1)])

        -- Just play with transfer, burn, mint
        withSender w1 . lCallBtg btgl $
            BTG.Token . BTG.Transfer $ ( #from .! w1 , #to .! w2 , #value .! 1)

        withSender admin . lCallBtg btgl $
            BTG.Token . BTG.Burn $ ( #from .! w1 , #value .! 3)

        withSender admin . lCallBtg btgl $
            BTG.Token . BTG.Mint $ ( #to .! w2 , #value .! 1)

        consumer <- originateNatConsumer
        lCallBtg btgl $ BTG.Token . BTG.GetBalance $ (mkView (#owner .! w1) consumer)
        lCallBtg btgl $ BTG.Token . BTG.GetBalance $ (mkView (#owner .! w2) consumer)

        -- Shares
        validate . Right $ lExpectViewConsumerStorage consumer [1, 3]

        -- Disburse dividends
        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()
        withSender admin . lCallBtg btgl $ BTG.Dividends . BTG.Disburse $ [w1, w2]
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 250)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 750)

    it "Transfer shares with pending dividends" $
      integrationalTestExpectation $ do
        btgl  <- ( originate 0 [w1, w2]
                 >>= addShares [ (w1, 1)
                               , (w2, 3)])

        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()
        withSender w1 . lCallBtg btgl $ BTG.Dividends . BTG.Withdraw $ ()
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 250)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 0) -- but 750 is pending

        -- Play with transfer, burn, mint
        withSender w2 . lCallBtg btgl $
            BTG.Token . BTG.Transfer $ ( #from .! w2 , #to .! w1 , #value .! 2)

        withSender admin . lCallBtg btgl $
            BTG.Token . BTG.Burn $ ( #from .! w1 , #value .! 1)

        withSender admin . lCallBtg btgl $
            BTG.Token . BTG.Mint $ ( #to .! w2 , #value .! 1)

        consumer <- originateNatConsumer
        lCallBtg btgl $ BTG.Token . BTG.GetBalance $ (mkView (#owner .! w1) consumer)
        lCallBtg btgl $ BTG.Token . BTG.GetBalance $ (mkView (#owner .! w2) consumer)
        validate . Right $ lExpectViewConsumerStorage consumer [2, 2]

        -- Disburse dividends
        withSender admin . lCallBtg1000 btgl $ BTG.Token . BTG.SetPause $ False
        validate . Right $ lExpectBalance btgl (unsafeMkMutez 1750)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()
        withSender admin . lCallBtg btgl $ BTG.Dividends . BTG.Disburse $ [w1, w2]
        validate . Right $ lExpectBalance w1 (unsafeMkMutez (250 + 500))
        validate . Right $ lExpectBalance w2 (unsafeMkMutez (750 + 500))

    let makePendingDividends = do
          btgl  <- ( originate 0 [w1, w2, w3]
                    >>= addShares [ (w1, 3)
                                  , (w2, 3)
                                  , (w3, 4)])

          validate . Right $ lExpectBalance btgl (unsafeMkMutez 1000)
          callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()

          forceAccountUpdate btgl w2
          forceAccountUpdate btgl w3

          withSender admin . lCallBtg1000 btgl $ BTG.Token . BTG.SetPause $ False
          validate . Right $ lExpectBalance btgl (unsafeMkMutez 2000)
          callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()

          forceAccountUpdate btgl w2

          -- At this point knowing the internal implementation we expect accounts to have both pending
          -- money payment and lazy dividends:
          --
          -- w1 - only lazy dividends
          -- w2 - only pending payment
          -- w3 - both lazy and pending dividends
          return btgl

    it "Transfer shares with pending dividends" $
      integrationalTestExpectation $ do
        btgl <- makePendingDividends

        -- We check that dividends are distributed correctly for each state of dividendsOwing state
        withSender admin . lCallBtg1000 btgl $ BTG.Token . BTG.SetPause $ False
        validate . Right $ lExpectBalance btgl (unsafeMkMutez 3000)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()

        withSender admin . lCallBtg btgl $ BTG.Dividends . BTG.Disburse $ [w1, w2, w3]
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 900)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 900)
        validate . Right $ lExpectBalance w3 (unsafeMkMutez 1200)

    it "DividendsOwing with all kinds of pending dividends" $
      integrationalTestExpectation $ do
        btgl <- makePendingDividends

        -- We check that dividends are distributed correctly for each state of dividendsOwing state
        withSender admin . lCallBtg1000 btgl $ BTG.Token . BTG.SetPause $ False
        validate . Right $ lExpectBalance btgl (unsafeMkMutez 3000)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()

        withSender admin . lCallBtg btgl $ BTG.Dividends . BTG.Disburse $ [w1, w2, w3]
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 900)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 900)
        validate . Right $ lExpectBalance w3 (unsafeMkMutez 1200)

    it "Disburse with all kinds of pending dividends" $
      integrationalTestExpectation $ do
        btgl <- makePendingDividends

        -- We check that dividends are distributed correctly for each state of dividendsOwing state
        withSender admin . lCallBtg1000 btgl $ BTG.Token . BTG.SetPause $ False
        validate . Right $ lExpectBalance btgl (unsafeMkMutez 3000)
        callPaused btgl admin $ BTG.Dividends . BTG.AddDividends $ ()

        withSender admin . lCallBtg btgl $ BTG.Dividends . BTG.Disburse $ [w1, w2, w3]
        validate . Right $ lExpectBalance w1 (unsafeMkMutez 900)
        validate . Right $ lExpectBalance w2 (unsafeMkMutez 900)
        validate . Right $ lExpectBalance w3 (unsafeMkMutez 1200)

    it "disburse can be called only by admin" $
      integrationalTestExpectation $ do
        btgl <- originate 0 [w1, w2]

        withSender w1 . lCallBtg btgl $ BTG.Dividends . BTG.Disburse $ [w1]

        validate . Left $ lExpectCustomError_ #senderIsNotAdmin

    it "collect can be called only by admin" $
      integrationalTestExpectation $ do
        btgl <- originate 0 [w1, w2]

        withSender w1 . lCallBtg btgl $ BTG.Dividends . BTG.Collect $ ()
        validate . Left $ lExpectCustomError_ #senderIsNotAdmin

    it "addDividends can be called only by admin" $
      integrationalTestExpectation $ do
        btgl <- originate 0 [w1, w2]

        withSender w1 . lCallBtg btgl $ BTG.Dividends . BTG.AddDividends $ ()

        validate . Left $ lExpectCustomError_ #senderIsNotAdmin
