{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | Tests on generated documentation.
module Test.Lorentz.Contracts.BTG.Doc
  ( test_Documentation
  ) where

import Test.Tasty (TestTree)

import Lorentz
import Lorentz.Test

import Lorentz.Contracts.BTG

test_Documentation :: [TestTree]
test_Documentation =
  runDocTests testLorentzDoc $ buildLorentzDoc btgTokenContract
