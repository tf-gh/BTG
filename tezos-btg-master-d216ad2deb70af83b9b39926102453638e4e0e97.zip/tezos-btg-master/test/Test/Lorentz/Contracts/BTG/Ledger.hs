{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | Tests for BTG Token + Whitelist parts.

module Test.Lorentz.Contracts.BTG.Ledger
  ( spec_Ledger
  ) where

-- Import Prelude to make intero calm
import Prelude

import qualified Data.Map.Strict as Map
import Fmt (listF, (+|), (|+))
import Test.Hspec (Spec, describe, it)

import qualified Data.Set as Set
import Lorentz (VoidResult(..))
import qualified Lorentz as L
import qualified Lorentz.Contracts.BTG as BTG
import Lorentz.Contracts.Spec.ApprovableLedgerInterface as AL
import Lorentz.Test
import qualified Michelson.Test.Integrational as I
import Tezos.Address (Address)
import Util.Named ((.!))

import Test.Lorentz.Contracts.BTG.Common

{-# ANN module ("HLint: ignore Reduce duplication" :: Text) #-}

spec_Ledger :: Spec
spec_Ledger = btgLedgerSpec btgLedger

-- | A set of tests for BTG/ReitBz ledger
btgLedgerSpec :: BtgLedger BTG.Parameter -> Spec
btgLedgerSpec BtgLedger
  { btgManaged = ManagedLedger { mlApprovable = ApprovableLedger {..} , ..}
  , ..
  } = do
  let lCallBtg addr = lCallDef addr . btgMkParam

  let
    wlStorageExpectation
      :: (Maybe () -> Bool)
      -> [Address]
      -> BTG.Storage
      -> Either I.ValidationError ()
    wlStorageExpectation p expected st =
        let L.BigMap curSubmap = BTG.smWhitelist st
            lookuped =
              filter (\key ->
                        p $ Map.lookup key curSubmap
                     ) expected
        in if Set.fromList lookuped == Set.fromList expected
           then pass
           else Left . I.CustomValidationError $
              "Expected to be in whitelist " +| listF expected |+ ", but got " +|
                listF lookuped |+ ""

  let
    lExpectInWhitelist :: L.TAddress param -> [Address] -> SuccessValidator
    lExpectInWhitelist addr expected =
        lExpectStorage addr (wlStorageExpectation isJust expected)

  let
    lExpectNotInWhitelist :: L.TAddress param -> [Address] -> SuccessValidator
    lExpectNotInWhitelist addr expected =
        lExpectStorage addr (wlStorageExpectation isNothing expected)

  let
    lExpectWhitelist addr inExpected notInExpected =
      I.composeValidators
        (lExpectInWhitelist addr inExpected)
        (lExpectNotInWhitelist addr notInExpected)

  describe "Interface" $ do
    it "Follows FA1.2 specification" $
      expectContractEntrypoints @AL.Parameter BTG.btgTokenContract

  describe "Whitelist" $ do
    it "Can be expanded by admin" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 []

        withSender admin $
          lCallBtg btgl $
            BTG.Whitelist . BTG.AddToWhitelist $ wallet1

        validate . Right $
          lExpectWhitelist btgl [wallet1] [wallet2, wallet3]

    it "Can be batch expanded by admin" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 []

        withSender admin $
          lCallBtg btgl $
            BTG.Whitelist . BTG.AddToWhitelistBatch $ [wallet1, wallet2]

        validate . Right $
          lExpectWhitelist btgl [wallet1, wallet2] [wallet3]

    it "Can be expanded with element one wallet twice" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 []

        withSender admin $
         lCallBtg btgl $
           BTG.Whitelist . BTG.AddToWhitelist $ wallet1

        withSender admin $
         lCallBtg btgl $
           BTG.Whitelist . BTG.AddToWhitelist $ wallet1

        validate . Right $
          lExpectWhitelist btgl [wallet1] [wallet2, wallet3]

    it "Can be shrinked with not whitelisted wallet" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 [wallet1]

        withSender admin $
          lCallBtg btgl $
            BTG.Whitelist . BTG.RemoveFromWhitelist $ wallet2

        validate . Right $ expectNoStorageUpdates

    it "Can be shrinked by admin" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 []

        withSender admin $
          lCallBtg btgl $
            BTG.Whitelist . BTG.AddToWhitelist $ wallet1

        validate . Right $
          lExpectInWhitelist btgl [wallet1]

        withSender admin $
          lCallBtg btgl $
            BTG.Whitelist . BTG.RemoveFromWhitelist $ wallet1

        validate . Right $
          lExpectNotInWhitelist btgl [wallet1]

    it "Can be batch shrinked by admin" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 [wallet1, wallet2, wallet3]

        withSender admin $
          lCallBtg btgl $
            BTG.Whitelist . BTG.RemoveFromWhitelistBatch $ [wallet1, wallet3]

        validate . Right $
          lExpectWhitelist btgl [wallet2] [wallet1, wallet3]

    it "Must report if user from batch remove is already not present" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 [wallet1]

        withSender admin $
          lCallBtg btgl $
            BTG.Whitelist . BTG.RemoveFromWhitelistBatch $ [wallet1, wallet2, wallet3]

        validate . Left $
          lExpectCustomError #notWhitelisted [wallet2, wallet3]

    it "Can be checked by everyone" $
      integrationalTestExpectation $ do
        btgl1 <- btgOriginate 0 [wallet1]

        withSender wallet1 $
          lCallBtg btgl1 $
            BTG.Whitelist . BTG.CheckWhitelisted $ (L.mkVoid wallet2)

        validate . Left $
          lExpectError (== VoidResult False)

        withSender wallet1 $
         lCallBtg btgl1 $
           BTG.Whitelist . BTG.CheckWhitelisted $ (L.mkVoid wallet1)

        -- TODO: May be worth it to make void syntax for tests
        validate . Left $
          lExpectError (== VoidResult True)

    it "Can't be expaneded by not admin" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 []

        withSender wallet1 $
          lCallBtg btgl $
            BTG.Whitelist . BTG.AddToWhitelist $ wallet2

        validate . Left $
          lExpectCustomError_ #senderIsNotAdmin

    it "Can't be batch expaneded by not admin" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 []

        withSender wallet1 $
          lCallBtg btgl $
            BTG.Whitelist . BTG.AddToWhitelistBatch $ [wallet2]

        validate . Left $
          lExpectCustomError_ #senderIsNotAdmin

    it "Can't be shrinked by not admin" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 []

        withSender wallet1 $
          lCallBtg btgl $
            BTG.Whitelist . BTG.RemoveFromWhitelist $ wallet2

        validate . Left $
          lExpectCustomError_ #senderIsNotAdmin

    it "Can't be batch shrinked by not admin" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 []

        withSender wallet1 $
          lCallBtg btgl $
            BTG.Whitelist . BTG.RemoveFromWhitelistBatch $ [wallet2]

        validate . Left $
          lExpectCustomError_ #senderIsNotAdmin

  describe "Whitelisted wallets" $ do
    it "Can transfer tokens" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 10 [wallet1, wallet2]
        consumer <- lOriginateEmpty contractConsumer "consumer"

        withSender wallet1 $
          lCallBtg btgl $
            BTG.Token . BTG.Transfer $
              ( #from .! wallet1
              , #to .! wallet2
              , #value .! 3
              )

        lCallBtg btgl $ BTG.Token . BTG.GetBalance $ (L.mkView (#owner .! wallet1) consumer)
        lCallBtg btgl $ BTG.Token . BTG.GetBalance $ (L.mkView (#owner .! wallet2) consumer)

        validate . Right $
          lExpectViewConsumerStorage consumer [7, 13]

    it "Can approve tokens" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 10 [wallet1, wallet2]
        consumer <- lOriginateEmpty contractConsumer "consumer"

        withSender wallet1 $
          lCallBtg btgl $
            BTG.Token . BTG.Approve $
            ( #spender .! wallet2
            , #value .! 5
            )

        withSender wallet2 $
          lCallBtg btgl $
            BTG.Token . BTG.Transfer $
            ( #from .! wallet1
            , #to .! wallet2
            , #value .! 5
            )

        lCallBtg btgl $ BTG.Token . BTG.GetBalance $ (L.mkView (#owner .! wallet2) consumer)

        validate . Right $
          lExpectViewConsumerStorage consumer [15]

    it "Mint can be applied to whitelisted wallet" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 [wallet1]
        consumer <- lOriginateEmpty contractConsumer "consumer"

        withSender admin $
          lCallBtg btgl $
            BTG.Token . BTG.Mint $
              ( #to .! wallet1
              , #value .! 10
              )

        lCallBtg btgl $ BTG.Token . BTG.GetBalance $ (L.mkView (#owner .! wallet1) consumer)

        validate . Right $
          lExpectViewConsumerStorage consumer [10]

  describe "Non whitelisted wallets" $ do
    describe "Transfer can be applied only between both wallets whitelisted" $ do
      it "Transfer fails if both not whitelisted" $
        integrationalTestExpectation $ do
          btgl <- btgOriginate 10 []

          withSender wallet1 $
            lCallBtg btgl $
              BTG.Token . BTG.Transfer $
                ( #from .! wallet1
                , #to .! wallet2
                , #value .! 3
                )
          validate . Left $
            lExpectCustomError #notWhitelisted [wallet2]

      it "Transfer fails if 'from' whitelisted and 'to' non whitelised" $
        integrationalTestExpectation $ do
          btgl <- btgOriginate 10 [wallet1]

          withSender wallet1 $
            lCallBtg btgl $
              BTG.Token . BTG.Transfer $
                ( #from .! wallet1
                , #to .! wallet2
                , #value .! 3
                )
          validate . Left $
            lExpectCustomError #notWhitelisted [wallet2]

      it "Transfer fails if 'from' non whitelisted and 'to' whitelised" $
        integrationalTestExpectation $ do
          btgl <- btgOriginate 10 [wallet2]

          withSender wallet1 $
            lCallBtg btgl $
              BTG.Token . BTG.Transfer $
                ( #from .! wallet1
                , #to .! wallet2
                , #value .! 3
                )
          validate . Left $
            lExpectCustomError #notWhitelisted [wallet1]

    it "Mint fails if wallet is non whitelisted" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 10 [wallet1]

        withSender admin $
          lCallBtg btgl $
            BTG.Token . BTG.Mint $
              ( #to .! wallet2
              , #value .! 10
              )

        validate . Left $
          lExpectCustomError #notWhitelisted [wallet2]

  describe "GetPaused" $ do
    it "Should return paused state" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 10 []

        lCallBtg btgl $ BTG.Token . BTG.GetPaused $ L.mkVoid ()

        validate . Left $
          lExpectError (== VoidResult False)

    it "Should return paused state" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 10 []

        withSender admin $
          lCallBtg btgl $ BTG.Token . BTG.SetPause $ True

        lCallBtg btgl $ BTG.Token . BTG.GetPaused $ L.mkVoid ()

        validate . Left $
          lExpectError (== VoidResult True)


  describe "MintBatch" $ do
    it "MintBatch can be called only by admin" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 [wallet1, wallet2]

        withSender admin . lCallBtg btgl $
          BTG.Token . BTG.MintBatch $
          [ (#to .! wallet1, #value .! 20)
          , (#to .! wallet2, #value .! 30)
          ]

        validate . Right $ expectAnySuccess

    it "MintBatch fails when calling from non admin account" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 [wallet1, wallet2]

        lCallBtg btgl $
          BTG.Token . BTG.MintBatch $
          [ (#to .! wallet1, #value .! 20)
          , (#to .! wallet2, #value .! 30)
          ]

        validate . Left $ lExpectCustomError_ #senderIsNotAdmin

    it "MintBatch fails when one of wallets is not whitelisted" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 [wallet1]

        withSender admin . lCallBtg btgl $
          BTG.Token . BTG.MintBatch $
          [ (#to .! wallet1, #value .! 20)
          , (#to .! wallet2, #value .! 30)
          ]

        validate . Left $
          lExpectCustomError #notWhitelisted [wallet2]

    it "MintBatch adds finds to specified whitelisted wallets" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 0 [wallet1, wallet2]
        consumer <- lOriginateEmpty contractConsumer "consumer"

        withSender admin . lCallBtg btgl $
          BTG.Token . BTG.MintBatch $
          [ (#to .! wallet1, #value .! 20)
          , (#to .! wallet2, #value .! 30)
          ]

        lCallBtg btgl $ BTG.Token . BTG.GetBalance $ (L.mkView (#owner .! wallet1) consumer)
        lCallBtg btgl $ BTG.Token . BTG.GetBalance $ (L.mkView (#owner .! wallet2) consumer)

        validate . Right $ lExpectViewConsumerStorage consumer [20, 30]
