{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | Tests for the Token functionality which is not Dividend-specific

module Test.Lorentz.Contracts.BTG.Token
  ( spec_Token
  ) where

-- Import Prelude to make intero calm
import Prelude

import Test.Hspec (Spec, describe, it)

import qualified Lorentz.Contracts.BTG as BTG
import Lorentz.Test
import Util.Named ((.!))

import Test.Lorentz.Contracts.BTG.Common

{-# ANN module ("HLint: ignore Reduce duplication" :: Text) #-}

spec_Token :: Spec
spec_Token = btgTokenSpec btgLedger

btgTokenSpec :: BtgLedger BTG.Parameter -> Spec
btgTokenSpec BtgLedger
  { btgManaged = ManagedLedger { mlApprovable = ApprovableLedger {..} , ..}
  , ..
  } = do
  let lCallBtg addr param = lCallDef addr (btgMkParam param)

  describe "Paused operations" $ do
    it "Mint fails if token is paused" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 10 [wallet1]

        withSender admin . lCallBtg btgl $ BTG.Token . BTG.SetPause $ True
        withSender admin $
          lCallBtg btgl $
            BTG.Token . BTG.Mint $
              ( #to .! wallet2
              , #value .! 10
              )

        validate . Left $
          lExpectCustomError #tokenOperationsArePaused ()

    it "Burn fails if token is paused" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 10 [wallet1]

        withSender admin . lCallBtg btgl $ BTG.Token . BTG.SetPause $ True
        withSender admin $
          lCallBtg btgl $
            BTG.Token . BTG.Burn $
              ( #from .! wallet2
              , #value .! 10
              )

        validate . Left $
          lExpectCustomError #tokenOperationsArePaused ()

    it "Transfer fails if token is paused" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 10 [wallet1, wallet2]

        withSender admin . lCallBtg btgl $ BTG.Token . BTG.SetPause $ True
        withSender wallet1 $
          lCallBtg btgl $
            BTG.Token . BTG.Transfer $
              ( #from .! wallet1
              , #to .! wallet2
              , #value .! 3
              )

        validate . Left $
          lExpectCustomError #tokenOperationsArePaused ()

    it "Approve fails if token is paused" $
      integrationalTestExpectation $ do
        btgl <- btgOriginate 10 [wallet1, wallet2]

        withSender admin . lCallBtg btgl $ BTG.Token . BTG.SetPause $ True
        withSender wallet1 $
          lCallBtg btgl $
            BTG.Token . BTG.Approve $
            ( #spender .! wallet2
            , #value .! 5
            )

        validate . Left $
          lExpectCustomError #tokenOperationsArePaused ()
