{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
module Main
  ( main
  ) where

import Prelude

import Control.Lens (ix)
import qualified Data.ByteString.Char8 as BS8
import Data.List ((!!))
import qualified Data.Text.Lazy.IO as TL
import Data.Version (showVersion)
import Fmt (Buildable, Builder, fmt, pretty, (+|), (|+))
import Options.Applicative (execParser, fullDesc, header, help, helper, info, infoOption, long)

import qualified Lorentz as L
import Lorentz.Contracts.Multisig.Generic (ErrorsKind(..))
import Michelson.Runtime.GState (genesisAddress2, genesisAddress3)
import Tezos.Address (Address(..), detGenKeyAddress, mkContractAddressRaw)
import Util.IO (hSetTranslit, writeFileUtf8)
import Util.Named ((.!))

import CLI.Parser (argParser)
import qualified CLI.Parser as P
import Lorentz.Contracts.BTG (btgTokenContract)
import Lorentz.Contracts.MultisigWrapper (btgMultisigWrapper)
import qualified Lorentz.Contracts.BTG as B
import Paths_btg (version)

data TestCmd param =
  CmdContractCall Address param Text
  | CmdCheckBalance Address Text
  | CmdTransfer Address Address Text
  | CmdComment Text

type TestScenario param = [TestCmd param]

showTestScenario
  :: (Buildable param, L.NicePrintedValue param)
  => TestScenario param -> Text
showTestScenario = fmt . foldMap formatParam
  where
     formatParam
       :: (Buildable param, L.NicePrintedValue param)
       => TestCmd param -> Builder
     formatParam (CmdContractCall addr param amount) =
       "\n# " +| param |+ "\n" +|
       addr |+ " " +| amount |+ "\n" +|
       L.printLorentzValue True param |+ "\n"
     formatParam (CmdCheckBalance addr amount) = "check-balance " +| addr |+ " " +| amount |+ "\n"
     formatParam (CmdTransfer from to amount) = "transfer " +| from |+ " " +| to |+ " " +| amount |+ "\n"
     formatParam (CmdComment msg) = "\n### " +| msg |+ "\n"

main :: IO ()
main = do
  hSetTranslit stdout
  hSetTranslit stderr
  run `catchAny` (die . displayException)
  where
    run :: IO ()
    run = do
      cmd <- execParser programInfo
      case cmd of
        P.AddToWl addr -> printParam (B.Whitelist . B.AddToWhitelist $ addr)
        P.AddToWlBatch addrs -> printParam (B.Whitelist . B.AddToWhitelistBatch $ addrs)
        P.RemoveFromWl addr -> printParam (B.Whitelist . B.RemoveFromWhitelist $ addr)
        P.RemoveFromWlBatch addrs -> printParam (B.Whitelist . B.RemoveFromWhitelistBatch $ addrs)
        P.CheckWhitelisted addr -> printParam (B.Whitelist . B.CheckWhitelisted $ L.mkVoid addr)
        P.Transfer transferParam -> printParam (B.Token . B.Transfer $ transferParam)
        P.Approve approveParam -> printParam (B.Token . B.Approve $ approveParam)
        P.Contract mOut -> printContract btgTokenContract mOut
        P.MultisigWrapper mOut useCustomErrors ->
          if useCustomErrors
            then printContract (btgMultisigWrapper @'CustomErrors) mOut
            else printContract (btgMultisigWrapper @'BaseErrors) mOut
        P.Document mOut ->
          let write = maybe putStrLn writeFileUtf8 mOut
          in write B.btgTokenDocumentation
        P.Storage adminAddr ->
          TL.putStrLn $
          L.printLorentzValue True $
            B.mkStorage adminAddr [] []
        P.ParseParam param -> TL.putStrLn $ pretty param
        P.SetMintingCap amount -> printParam (B.Token . B.SetMintingCap $ amount)
        P.TestScenario P.TestScenarioOptions {..} -> do
          let
            write = maybe putStrLn writeFileUtf8 tsoOutput
          maybe (die "Not enough addresses") write $
            showTestScenario <$> mkTestScenario tsoAdmin tsoContract tsoAddresses
        P.GasTestScenario P.GasTestScenarioOptions {..} -> do
          let
            write = maybe putStrLn writeFileUtf8 gtsoOutput
          maybe (die "Not enough addresses") write $
            showTestScenario <$> mkGasTestScenario gtsoAdmin gtsoAddresses

    printContract contract mOut = maybe putStrLn writeFileUtf8 mOut $
      L.printLorentzContract False contract

    printParam = TL.putStrLn . L.printLorentzValue True


    programInfo =
      info (helper <*> versionOption <*> argParser) $
      mconcat
        [ fullDesc
        , header "BTG Token Tools"
        ]

    versionOption =
      infoOption
        ("btg-" <> showVersion version)
        (long "version" <> help "Show version")

call :: forall param. Address -> param -> TestCmd param
call a b = CmdContractCall a b "0"

call1000 :: Address -> param -> TestCmd param
call1000 a b = CmdContractCall a b "1000"

transfer :: Address -> Address -> Text -> TestCmd param
transfer a b c = CmdTransfer a b c

balance :: Address -> Text -> TestCmd param
balance a b = CmdCheckBalance a b

comment :: Text -> TestCmd param
comment a = CmdComment a

mkTestScenario :: Address -> Address -> [Address] -> Maybe (TestScenario B.Parameter)
mkTestScenario admin contract addresses = do
  addr1 <- addresses ^? ix 0
  addr2 <- addresses ^? ix 1
  addr3 <- addresses ^? ix 2
  pure
    [ comment "We require 3 empty accounts"
    , comment "Ensure all given addresses were empty and initiate them with some XTZ"
    , transfer admin addr1 "1"
    , transfer admin addr2 "1"
    , transfer admin addr3 "1"
    , balance addr1 "1"
    , balance addr2 "1"
    , balance addr3 "1"

    , comment "Dividends test"
    , call admin (B.Whitelist . B.AddToWhitelistBatch $ [addr1, addr2])
    , call admin (B.Token . B.Mint $ (#to .! addr1, #value .! 4))
    , call admin (B.Token . B.Mint $ (#to .! addr2, #value .! 6))
    , balance contract "0"
    , comment "Distribute 1000 dividends"
    , call1000 admin (B.Token . B.SetPause $ True)
    , call admin (B.Dividends . B.AddDividends $ ())
    , call admin (B.Dividends . B.Disburse $ [addr1, addr2, addr3])
    , balance addr1 "401"
    , balance addr2 "601"
    , call admin (B.Token . B.SetPause $ False)

    , comment "Whitelist test"
    , call admin (B.Whitelist . B.AddToWhitelist $ addr3)
    , call admin (B.Token . B.Mint $ (#to .! addr3, #value .! 100500))
    , call admin (B.Whitelist . B.AddToWhitelistBatch $ [admin, genesisAddress2, genesisAddress3])
    , call addr3 (B.Token . B.Transfer $ (#from addr3, #to .! genesisAddress3, #value .! 500))
    , call admin (B.Whitelist . B.RemoveFromWhitelistBatch $ [genesisAddress2])
    , call addr3 (B.Token . B.Approve $ (#spender .! admin, #value .! 500))
    , call admin (B.Token . B.Transfer $ (#from addr3, #to .! genesisAddress3, #value .! 400))

    , call admin (B.Token . B.SetAdministrator $ (#newAdmin .! addr3))
    , call addr3 (B.Token . B.Burn $ (#from genesisAddress3, #value .! 20))
    , call addr3 (B.Token . B.SetPause $ True)
    ]

mkGasTestScenario :: Address -> [Address] -> Maybe (TestScenario B.Parameter)
mkGasTestScenario admin addresses = do
  addr1 <- addresses ^? ix 0
  let addr2 = mkContractAddressRaw "-"
  let dummyAddrs = detGenKeyAddress . BS8.singleton <$> [minBound ..]
  let toMintParam addr = (#to .! addr, #value .! 1000)
  pure
    [ comment "Test on gas consumption initiated"
    , comment "Ensure given address has some funds"
    , transfer admin addr1 "1"

    , comment "Whitelist modification"
    , call admin (B.Whitelist . B.AddToWhitelist $ addr1)
    , call admin (B.Whitelist . B.RemoveFromWhitelist $ addr1)

    , comment "Whitelist modification batched"
    , call admin (B.Whitelist . B.AddToWhitelistBatch      $ [])
    , call admin (B.Whitelist . B.RemoveFromWhitelistBatch $ [])
    , call admin (B.Whitelist . B.AddToWhitelistBatch      $ (take 1 dummyAddrs))
    , call admin (B.Whitelist . B.RemoveFromWhitelistBatch $ (take 1 dummyAddrs))
    , call admin (B.Whitelist . B.AddToWhitelistBatch      $ (take 5 dummyAddrs))
    , call admin (B.Whitelist . B.RemoveFromWhitelistBatch $ (take 5 dummyAddrs))

    , comment "Prerequisites for further testing"
    , call admin (B.Whitelist . B.AddToWhitelistBatch $ [addr1, addr2] ++ take 7 dummyAddrs)

    , comment "Token operations"
    , call admin (B.Token . B.Mint     $ (#to .! addr1, #value 100))
    , call admin (B.Token . B.Burn     $ (#from .! addr1, #value 5))
    , call addr1 (B.Token . B.Transfer $ (#from .! addr1, #to .! addr2, #value 10))

    , comment "Token operations batched"
    , call admin (B.Token . B.MintBatch $ [])
    , call admin (B.Token . B.MintBatch $ [toMintParam addr1])
    , call admin (B.Token . B.MintBatch $ toMintParam <$> take 7 dummyAddrs)

    , comment "Dividends operations"
    , call admin . B.Token $  B.SetPause True
    , call1000 admin . B.Dividends $ B.AddDividends ()
    , call admin . B.Dividends . B.Disburse $ [dummyAddrs !! 5]
    , call admin . B.Dividends . B.Disburse $ take 5 dummyAddrs
    -- They don't have dividends anymore, but it shouldn't fail, just do nothing
    , call admin . B.Dividends . B.Disburse $ take 5 dummyAddrs

    -- At this point we did not disburse to `dummyAddrs !! 6` and to `addr1`.
    , call addr1 . B.Dividends $ B.Withdraw ()
    , call addr1 . B.Dividends $ B.Withdraw () -- does not fail, just does nothing
    , call admin . B.Dividends $ B.Collect  ()
    ]
