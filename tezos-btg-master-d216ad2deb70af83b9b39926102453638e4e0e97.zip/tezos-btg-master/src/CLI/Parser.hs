{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}

{-# LANGUAGE ApplicativeDo #-}

module CLI.Parser
  ( CmdLnArgs (..)
  , TestScenarioOptions (..)
  , GasTestScenarioOptions (..)
  , argParser
  ) where

import Prelude

import GHC.TypeLits (KnownSymbol, Symbol, symbolVal)

import Data.Char (toUpper)
import Fmt (pretty)
import Named (Name(..), type (:!))
import Options.Applicative
  (argument, auto, command, eitherReader, help, helper, info, long, metavar, option, progDesc,
  subparser, switch)
import qualified Options.Applicative as Opt

import Lorentz (parseLorentzValue)
import Tezos.Address (Address (..), parseAddress)
import Util.Named

import qualified Lorentz.Contracts.BTG as BTG
import qualified Lorentz.Contracts.BTG.Primitives as Primitives

data CmdLnArgs
  = AddToWl Address
  | AddToWlBatch [Address]
  | RemoveFromWl Address
  | RemoveFromWlBatch [Address]
  | CheckWhitelisted Address
  | Transfer Primitives.TransferParams
  | Approve Primitives.ApproveParams
  | Contract (Maybe FilePath)
  | MultisigWrapper (Maybe FilePath) Bool
  | Document (Maybe FilePath)
  | Storage Address
  | ParseParam BTG.Parameter
  | SetMintingCap Natural
  | TestScenario TestScenarioOptions
  | GasTestScenario GasTestScenarioOptions

data TestScenarioOptions = TestScenarioOptions
  { tsoAdmin :: Address
  , tsoContract :: Address
  , tsoOutput :: Maybe FilePath
  , tsoAddresses :: [Address]
  }

data GasTestScenarioOptions = GasTestScenarioOptions
  { gtsoAdmin :: Address
  , gtsoOutput :: Maybe FilePath
  , gtsoAddresses :: [Address]
  }

argParser :: Opt.Parser CmdLnArgs
argParser = subparser $ mconcat
  [ addToWlSubCmd
  , addToWlBatchSubCmd
  , removeFromWlSubCmd
  , removeFromWlBatchSubCmd
  , checkWhitelistedSubCmd
  , transferSubCmd
  , approveSubCmd
  , contractSubCmd
  , multisigWrapperSubCmd
  , storageSubCmd
  , documentSubCmd
  , parseParamSubCmd
  , setMintingCapCmd
  , testScenarioSubCmd
  , gasTestScenarioSubCmd
  ]
  where
    addToWlSubCmd =
      mkParamPrinter "addToWl"
      (AddToWl <$> addressArg "Address to be whitelisted")
      "AddToWhitelist"

    addToWlBatchSubCmd =
      mkParamPrinter "addToWlBatch"
      (AddToWlBatch <$> many (addressArg "Address to be whitelisted"))
      "AddToWhitelistBatch"

    removeFromWlSubCmd =
      mkParamPrinter "removeFromWl"
      (RemoveFromWl <$> addressArg "Address to be removed from whitelist")
      "RemoveFromWhitelist"

    removeFromWlBatchSubCmd =
      mkParamPrinter "removeFromWlBatch"
      (RemoveFromWlBatch <$> many (addressArg "Address to be removed from whitelist"))
      "RemoveFromWhitelistBatch"

    checkWhitelistedSubCmd =
      mkParamPrinter "checkWhitelisted"
      (CheckWhitelisted <$> addressArg "Address to be checked")
      "CheckWhitelisted"

    transferSubCmd =
      mkParamPrinter "transfer"
      (Transfer <$> transferOpts)
      "Transfer"

    transferOpts =
      (,,) <$> getParser @("from" :! Address) "Address to be withrawn from"
           <*> getParser @("to" :! Address) "Address transfered to"
           <*> getParser @("value" :! Natural) "Value to be tranfered"

    approveSubCmd =
      mkParamPrinter "approve"
      (Approve <$> approveOpts)
      "Approve"

    approveOpts =
      (,) <$> getParser @("spender" :! Address) "Address to be approved to spend"
          <*> getParser @("value" :! Natural) "Value approved to spend"

    contractSubCmd =
      mkCommandParser "contract"
      (Contract <$> outputOption)
      "Print BTG contract as Michelson value"

    multisigWrapperSubCmd =
      mkCommandParser "multisig-wrapper"
      (MultisigWrapper <$> outputOption <*> customErrorsFlag)
      "Print mutlisig wrapper for BTG contract"
      where
        customErrorsFlag = switch
          (long "use-custom-errors" <>
           help "By default multisig wrapper contract fails with 'unit' in all error cases.\n\
                \This flag will deploy the custom version of multisig wrapper\n\
                \contract with human-readable string errors.")

    documentSubCmd =
      mkCommandParser "document"
      (Document <$> outputOption)
      "Print BTG contract documentation"

    storageSubCmd =
      mkCommandParser "storage"
      (Storage <$> addressArg "Admin address")
      "Storage with specified admin"

    parseParamSubCmd =
      mkCommandParser "parseParam"
      (ParseParam <$> parameterArg)
      "Print description of specified parameter"

    setMintingCapCmd =
      mkCommandParser "setMintingCap"
      (SetMintingCap <$> naturalArg "Minting capacity")
      "Set minting capacity for a token"

    testScenarioSubCmd =
      mkCommandParser "test-scenario"
      (TestScenario <$> testScenarioOptions)
      "Print parameters for smoke testing"

    gasTestScenarioSubCmd =
      mkCommandParser "gas-test-scenario"
      (GasTestScenario <$> gasTestScenarioOptions)
      "Print parameters for gas consumption testing"

    testScenarioOptions = do
      tsoAdmin <- addressOption "admin" "Admin's address"
      tsoContract <- addressOption "contract" "Contract's address"
      tsoOutput <- outputOption
      tsoAddresses <- many $ addressOption "address" "An address that we own"
      pure TestScenarioOptions {..}

    gasTestScenarioOptions = do
      gtsoAdmin <- addressOption "admin" "Admin's address"
      gtsoOutput <- outputOption
      gtsoAddresses <- many $ addressOption "address" "An address that we own"
      pure GasTestScenarioOptions {..}

    outputOption = Opt.optional $ Opt.strOption $ mconcat
      [ Opt.short 'o'
      , Opt.long "output"
      , Opt.metavar "FILEPATH"
      , Opt.help "Output file"
      ]

mkParamPrinter
  :: String
  -> Opt.Parser a
  -> String
  -> Opt.Mod Opt.CommandFields a
mkParamPrinter cmdName parser paramName =
  mkCommandParser cmdName parser $
  "Prints Michelson representation of " <>
  paramName <> " with specified arguments"

mkCommandParser
  :: String
  -> Opt.Parser a
  -> String
  -> Opt.Mod Opt.CommandFields a
mkCommandParser commandName parser desc =
      command commandName $
      info (helper <*> parser) $
      progDesc desc

-- HasParser typeclasses copy pasted from https://github.com/serokell/tezos-btc

-- The following, HasReader/HasParser typeclasses are used to generate
-- parsers for a named fields with options name and metavars derived from
-- the name of the field itself.
--
-- | Supporting typeclass for HasParser.
class HasReader a where
  getReader :: Opt.ReadM a

instance HasReader Natural where
  getReader = auto

instance HasReader Address where
  getReader = eitherReader parseAddrDo

-- | Typeclass used to define general instance for named fields
class HasParser a where
  getParser :: String -> Opt.Parser a

instance
  (HasReader a, KnownSymbol name) =>
    HasParser ((name :: Symbol) :! a)  where
  getParser hInfo =
    let
      name = (symbolVal (Proxy @name))
    in option ((Name @name) <.!> getReader) $
         mconcat [ long name , metavar (toUpper <$> name), help hInfo ]

addressArg :: String -> Opt.Parser Address
addressArg hInfo =
  argument (eitherReader parseAddrDo) $
  mconcat
    [ metavar "ADDRESS"
    , help hInfo
    ]

naturalArg :: String -> Opt.Parser Natural
naturalArg hInfo =
  argument getReader $
  mconcat
    [ metavar "NATURAL"
    , help hInfo
    ]

addressOption :: String -> String -> Opt.Parser Address
addressOption name hInfo =
  option (Opt.eitherReader parseAddrDo) $ mconcat
  [ long name
  , metavar "ADDRESS"
  , help hInfo
  ]

parseAddrDo :: String -> Either String Address
parseAddrDo addr =
  either (Left . mappend "Failed to parse address: " . pretty) Right $
  parseAddress $ toText addr

parameterArg :: Opt.Parser BTG.Parameter
parameterArg =
  argument (eitherReader parseContractParam) $
  mconcat
    [ metavar "CONTRACT_PARAMETER"
    , help "Contract parameter represented as Michelson value"
    ]

parseContractParam :: String -> Either String BTG.Parameter
parseContractParam valueStr =
  either (Left . mappend "Failed to parse parameter: " . pretty) Right $
  parseLorentzValue @BTG.Parameter $ toText valueStr
