{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}

module Lorentz.Contracts.BTG.Dividends.Doc
  ( disburseDoc
  , withdrawDoc
  , collectDoc
  , dividendsOwingDoc
  , addDividendsDoc
  , registerSalesDoc
  ) where

import Lorentz

import Text.InterpolatedString.QM (qnb)

disburseDoc :: Markdown
disburseDoc = [qnb|
  Distribute pending dividends between the given list of shareholders.

  While sending payments it
  * skips sending 0tz transactions
  * assumes that addresses are either plain "tz..." addresses or contracts of type `contract unit`.
  |]

withdrawDoc :: Markdown
withdrawDoc = [qnb|
  Similar to the 'disburse' method but only for one account: SENDER.
  |]

collectDoc :: Markdown
collectDoc = [qnb|
  Send all funds owned by the contract to the admin.
  Keep in mind that transaction of 0tz to a non-contract address is prohibited.
  So this operation will fail if this contract's balance is 0 and the admin is not a contract with parameter `unit`.
  |]

dividendsOwingDoc :: Markdown
dividendsOwingDoc = [qnb|
  Amount of pending dividends owed to the given account.
  |]

addDividendsDoc :: Markdown
addDividendsDoc = [qnb|
  Register a new portion of dividends.
  |]

registerSalesDoc :: Markdown
registerSalesDoc = [qnb|
  Mint the given amount of shares for each given account.
  |]
