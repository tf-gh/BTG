{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}

module Lorentz.Contracts.BTG.Token.Doc
  ( pausedDoc
  , mintBatchDoc
  , setAdministratorDoc
  , acceptOwnershipDoc
  , setMintingCapDoc
  , getMintingCapDoc
  , getTotalMintedDoc
  ) where

import Lorentz

import Text.InterpolatedString.QM (qnb)

pausedDoc :: Markdown
pausedDoc = [qnb|
  Returns paused state as `Void`.
  |]

mintBatchDoc :: Markdown
mintBatchDoc = [qnb|
  Produces tokens on every account assosiated with given address in list.
  |]

setAdministratorDoc :: Markdown
setAdministratorDoc = [qnb|
  Sets a new administrator. The current administrator retains his priveleges up until `acceptOwnership` is called.
  This can be called multiple times, each call replaces pending administrator with the new one. Note, that if proposed administrator
  is the same as the current one, then the call is simply invalidated.
  |]

acceptOwnershipDoc :: Markdown
acceptOwnershipDoc = [qnb|
  Accept ownership for a pending administrator.
  |]

setMintingCapDoc :: Markdown
setMintingCapDoc = [qnb|
  Sets minting capacity for a whole token.
  |]

getMintingCapDoc :: Markdown
getMintingCapDoc = [qnb|
  Returns current minting capacity for a token.
  |]

getTotalMintedDoc :: Markdown
getTotalMintedDoc = [qnb|
  Returns current amount of minted coins for a token.
  |]
