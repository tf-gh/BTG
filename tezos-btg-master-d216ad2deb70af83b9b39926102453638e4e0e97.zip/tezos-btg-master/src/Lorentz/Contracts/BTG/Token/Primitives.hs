{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}

-- | Types shared between contracts participating in ManagedLedger.

module Lorentz.Contracts.BTG.Token.Primitives
  ( module ML
  ) where

import Lorentz.Contracts.ManagedLedger.Types as ML
  (AllowanceParams, ApproveCasParams, ApproveParams, BurnParams, GetAllowanceParams,
  GetBalanceParams, LedgerValue, MintParams, TransferParams)
