{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}

{-# OPTIONS_GHC -Wno-orphans #-}

module Lorentz.Contracts.BTG.Token.Types
  ( -- * Parameter
    SetAdministratorParams

    -- * Storage
  , StorageFields (..)
  , mkStorageFields
  , Submap
  , mkSubmap

  , StorageC

  , Deps (..)
  ) where

import Lorentz
import Prelude (fmap, snd, sum, (<$>))

import qualified Data.Map.Strict as Map
import Util.Named ((.!))

import Lorentz.Contracts.BTG.Token.Primitives

----------------------------------------------------------------------------
-- Parameter
----------------------------------------------------------------------------

type SetAdministratorParams = ("newAdmin" :! Address)

----------------------------------------------------------------------------
-- Storage
----------------------------------------------------------------------------

data StorageFields = StorageFields
  { sAdmin       :: Address
  , sNewAdmin    :: Maybe Address
  , sPaused      :: Bool
  , sTotalSupply :: Natural
  , sTotalMinted :: Natural
  , sMintCap     :: Natural
  } deriving stock Generic
    deriving anyclass IsoValue

instance (field ~ Address) =>
         StoreHasField StorageFields "admin" field where
  storeFieldOps = storeFieldOpsReferTo #sAdmin storeFieldOpsADT

instance (field ~ (Maybe Address)) =>
         StoreHasField StorageFields "newAdmin" field where
  storeFieldOps = storeFieldOpsReferTo #sNewAdmin storeFieldOpsADT

instance (field ~ Bool) =>
         StoreHasField StorageFields "paused" field where
  storeFieldOps = storeFieldOpsReferTo #sPaused storeFieldOpsADT

instance (field ~ Natural) =>
         StoreHasField StorageFields "totalSupply" field where
  storeFieldOps = storeFieldOpsReferTo #sTotalSupply storeFieldOpsADT

instance (field ~ Natural) =>
         StoreHasField StorageFields "totalMinted" field where
  storeFieldOps = storeFieldOpsReferTo #sTotalMinted storeFieldOpsADT

instance (field ~ Natural) =>
         StoreHasField StorageFields "mintCap" field where
  storeFieldOps = storeFieldOpsReferTo #sMintCap storeFieldOpsADT

-- | Create a default storage with ability to set some balances to
-- non-zero values.
mkStorageFields :: Address -> [(Address, Natural)] -> StorageFields
mkStorageFields adminAddress balances =
  StorageFields
  { sAdmin = adminAddress
  , sNewAdmin = Nothing
  , sPaused = False
  , sTotalSupply = sum $ snd <$> balances
  , sTotalMinted = 0
  , sMintCap = 1e10
  }

type Submap = BigMap Address LedgerValue

mkSubmap
  :: [(Address, Natural)] -> Submap
mkSubmap = BigMap . Map.fromList . fmap toLedgerEntry
  where
    toLedgerEntry (addr, initBal) =
      (addr, (#balance .! initBal, #approvals .! mempty))

type StorageC store =
  ( IsoValue store
  , StorageContains store
      [ "admin" := Address
      , "newAdmin" := Maybe Address
      , "paused" := Bool
      , "totalSupply" := Natural
      , "totalMinted" := Natural
      , "mintCap" := Natural
      , "ledger" := Address ~> LedgerValue
      ]
  )

----------------------------------------------------------------------------
-- Deps
----------------------------------------------------------------------------

data Deps storage = Deps
  { dUpdateAccount
      :: forall s. Address : storage : s :-> storage : s
  , dEnsureWhitelisted
      :: forall s. Text -> Address : storage : s :-> storage : s
  }

----------------------------------------------------------------------------
-- Errors
----------------------------------------------------------------------------

type instance ErrorArg "tokenOperationsAreNotPaused" = ()

type instance ErrorArg "notInTransferOwnershipMode" = ()

type instance ErrorArg "senderIsNotNewAdmin" = ()

type instance ErrorArg "mintCapExceeded" = ()

instance CustomErrorHasDoc "tokenOperationsAreNotPaused" where
  customErrClass = ErrClassActionException
  customErrDocMdCause =
    "token is not paused"

instance CustomErrorHasDoc "notInTransferOwnershipMode" where
  customErrClass = ErrClassActionException
  customErrDocMdCause =
    "Cannot accept ownership before transfer process has been initiated \
    \by calling acceptOwnership entrypoint"

instance CustomErrorHasDoc "senderIsNotNewAdmin" where
  customErrClass = ErrClassBadArgument
  customErrDocMdCause =
    "Cannot accept ownership because the sender address is different from \
    \the address passed to the acceptOwnership entrypoint previously"

instance CustomErrorHasDoc "mintCapExceeded" where
  customErrClass = ErrClassActionException
  customErrDocMdCause =
    "minting capacity exceeded"
