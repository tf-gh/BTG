{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | Token implementation.
module Lorentz.Contracts.BTG.Token.Impl
  ( ApproveCasParams
  , StorageFields (..)
  , mkStorageFields
  , Submap
  , mkSubmap

  , StorageC
  , Deps (..)

    -- * Entrypoints implementation
  , transfer
  , approve
  , approveCAS
  , getAllowance
  , getBalance
  , getTotalSupply
  , setPause
  , getPaused
  , setAdministrator
  , getAdministrator
  , acceptOwnership
  , setMintingCap
  , getMintingCap
  , getTotalMinted
  , mint
  , mintBatch
  , burn

    -- * Internal functions
  , authorizeAdmin
  , creditTo
  , checkPause
  , getBalanceInternal
  , getTotalSupplyInternal
  ) where

import Lorentz
import Lorentz.Contracts.BTG.Token.Doc
import Lorentz.Contracts.BTG.Token.Primitives
import Lorentz.Contracts.BTG.Token.Types
import qualified Lorentz.Contracts.ManagedLedger.Impl as ML

{-# ANN mint ("HLint: ignore Reduce duplication" :: Text) #-}

----------------------------------------------------------------------------
-- Entrypoints implementation
----------------------------------------------------------------------------

-- | This is a slightly more general version of 'transfer' which is
-- needed to implement 'transferViaProxy'. It does not use 'sender'.
transfer
  :: forall store. StorageC store
  => Deps store -> Entrypoint TransferParams store
transfer Deps{..} = do
  dup; dip $ do
    dup; dip $ toField #to >> dEnsureWhitelisted "to"
    dup; dip $ toField #from >> dEnsureWhitelisted "from"
    dup; dip $ toField #to >> dUpdateAccount
    toField #from >> dUpdateAccount
  ML.transfer

-- | Implementation of @approve@ entrypoint. It reuses the logic from
-- ManagedLedger and adds a check that sender and spender are both
-- whitelisted.
approve
  :: forall store. StorageC store
  => Deps store -> Entrypoint ApproveParams store
approve deps = do
  approveEnsureWhitelisted deps
  ML.approve

-- | Implementation of @approveCAS@ entrypoint. It adds an additional
-- check to @approve@: current allowance must match the expected one.
approveCAS
  :: forall store. StorageC store
  => Deps store -> Entrypoint ApproveCasParams store
approveCAS deps = do
  approveEnsureWhitelisted deps
  ML.approveCAS

getAllowance
  :: StorageC store
  => Entrypoint (View GetAllowanceParams Natural) store
getAllowance = ML.getAllowance

getBalance :: StorageC store => Entrypoint (View GetBalanceParams Natural) store
getBalance = ML.getBalance

getTotalSupply :: StorageC store => Entrypoint (View () Natural) store
getTotalSupply = ML.getTotalSupply

setPause :: StorageC store => Entrypoint Bool store
setPause = ML.setPause

getPaused :: StorageC store => Entrypoint (Void_ () Bool) store
getPaused = void_ $ do
  doc $ DDescription pausedDoc
  drop @()
  stGetField #paused

-- | Marks `newAdmin` as pending administrator. All privileges
-- are transfered when `acceptOwnership` is called.
setAdministrator
  :: forall store. StorageC store
  => Entrypoint SetAdministratorParams store
setAdministrator = do
  doc $ DDescription setAdministratorDoc
  dip authorizeAdmin
  fromNamed #newAdmin
  some
  stSetField #newAdmin
  nil; pair

-- | Accept ownership of the contract. This is only callable by
-- the address in `newAdmin` field, if it contains one.
acceptOwnership :: StorageC store => Entrypoint () store
acceptOwnership = do
  doc $ DDescription acceptOwnershipDoc
  drop @()
  stGetField #newAdmin
  ifSome (do
    -- Authorize new admin
    dup; dip $ do
      sender; eq
      if_ nop (failCustom_ #senderIsNotNewAdmin)
    -- Update necessary fields
    stSetField #admin
    none
    stSetField #newAdmin
    ) (failCustom_ #notInTransferOwnershipMode)
  nil; pair

-- | Return current administrator address.
getAdministrator :: StorageC store => Entrypoint (View () Address) store
getAdministrator = ML.getAdministrator

setMintingCap :: forall store. StorageC store => Entrypoint Natural store
setMintingCap = do
  doc $ DDescription setMintingCapDoc
  dip authorizeAdmin
  stackType @[Natural, store]
  stSetField #mintCap
  nil; pair

getMintingCap :: StorageC store => Entrypoint (Void_ () Natural) store
getMintingCap = void_ $ do
  doc $ DDescription getMintingCapDoc
  drop @()
  stGetField #mintCap

getTotalMinted :: StorageC store => Entrypoint (Void_ () Natural) store
getTotalMinted = void_ $ do
  doc $ DDescription getTotalMintedDoc
  drop @()
  stGetField #totalMinted

mint :: StorageC store => Deps store -> Entrypoint MintParams store
mint Deps{..} = do
  -- Duplicating call of 'authorizeAdmin' because this thing apparently
  -- should be checked first (there is one another call in 'ML.mint').
  dip (authorizeAdmin >> ML.ensureNotPaused)
  dup; dip (toField #to >> dEnsureWhitelisted "to")
  dup; dip (toField #to >> dUpdateAccount)
  dup; dip (toField #value >> updateTotalMinted)
  dip ensureMintCapNotExceeded

  ML.mint

mintBatch
  :: forall store. StorageC store => Deps store -> Entrypoint [MintParams] store
mintBatch Deps{..} = do
  doc $ DDescription mintBatchDoc
  dip authorizeAdmin

  iter $ do
    dup; dip (toField #to >> dEnsureWhitelisted "all accounts from list")
    dup; dip (toField #to >> dUpdateAccount)
    dup; dip (toField #value >> updateTotalMinted)

    ML.creditTo
    drop

  ensureMintCapNotExceeded
  nil; pair

burn :: StorageC store => Deps store -> Entrypoint BurnParams store
burn deps = do
  dip (authorizeAdmin >> ML.ensureNotPaused)
  dup; dip (toField #from >> dUpdateAccount deps)
  ML.burn

----------------------------------------------------------------------------
-- Helpers
----------------------------------------------------------------------------

authorizeAdmin ::
  StorageC store => store : s :-> store : s
authorizeAdmin = ML.authorizeAdmin

creditTo
  :: ( param `HasFieldsOfType` ["to" := Address, "value" := Natural]
     , StorageC store
     )
  => '[param, store] :-> '[param, store]
creditTo = ML.creditTo

checkPause :: StorageC store => Bool -> store : s :-> store : s
checkPause False = ML.ensureNotPaused
checkPause True = do
  stGetField #paused
  if_ nop (failCustom_ #tokenOperationsAreNotPaused)

updateTotalMinted
  :: StorageC store
  => Natural : store : s :-> store : s
updateTotalMinted = do
  dip (stGetField #totalMinted)
  add @Natural
  stSetField #totalMinted

ensureMintCapNotExceeded
  :: StorageC store
  => store : s :-> store : s
ensureMintCapNotExceeded = do
  stGetField #totalMinted
  dip (stGetField #mintCap)
  if IsGt then failCustom_ #mintCapExceeded else nop

getBalanceInternal
  :: StorageC store
  => Address : store : s :-> Natural : s
getBalanceInternal = do
  stGet #ledger
  ifSome (toField #balance) (push 0)

getTotalSupplyInternal
  :: StorageC store
  => store : s :-> Natural : s
getTotalSupplyInternal = stToField #totalSupply

-- Check that sender and spender are whitelisted as required by 'approve'.
approveEnsureWhitelisted
  :: forall param store.
     ( HasFieldOfType param "spender" Address
     )
  => Deps store -> '[ param, store] :-> '[ param, store]
approveEnsureWhitelisted Deps{..} = do
  dup
  dip $ do
    toField #spender >> dEnsureWhitelisted "spender"
    sender >> dEnsureWhitelisted "sender"
