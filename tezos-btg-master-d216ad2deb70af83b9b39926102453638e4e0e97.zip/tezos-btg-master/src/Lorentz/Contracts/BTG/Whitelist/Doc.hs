{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}

module Lorentz.Contracts.BTG.Whitelist.Doc
  ( DWhitelisted(..)

  , addToWhitelistDoc
  , removeFromWhitelistDoc
  , checkWhitelistedDoc
  , addToWhitelistBatchDoc
  , removeFromWhitelistBatchDoc
  ) where

import Lorentz

import Fmt (build)
import Text.InterpolatedString.QM (qnb)

import Util.Markdown

addToWhitelistDoc :: Markdown
addToWhitelistDoc = [qnb|
  Add specified account to whitelist.
  |]

removeFromWhitelistDoc :: Markdown
removeFromWhitelistDoc = [qnb|
  Remove specified account from whitelist.
  |]

checkWhitelistedDoc :: Markdown
checkWhitelistedDoc = [qnb|
  Checks if supplied account is whitelisted.
  Fails with result.
  |]

addToWhitelistBatchDoc :: Markdown
addToWhitelistBatchDoc = [qnb|
  Add specifed list of accounts to whitelist.
  |]

removeFromWhitelistBatchDoc :: Markdown
removeFromWhitelistBatchDoc = [qnb|
  Removes list of specifed accounts from whitelist.
  Fails if one or more of supplied accounts are not whitelisted.
  |]

data DWhitelisted = DWhitelisted { dWlDescription :: Text }

instance DocItem DWhitelisted where
  type DocItemPosition DWhitelisted = 55
  docItemSectionName = Nothing
  docItemToMarkdown _ DWhitelisted{..} =
    mdSubsection "Whitelist requirements" $
      "Must be whitelisted: " <> "**" <> build dWlDescription <> "**" <> "."
