{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
module Lorentz.Contracts.MultisigWrapper
  ( btgMultisigWrapper
  ) where

import Lorentz

import Data.Typeable as T

import Lorentz.Contracts.BTG
import Lorentz.Contracts.Multisig.Generic (ErrorHandler, ErrorsKind(..))
import qualified Lorentz.Contracts.Multisig.Specialized as MSig

btgMultisigWrapper
  :: forall (e :: ErrorsKind). (ErrorHandler e, Typeable e)
  => Contract (MSig.Parameter Parameter Parameter) MSig.Storage
btgMultisigWrapper =
  MSig.specializedMultisigContract @Parameter @Parameter @e @_ CallDefault
