{- SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
-- | BTG Token.
--
-- The main feature of the token is an efficient implementation of dividend payments. An efficient
-- implementation means that the dividend payment is split into several steps and it uses
-- computation amortization which helps to meet GAS requirements. Amortization of computations looks
-- like this: distribution of a new portion of dividends doesn't update a state associated with of
-- each account right away. Instead, it updates only some state common for all account. Dividends
-- for each account are computed only by an explicit request to withdraw dividends or when the
-- amount of shares for the account should be changed.
--
-- All formulas behind this implementation are described in [the document](./docs/dividends.pdf). In
-- short, 'addDividends' method accumulates @(newDividends / totalSupply)@ value in the
-- 'totalDividendPoints'. Increasing 'totalDividendPoints' means that all shareholders own some new
-- dividends. Amount of "unclaimed" or "pending" dividends is determined as new dividend points of
-- an account multiplied by its the amount of shares. 'lastDividendPoints' value associated with
-- each account allows keeping track of new dividends points (and hence, new pending dividends) for
-- each account.
--
-- The Token API is used to keep track of shares.
--
-- To change the amount of shares for an account the implementation should force computation of
-- pending dividends for that account. This is done internally by the 'updateAccount' method and all
-- methods which modify shares has appropriate 'updateAccount' calls in place. However,
-- 'updateAccount' doesn't send any transactions to pay money, instead, it accumulates the amount of
-- already computed but not yet paid dividends in the 'pendingPayment' mapping.
--
-- The typical usage of the contract to distribute dividends:
--
-- 1. send the desired amount of XTZ to the contract
-- 2. call @addDividends@ method
-- 3. call @disburse@ or @withdraw@ to send XTZ to the requested accounts.
module Lorentz.Contracts.BTG
  ( Parameter (..)
  , DividendsParameter (..)
  , TokenParameter (..)
  , WhitelistParameter (..)

  , Storage (..)
  , mkStorage
  , btgTokenContract
  , btgTokenDocumentation

  , module Lorentz.Contracts.BTG.Primitives
  ) where

import Lorentz
import Prelude (LText)

import qualified Data.Map.Strict as Map
import Fmt (Buildable(..), listF, listF', tupleF, (+|), (|+))

import Lorentz.Macro (buildViewTuple)
import qualified Michelson.Doc as Doc
import Michelson.Optimizer (OptimizerConf(..))
import Util.Instances ()
import Util.Named ()

import Lorentz.Contracts.BTG.Common
import qualified Lorentz.Contracts.BTG.Dividends as Dividends
import Lorentz.Contracts.BTG.Doc
import Lorentz.Contracts.BTG.Primitives
import qualified Lorentz.Contracts.BTG.Token as Token
import qualified Lorentz.Contracts.BTG.Whitelist as Whitelist

{-# ANN module ("HLint: ignore Reduce duplication" :: Text) #-}

----------------------------------------------------------------------------
-- Parameter
----------------------------------------------------------------------------

data DividendsParameter
  = Disburse     [Address]
  | Withdraw     ()
  | Collect      ()
  | AddDividends ()
  deriving stock Generic
  deriving anyclass IsoValue

data TokenParameter
  = Transfer         TransferParams
  | Approve          ApproveParams
  | ApproveCAS       Token.ApproveCasParams
  | GetAllowance     (View GetAllowanceParams Natural)
  | GetBalance       (View GetBalanceParams Natural)
  | GetTotalSupply   (View () Natural)
  | SetPause         Bool
  | GetPaused        (Void_ () Bool)
  | SetAdministrator Token.SetAdministratorParams
  | GetAdministrator (View () Address)
  | SetMintingCap    Natural
  | GetMintingCap    (Void_ () Natural)
  | GetTotalMinted   (Void_ () Natural)
  | Mint             MintParams
  | MintBatch        [MintParams]
  | Burn             BurnParams
  | AcceptOwnership  ()
  deriving stock Generic
  deriving anyclass IsoValue

data WhitelistParameter
  = AddToWhitelist           Address
  | RemoveFromWhitelist      Address
  | CheckWhitelisted         (Void_ Address Bool)
  | AddToWhitelistBatch      (List Address)
  | RemoveFromWhitelistBatch (List Address)
  deriving stock Generic
  deriving anyclass IsoValue

data Parameter
  = Dividends DividendsParameter
  | Token     TokenParameter
  | Whitelist WhitelistParameter
  deriving stock Generic
  deriving anyclass IsoValue

instance Buildable Parameter where
  build = \case
    Dividends dv -> case dv of
      Disburse params ->
        "Disburse (#accounts :! " +| listF params |+ ")"
      Withdraw () ->
        "Withdraw ()"
      Collect () ->
        "Collect ()"
      AddDividends () ->
        "AddDividends ()"
    Token t -> case t of
      Transfer params ->
        "Transfer " +| tupleF params |+ ""
      Approve params ->
        "Approve " +| tupleF params |+ ""
      ApproveCAS params ->
        "ApproveCAS " +| tupleF params |+ ""
      GetAllowance view ->
        "GetAllowance " +| buildViewTuple view |+ ""
      GetBalance view ->
        "GetBalance " +| view |+ ""
      GetTotalSupply view ->
        "GetTotalSupply " +| view |+ ""
      SetPause bool ->
        "SetPause " +| bool |+ ""
      GetPaused _ ->
        "GetPaused"
      SetAdministrator addr ->
        "SetAdministrator " +| addr |+ ""
      GetAdministrator view ->
        "GetAdministrator " +| view |+ ""
      SetMintingCap cap ->
        "SetMintingCap " +| cap |+ ""
      GetMintingCap _ ->
        "GetMintingCap"
      GetTotalMinted _ ->
        "GetTotalMinted"
      Mint params ->
        "Mint " +| tupleF params |+ ""
      MintBatch params ->
        "MintBatch " +| listF' tupleF params |+ ""
      Burn params ->
        "Burn " +| tupleF params |+ ""
      AcceptOwnership () ->
        "AcceptOwnership ()"
    Whitelist wl -> case wl of
      AddToWhitelist addr ->
        "AddToWitelist " +| addr |+ ""
      RemoveFromWhitelist addr ->
        "RemoveFromWhitelist " +| addr |+ ""
      CheckWhitelisted void ->
        "CheckWhitelisted " +| void |+ ""
      AddToWhitelistBatch lst ->
        "AddToWhitelistBatch " +| listF lst |+ ""
      RemoveFromWhitelistBatch lst ->
        "RemoveFromWhitelistBatch " +| listF lst |+ ""

instance TypeHasDoc DividendsParameter where
  typeDocName _ = "Parameter.DividendsParameter"
  typeDocMdDescription = "Parameter that specifies entrypoints for Dividends."
  typeDocMdReference tp =
    customTypeDocMdReference ("Parameter.DividendsParameter", DType tp) []
  typeDocHaskellRep = homomorphicTypeDocHaskellRep
  typeDocMichelsonRep = homomorphicTypeDocMichelsonRep
  typeDocDependencies = genericTypeDocDependencies

instance TypeHasDoc TokenParameter where
  typeDocName _ = "Parameter.TokenParameter"
  typeDocMdDescription = "Parameter that specifies entrypoints for a token."
  typeDocMdReference tp =
    customTypeDocMdReference ("Parameter.TokenParameter", DType tp) []
  typeDocHaskellRep = homomorphicTypeDocHaskellRep
  typeDocMichelsonRep = homomorphicTypeDocMichelsonRep
  typeDocDependencies = genericTypeDocDependencies

instance TypeHasDoc WhitelistParameter where
  typeDocName _ = "Parameter.WhitelistParameter"
  typeDocMdDescription = "Parameter that specifies entrypoints for token whitelist."
  typeDocMdReference tp =
    customTypeDocMdReference ("Parameter.WhitelistParameter", DType tp) []
  typeDocHaskellRep = homomorphicTypeDocHaskellRep
  typeDocMichelsonRep = homomorphicTypeDocMichelsonRep
  typeDocDependencies = genericTypeDocDependencies

----------------------------------------------------------------------------
-- Storage
----------------------------------------------------------------------------

data Storage = Storage
  {
    -- Storage maps
    smToken :: Token.Submap
  , smWhitelist :: Whitelist.Submap
  , smDividends :: Dividends.Submaps
  , smEntrypoints :: BigMap MText ByteString

    -- Storage fields
  , sfToken :: Token.StorageFields
  , sfDividends :: Dividends.StorageFields
  } deriving stock Generic
    deriving anyclass IsoValue

-- | Create a default storage with ability to set some balances to
-- non-zero values and whitelist some addresses.
mkStorage :: Address -> [(Address, Natural)] -> [Address] -> Storage
mkStorage adminAddress balances whitelist = Storage
  { smToken = Token.mkSubmap balances
  , smWhitelist = Whitelist.mkSubmap whitelist
  , smDividends = Dividends.mkSubmaps
  , smEntrypoints = BigMap . Map.fromList $
    [ storedCodeToPair (Dividends.updateAccountLogic dividendsDeps)
    , storedCodeToPair (Dividends.disburseOneLogic @Storage)
    ]

  , sfToken = Token.mkStorageFields adminAddress balances
  , sfDividends = Dividends.mkStorageFields
  }

-- Instances for submaps

instance (key ~ Address, value ~ LedgerValue) =>
  StoreHasSubmap Storage "ledger" key value where
  storeSubmapOps = storeSubmapOpsDeeper #smToken

instance (key ~ Address, value ~ ()) =>
  StoreHasSubmap Storage "whitelist" key value where
  storeSubmapOps = storeSubmapOpsDeeper #smWhitelist

instance (key ~ Address, value ~ Natural) =>
  StoreHasSubmap Storage "lastDividendPoints" key value where
  storeSubmapOps = storeSubmapOpsDeeper #smDividends

instance (key ~ Address, value ~ Natural) =>
  StoreHasSubmap Storage "pendingPayment" key value where
  storeSubmapOps = storeSubmapOpsDeeper #smDividends

instance (key ~ MText, value ~ ByteString) =>
  StoreHasSubmap Storage "entrypoints" key value where
  storeSubmapOps = storeSubmapOpsDeeper #smEntrypoints

-- Instances for fields

instance StoreHasField Token.StorageFields "admin" field =>
         StoreHasField Storage "admin" field where
  storeFieldOps = storeFieldOpsDeeper #sfToken

instance StoreHasField Token.StorageFields "newAdmin" field =>
         StoreHasField Storage "newAdmin" field where
  storeFieldOps = storeFieldOpsDeeper #sfToken

instance StoreHasField Token.StorageFields "paused" field =>
         StoreHasField Storage "paused" field where
  storeFieldOps = storeFieldOpsDeeper #sfToken

instance StoreHasField Token.StorageFields "totalSupply" field =>
         StoreHasField Storage "totalSupply" field where
  storeFieldOps = storeFieldOpsDeeper #sfToken

instance StoreHasField Token.StorageFields "totalMinted" field =>
         StoreHasField Storage "totalMinted" field where
  storeFieldOps = storeFieldOpsDeeper #sfToken

instance StoreHasField Token.StorageFields "mintCap" field =>
         StoreHasField Storage "mintCap" field where
  storeFieldOps = storeFieldOpsDeeper #sfToken

instance StoreHasField Dividends.StorageFields "totalDividendPoints" field =>
         StoreHasField Storage "totalDividendPoints" field where
  storeFieldOps = storeFieldOpsDeeper #sfDividends

instance StoreHasField Dividends.StorageFields "totalUnclaimedDividends" field =>
         StoreHasField Storage "totalUnclaimedDividends" field where
  storeFieldOps = storeFieldOpsDeeper #sfDividends

----------------------------------------------------------------------------
-- Implementation
----------------------------------------------------------------------------

btgTokenContract :: Contract Parameter Storage
btgTokenContract =
  optimizeLorentzWithConf (def {gotoValues = True}) btgTokenContractRaw

btgTokenContractRaw :: Contract Parameter Storage
btgTokenContractRaw = contractName "BTG Token" $ do
  doc $ DDescription btgTokenContractDoc
  doc $ $mkDGitRevision btgRepoSettings
  unpair
  entryCase @Parameter (Proxy @PlainEntryPointsKind)
    ( #cDividends /-> do
        doc $ DDescription
          "Entrypoint for contract dividends."
        dividendsEntrypoint
    , #cToken /-> do
        doc $ DDescription
          "Entrypoint for contract token."
        tokenEntrypoint
    , #cWhitelist /-> do
        doc $ DDescription
          "Entrypoint for contract whitelist."
        whitelistEntrypoint
    )

dividendsEntrypoint :: Entrypoint DividendsParameter Storage
dividendsEntrypoint =
  entryCase @DividendsParameter (Proxy @PlainEntryPointsKind)
    ( #cDisburse /-> Dividends.disburse dividendsDeps
    , #cWithdraw /-> Dividends.withdraw dividendsDeps
    , #cCollect /-> Dividends.collect dividendsDeps
    , #cAddDividends /-> Dividends.addDividends dividendsDeps
    )

tokenEntrypoint :: Entrypoint TokenParameter Storage
tokenEntrypoint =
  entryCase @TokenParameter (Proxy @PlainEntryPointsKind)
    ( #cTransfer /-> Token.transfer tokenDeps
    , #cApprove /-> Token.approve tokenDeps
    , #cApproveCAS /-> Token.approveCAS tokenDeps
    , #cGetAllowance /-> Token.getAllowance
    , #cGetBalance /-> Token.getBalance
    , #cGetTotalSupply /-> Token.getTotalSupply
    , #cSetPause /-> Token.setPause
    , #cGetPaused /-> Token.getPaused
    , #cSetAdministrator /-> Token.setAdministrator
    , #cGetAdministrator /-> Token.getAdministrator
    , #cSetMintingCap /-> Token.setMintingCap
    , #cGetMintingCap /-> Token.getMintingCap
    , #cGetTotalMinted /-> Token.getTotalMinted
    , #cMint /-> Token.mint tokenDeps
    , #cMintBatch /-> Token.mintBatch tokenDeps
    , #cBurn /-> Token.burn tokenDeps
    , #cAcceptOwnership /-> Token.acceptOwnership
    )

whitelistEntrypoint :: Entrypoint WhitelistParameter Storage
whitelistEntrypoint =
  entryCase @WhitelistParameter (Proxy @PlainEntryPointsKind)
    ( #cAddToWhitelist /-> Whitelist.addToWhitelist whitelistDeps
    , #cRemoveFromWhitelist /-> Whitelist.removeFromWhitelist whitelistDeps
    , #cCheckWhitelisted /-> Whitelist.checkWhitelisted
    , #cAddToWhitelistBatch /-> Whitelist.addToWhitelistBatch whitelistDeps
    , #cRemoveFromWhitelistBatch /-> Whitelist.removeFromWhitelistBatch whitelistDeps
    )

----------------------------------------------------------------------------
-- Dependencies
----------------------------------------------------------------------------

whitelistDeps :: Whitelist.Deps Storage
whitelistDeps = Whitelist.Deps
  { Whitelist.dAuthorizeAdmin = Token.authorizeAdmin
  }

tokenDeps :: Token.Deps Storage
tokenDeps = Token.Deps
  { Token.dEnsureWhitelisted = Whitelist.ensureWhitelisted
  , Token.dUpdateAccount = Dividends.updateAccount dividendsDeps
  }

dividendsDeps :: Dividends.Deps Storage
dividendsDeps = Dividends.Deps
  { Dividends.dAuthorizeAdmin = Token.authorizeAdmin
  , Dividends.dGetBalance = Token.getBalanceInternal
  , Dividends.dGetTotalSupply = Token.getTotalSupplyInternal
  , Dividends.dCreditTo = Token.creditTo
  , Dividends.dCheckPause = Token.checkPause
  , Dividends.dEnsureWhitelisted = Whitelist.ensureWhitelisted
  }

----------------------------------------------------------------------------
-- Misc
----------------------------------------------------------------------------

instance ParameterHasEntryPoints Parameter where
  type ParameterEntryPointsDerivation Parameter = EpdRecursive

btgTokenDocumentation :: LText
btgTokenDocumentation =
  Doc.contractDocToMarkdown $ buildLorentzDoc btgTokenContract
