<!--
 - SPDX-FileCopyrightText: 2019 BTG Pactual
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -->

# BTG

BTG is a secure token on Tezos blockchain implemented using Morley framework and
Haskell programming language.

There is a [specification](/docs/specification.md) for the required smart contract.
Currently this specification is fully implemented in the contract.

Also see [contract API](https://github.com/serokell/tezos-btg/blob/autodoc/master/BTG-contract.md).

## Build Instructions [↑](#btg)

You can use `stack build` to build `btg` executable.

## Usage [↑](#btg)

Run `stack exec -- btg --help` to see available commands.

## Issue Tracker [↑](#btg)

We use [YouTrack](https://issues.serokell.io/issues/BTG)

## For Contributors [↑](#btg)

Please see [CONTRIBUTING.md](CONTRIBUTING.md) for more information.

## License

© 2019 BTG Pactual, all rights reserved.
