### Config

Obelisk projects should contain a config folder with the following subfolders: common, frontend, and backend.

Things that should never be transmitted to the frontend belong in backend/ (e.g., email credentials)

Frontend-only configuration belongs in frontend/.

Shared configuration files (e.g., the route config) belong in common/
