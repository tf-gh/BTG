{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Frontend.Watch where

import Control.Monad.Fix (MonadFix)
import Data.Map.Monoidal (MonoidalMap)
import qualified Data.Map.Monoidal as MMap
import Data.Maybe (fromMaybe, listToMaybe)
import Data.Semigroup
import Database.Id.Class
import Reflex
import Rhyolite.Frontend.App
import Rhyolite.SemiMap
import Tezos.Common.Base58Check

import Common.App
import Common.Schema

watchAllBtgUsers
  :: (Reflex t, MonadQuery t (BTGViewSelector SelectedCount) m, MonadHold t m, MonadFix m)
  => Dynamic t UserInfoQuery -> m (Dynamic t (MonoidalMap (Id UserInfo) (Maybe UserInfoView)))
watchAllBtgUsers q = do
  dynV <- watchViewSelector $ ffor q $ \q' -> mempty
    { _btgViewSelector_userInfo = MMap.singleton q' (1 :: SelectedCount) }
  let queryRes = (MMap.lookup UserInfoQuery_AllUsers . _btgView_userInfo) <$> dynV
      mUserMap = ffor queryRes $ \case
        Just (viewVal :: (SelectedCount, SemiMap (Id UserInfo) (Maybe UserInfoView))) -> getComplete $ snd viewVal
        Nothing -> Nothing
  return $ fmap (fromMaybe MMap.empty) mUserMap

watchBtgUser
  :: (Reflex t, MonadQuery t (BTGViewSelector SelectedCount) m, MonadHold t m, MonadFix m)
  => Dynamic t UserInfoQuery -> m (Dynamic t (MonoidalMap (Id UserInfo) (Maybe UserInfoView)))
watchBtgUser q = do
  dynV <- watchViewSelector $ ffor q $ \q' -> mempty
    { _btgViewSelector_userInfo = MMap.singleton q' (1 :: SelectedCount) }
  let queryRes = (listToMaybe . MMap.elems . _btgView_userInfo) <$> dynV
      mUserMap = ffor queryRes $ \case
        Just (viewVal :: (SelectedCount, SemiMap (Id UserInfo) (Maybe UserInfoView))) -> getComplete $ snd viewVal
        Nothing -> Nothing
  return $ fmap (fromMaybe MMap.empty) mUserMap

watchTokenInfo
  :: (Reflex t, MonadQuery t (BTGViewSelector SelectedCount) m, MonadHold t m, MonadFix m)
  => Dynamic t TokenInfoQuery -> m (Dynamic t (First (Maybe TokenInfo)))
watchTokenInfo q = do
  dynV <- watchViewSelector $ ffor q $ \q' -> mempty
    { _btgViewSelector_tokenInfo = MMap.singleton q' (1 :: SelectedCount) }
  let queryRes = MMap.lookup TokenInfoQuery_Token . _btgView_tokenInfo <$> dynV
  return $ ffor queryRes $ \case
    Just (viewVal :: (SelectedCount, First (Maybe TokenInfo))) -> snd viewVal
    Nothing -> First Nothing

watchAuthorizedKeys
  :: (Reflex t, MonadQuery t (BTGViewSelector SelectedCount) m, MonadHold t m, MonadFix m)
  => Dynamic t AuthorizedKeysQuery -> m (Dynamic t (First (Maybe AuthorizedKeys)))
watchAuthorizedKeys q = do
  dynV <- watchViewSelector $ ffor q $ \q' -> mempty
    { _btgViewSelector_authorizedKeys = MMap.singleton q' (1 :: SelectedCount) }
  let queryRes = MMap.lookup AuthorizedKeysQuery_ActiveKeys . _btgView_authorizedKeys<$> dynV
  return $ ffor queryRes $ \case
    Just (viewVal :: (SelectedCount, First (Maybe AuthorizedKeys))) -> snd viewVal
    Nothing -> First Nothing

watchIsValidSession
  :: (Reflex t, MonadQuery t (BTGViewSelector SelectedCount) m, MonadHold t m, MonadFix m)
  => Dynamic t LoginSessionQuery -> m (Dynamic t (First Bool))
watchIsValidSession dynQ = do
  dynV <- watchViewSelector $ ffor dynQ $ \q -> mempty
    { _btgViewSelector_loginSession = MMap.singleton q (1 :: SelectedCount) }
  let queryRes = (\(q, v) -> MMap.lookup q . _btgView_loginSession $ v) <$> zipDyn dynQ dynV
  return $ ffor queryRes $ \case
    Just (viewVal :: (SelectedCount, First Bool)) -> snd viewVal
    Nothing -> First False

watchPendingOperations
  :: (Reflex t, MonadQuery t (BTGViewSelector SelectedCount) m, MonadHold t m, MonadFix m)
  => Dynamic t PendingOperationsQuery -> m (Dynamic t (MonoidalMap (Id PendingOperation) PendingOperation))
watchPendingOperations q = do
  dynV <- watchViewSelector $ ffor q $ \q' -> mempty
    { _btgViewSelector_pendingOperations = MMap.singleton q' (1 :: SelectedCount) }
  let queryRes = (MMap.lookup PendingOperationsQuery_Pending . _btgView_pendingOperations) <$> dynV
      mUserMap = ffor queryRes $ \case
        Just (viewVal :: (SelectedCount, SemiMap (Id PendingOperation) PendingOperation)) -> getComplete $ snd viewVal
        Nothing -> Nothing
  return $ fmap (fromMaybe MMap.empty) mUserMap

watchOperationSignature
  :: (Reflex t, MonadQuery t (BTGViewSelector SelectedCount) m, MonadHold t m, MonadFix m)
  => Dynamic t OperationSignatureQuery -> m (Dynamic t (MonoidalMap (Id OperationSignature) OperationSignature))
watchOperationSignature q = do
  dynV <- watchViewSelector $ ffor q $ \q' -> mempty
    { _btgViewSelector_operationSignature = MMap.singleton q' (1 :: SelectedCount) }
  let queryRes = (listToMaybe . MMap.toList . _btgView_operationSignature) <$> dynV
      mmapOpSig = ffor queryRes $ \case
        Just (viewVal :: (OperationSignatureQuery, (SelectedCount, SemiMap (Id OperationSignature) OperationSignature))) -> getComplete $ snd $ snd viewVal
        Nothing -> Nothing
  return $ fmap (fromMaybe MMap.empty) mmapOpSig

watchSigningInfo
  :: (Reflex t, MonadQuery t (BTGViewSelector SelectedCount) m, MonadHold t m, MonadFix m)
  => Dynamic t SigningInfoQuery -> m (Dynamic t (First (Maybe SigningInfo)))
watchSigningInfo dynQ = do
  dynV <- watchViewSelector $ ffor dynQ $ \q -> mempty
    { _btgViewSelector_signingInfo = MMap.singleton q (1 :: SelectedCount) }
  let queryRes = (\(q, v) -> MMap.lookup q . _btgView_signingInfo $ v) <$> zipDyn dynQ dynV
  return $ ffor queryRes $ \case
    Just (viewVal :: (SelectedCount, First (Maybe SigningInfo))) -> snd viewVal
    Nothing -> First Nothing

watchPastOperations
  :: (Reflex t, MonadQuery t (BTGViewSelector SelectedCount) m, MonadHold t m, MonadFix m)
  => Dynamic t PastOperationsQuery -> m (Dynamic t (MonoidalMap OperationHash PastOperation))
watchPastOperations dynQ = do
  dynV <- watchViewSelector $ ffor dynQ $ \q -> mempty
    { _btgViewSelector_pastOperations = MMap.singleton q (1 :: SelectedCount) }
  let queryRes = (\(q, v) -> MMap.lookup q . _btgView_pastOperations $ v) <$> zipDyn dynQ dynV
      mPastOpsMap = ffor queryRes $ \case
        Just (viewVal :: (SelectedCount, SemiMap OperationHash PastOperation)) -> getComplete $ snd viewVal
        Nothing -> Nothing
  return $ fmap (fromMaybe MMap.empty) mPastOpsMap
