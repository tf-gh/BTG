{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}

module Frontend.OperationText where

import qualified Data.List as List
import Data.Text (Text)
import qualified Data.Text as T
import Data.Traversable (for)
import Reflex.Dom.Core
import Reflex.Dom.SemanticUI (UI)
import Tezos.Multisig.Schema
import Tezos.Token.Schema
import Tezos.V005.Contract
import Tezos.V005.Types (toPublicKeyHashText)

data OperationText = OperationText
  { _operationText_short :: Text
  , _operationText_definition :: Text
  , _operationText_details :: Maybe Text
  }

lookupOperationText :: MultisigPayload -> OperationText
lookupOperationText = \case
  MultisigPayload_Call _ tokenOperation ->
    lookupTokenOperationText tokenOperation
  MultisigPayload_Reconfig _ _ ->
    multisigReconfigText

lookupTokenOperationText :: TokenOperation -> OperationText
lookupTokenOperationText = \case
  SetPause True -> pauseOperationText
  SetPause False -> resumeOperationText
  Mint _ _ -> mintOperationText
  Transfer _ _ _ -> transferOperationText
  AddToWhitelist _ -> addToWhitelistText
  AddToWhitelistBatch _ -> addToWhitelistBatchText
  RemoveFromWhitelist _ -> removeFromWhitelistText
  RemoveFromWhitelistBatch _ -> removeFromWhitelistBatchText
  Burn _ _ -> burnOperationText

pauseOperationText :: OperationText
pauseOperationText = OperationText
  { _operationText_short = "Pause Contract"
  , _operationText_definition = "Pausing this contract will stop all transfers and approval operations."
  , _operationText_details = Just "Signatures for other operations can still be collected during the pause. If an operation receives enough signatures it will be processed after the contract is unpaused."
  }

resumeOperationText :: OperationText
resumeOperationText = OperationText
  { _operationText_short = "Resume Contract"
  , _operationText_definition = "Resuming this contract will allow transfers and approval operations to resume."
  , _operationText_details = Just "Operations that have collected 3 signatures will be processed immediately after the contract is resumed."
  }

mintOperationText :: OperationText
mintOperationText = OperationText
  { _operationText_short = "Mint Tokens"
  , _operationText_definition = "Minting Tokens delivers a specific amount of new tokens to a specific address."
  , _operationText_details = Nothing
  }

transferOperationText :: OperationText
transferOperationText = OperationText
  { _operationText_short = "Transfer Tokens"
  , _operationText_definition = "Transfer Tokens from the Multi-signature contract to another address."
  , _operationText_details = Nothing
  }

addToWhitelistText :: OperationText
addToWhitelistText = OperationText
  { _operationText_short = "Whitelist an Address"
  , _operationText_definition = "Add an address to the token contract Whitelist."
  , _operationText_details = Nothing
  }

addToWhitelistBatchText :: OperationText
addToWhitelistBatchText = OperationText
  { _operationText_short = "Add to Whitelist"
  , _operationText_definition = "Add addresses to the token contract Whitelist."
  , _operationText_details = Just "Paste the list of addresses you’d like to add into the textbox below.\nOne address per line."
  }

removeFromWhitelistText :: OperationText
removeFromWhitelistText = OperationText
  { _operationText_short = "Remove from Whitelist"
  , _operationText_definition = "Remove addresses from the token contract Whitelist."
  , _operationText_details = Nothing
  }

removeFromWhitelistBatchText :: OperationText
removeFromWhitelistBatchText = OperationText
  { _operationText_short = "Remove from Whitelist"
  , _operationText_definition = "Remove addresses from the token contract Whitelist."
  , _operationText_details = Just "Paste the list of addresses you’d like to add into the textbox below.\nOne address per line."
  }

burnOperationText :: OperationText
burnOperationText = OperationText
  { _operationText_short = "Burn Tokens"
  , _operationText_definition = "Burning Tokens removes and destroys a specific amount of tokens from a specific address."
  , _operationText_details = Nothing
  }

multisigReconfigText :: OperationText
multisigReconfigText = OperationText
  { _operationText_short = "Update Multi-Signature List"
  , _operationText_definition = "Update the multi-signature signers list."
  , _operationText_details = Nothing
  }

data FormattedText
  = FormattedText_Plain Text
  | FormattedText_Bold Text
  | FormattedText_LineBreak

renderDescription :: UI t m => MultisigPayload -> m ()
renderDescription payload = renderFormattedText $
  case payload of
    MultisigPayload_Call _ tokenOperation ->
      case tokenOperation of
        SetPause True ->
          [ FormattedText_Plain "Pause contract." ]
        SetPause False ->
          [ FormattedText_Plain "Resume contract." ]
        Mint amount address ->
          [ FormattedText_Plain "Mint "
          , FormattedText_Bold (T.pack (show amount))
          , FormattedText_Plain " to "
          , FormattedText_Bold (toContractIdText address)
          ]
        Transfer amount from to ->
          [ FormattedText_Plain "Transfer "
          , FormattedText_Bold (T.pack (show amount))
          , FormattedText_Plain " from "
          , FormattedText_Bold (toContractIdText from)
          , FormattedText_Plain " to "
          , FormattedText_Bold (toContractIdText to)
          ]
        AddToWhitelist address ->
          [ FormattedText_Plain "Add "
          , FormattedText_Bold (toContractIdText address)
          , FormattedText_Plain " to whitelist"
          ]
        AddToWhitelistBatch addresses ->
          [ FormattedText_Plain "Add "
          , FormattedText_Bold (T.pack (show (length addresses)) <> " Addresses")
          , FormattedText_Plain " to whitelist"
          ]
        RemoveFromWhitelist address ->
          [ FormattedText_Plain "Remove "
          , FormattedText_Bold (toContractIdText address)
          , FormattedText_Plain " from whitelist"
          ]
        RemoveFromWhitelistBatch addresses ->
          [ FormattedText_Plain "Remove "
          , FormattedText_Bold (T.pack (show (length addresses)) <> " Addresses")
          , FormattedText_Plain " from whitelist"
          ]
        Burn amount address ->
          [ FormattedText_Plain "Burn "
          , FormattedText_Bold (T.pack (show amount))
          , FormattedText_Plain " from "
          , FormattedText_Bold (toContractIdText address)
          ]
    MultisigPayload_Reconfig _ addresses ->
      [ FormattedText_Plain "Update multi-signature list:"
      , FormattedText_LineBreak
      ] <> (List.intersperse FormattedText_LineBreak (FormattedText_Bold . toPublicKeyHashText . snd <$> addresses))

showOperationType :: MultisigPayload -> String
showOperationType = \case
  MultisigPayload_Call _ targetParameter ->
    showTokenOperationType targetParameter
  MultisigPayload_Reconfig _threshold _signers ->
    "Update multi-signature signers list"


showTokenOperationType :: TokenOperation -> String
showTokenOperationType = \case
  SetPause True ->
    "Pause contract"
  SetPause False ->
    "Resume contract"
  Mint _amount _address ->
    "Mint"
  Transfer _amount _from _to ->
    "Transfer"
  AddToWhitelist _address ->
    "Add 1 address to whitelist"
  AddToWhitelistBatch addresses ->
    "Add " <> show (length addresses) <> " addresses to whitelist"
  RemoveFromWhitelist _address ->
    "Remove 1 address from whitelist"
  RemoveFromWhitelistBatch addresses ->
    "Remove " <> show (length addresses) <> " addresses from whitelist"
  Burn _amount _address ->
    "Burn"



renderFormattedText :: UI t m => [FormattedText] -> m ()
renderFormattedText formattedTexts =
  el "p" $ do
    _ <- for formattedTexts $ \case
      FormattedText_Plain val -> text val
      FormattedText_Bold val -> el "strong" $ text val
      FormattedText_LineBreak -> el "br" blank
    return ()
