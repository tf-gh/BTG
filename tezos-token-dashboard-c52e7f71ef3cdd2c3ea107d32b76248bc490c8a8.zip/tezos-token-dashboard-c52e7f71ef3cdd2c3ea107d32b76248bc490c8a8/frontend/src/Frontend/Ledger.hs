{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeInType #-}

module Frontend.Ledger where

import Control.Concurrent.MVar (newEmptyMVar, putMVar, takeMVar)
import Control.Lens
import Control.Monad (void)
import Control.Monad.IO.Class (liftIO)
import Data.Bool
import qualified Data.ByteString as BS
import qualified Data.ByteString.Base16 as BS16
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.Encoding as T
import Language.Javascript.JSaddle
import Reflex
import Reflex.Dom
import Tezos.Common.Base58Check
import Tezos.Common.ShortByteString
import Tezos.V005.Ledger
import Tezos.V005.PublicKeyHash
import Tezos.V005.Signature

data Address = Address
  { _address_signingCurve :: SigningCurve
  , _address_derivationPath :: DerivationPath
  , _address_publicKey :: BS.ByteString
  }

getAddress :: MonadJSM m => SigningCurve -> DerivationPath -> m (Maybe Address)
getAddress signingCurve derivationPath = liftJSM $ do
  app <- createApp 30000
  maybeAddress <- await $ app ^. js3 ("getAddress" :: String) (unDerivationPath derivationPath) True (getTopByte signingCurve)
  case maybeAddress of
    Just address -> do
      maybePublicKey <- address !? "publicKey"
      pure $ case maybePublicKey of
        Just rawPublicKey -> Just $ Address
          { _address_signingCurve = signingCurve
          , _address_derivationPath = derivationPath
          , _address_publicKey =  readRawPublicKey rawPublicKey
          }
        Nothing -> Nothing
    Nothing ->
      pure Nothing

getTopByte :: SigningCurve -> Int
getTopByte = \case
  SigningCurve_Ed25519 -> 0x00
  SigningCurve_Secp256k1 -> 0x01
  SigningCurve_P256 -> 0x02

data Version = Version
 { _version_major :: Int
 , _version_minor :: Int
 , _version_patch :: Int
 } deriving (Show)

getVersion :: MonadJSM m => m (Maybe Version)
getVersion = liftJSM $ do
  app <- createApp 5000
  maybeVersionJSVal <- await $ app ^. js0 ("getVersion" :: String)
  case maybeVersionJSVal of
    Just versionJSVal -> do
      versionMajor <- versionJSVal !? "major"
      versionMinor <- versionJSVal !? "minor"
      versionPatch <- versionJSVal !? "patch"
      pure $ Version <$> versionMajor <*> versionMinor <*> versionPatch
    Nothing ->
      pure Nothing

signHashedOperation :: MonadJSM m => DerivationPath -> BS.ByteString -> m (Maybe Signature)
signHashedOperation derivationPath operationBytes = liftJSM $ do
  app <- createApp 30000
  -- the 5 here is a magic byte for arbitrary data (as opposed to an Operation
  -- like a transfer); despite the name this function is not appropriate for
  -- signing an Op at this time.
  let opText = T.decodeUtf8 $ BS16.encode operationBytes
  maybeResult <- await $ app ^. js2 ("signHash" :: String) (unDerivationPath derivationPath) opText
  case maybeResult of
    Just result -> do
      maybeSignatureBytes <- result !? "signature"
      -- This will need tweaked if we support different signing curves.
      pure $ Signature_Ed25519 . HashedValue . toShort . fst . BS16.decode . T.encodeUtf8 <$> maybeSignatureBytes
    Nothing ->
      pure Nothing

signOperation :: MonadJSM m => DerivationPath -> BS.ByteString -> m (Maybe Signature)
signOperation derivationPath operationBytes = liftJSM $ do
  app <- createApp 30000
  -- the 5 here is a magic byte for arbitrary data (as opposed to an Operation
  -- like a transfer); despite the name this function is not appropriate for
  -- signing an Op at this time.
  let opText = T.decodeUtf8 $ BS16.encode $ BS.cons 5 operationBytes
  maybeResult <- await $ app ^. js2 ("signOperation" :: String) (unDerivationPath derivationPath) opText
  case maybeResult of
    Just result -> do
      maybeSignatureBytes <- result !? "signature"
      -- This will need tweaked if we support different signing curves.
      pure $ Signature_Ed25519 . HashedValue . toShort . fst . BS16.decode . T.encodeUtf8 <$> maybeSignatureBytes
    Nothing ->
      pure Nothing

readRawPublicKey :: Text -> BS.ByteString
readRawPublicKey rawPublicKey =
  fst $ BS16.decode $ T.encodeUtf8 $ T.drop 2 rawPublicKey

toPublicKeyHash :: SigningCurve -> BS.ByteString -> PublicKeyHash
toPublicKeyHash signingCurve rawPublicKeyHash =
  case signingCurve of
    SigningCurve_Ed25519 ->
      PublicKeyHash_Ed25519 $ HashedValue $ toShort rawPublicKeyHash
    SigningCurve_Secp256k1 ->
      PublicKeyHash_Secp256k1 $ HashedValue $ toShort rawPublicKeyHash
    SigningCurve_P256 ->
      PublicKeyHash_P256 $ HashedValue $ toShort rawPublicKeyHash

-- HELPER
createApp :: Int -> JSM JSVal
createApp timeout = do
  (Just transport) <- createTransport timeout
  appModule <- getAppModule
  new appModule transport

createTransport :: Int -> JSM (Maybe JSVal)
createTransport timeout = do
  transportModule <- getTransportModule
  maybeTransport <- await $ transportModule ^. js0 ("create" :: String)
  case maybeTransport of
    Just transport -> do
      _ <-  transport ^. js1 ("setExchangeTimeout" :: String) timeout
      pure $ Just transport
    Nothing ->
      pure Nothing


getTransportModule :: JSM JSVal
getTransportModule =
  jsg ("ledger" :: String) ^. js ("transport" :: String)

getAppModule :: JSM JSVal
getAppModule =
  jsg ("ledger" :: String) ^. js ("app" :: String)

await :: JSM JSVal -> JSM (Maybe JSVal)
await async = do
  responseRef <- liftIO newEmptyMVar
  thenCallback <- function $ \_ _ (result:_) -> do
    liftIO $ putMVar responseRef $ Just result
  catchCallback <- function $ \_ _ (result:_) -> do
    consoleLog result
    liftIO $ putMVar responseRef Nothing
  thenVal <- async ^. js1 ("then" :: String) thenCallback
  _ <- thenVal ^. js1 ("catch" :: String) catchCallback
  liftIO $ takeMVar responseRef

(!?) :: FromJSVal a => JSVal -> String -> JSM (Maybe a)
(!?) jsVal key = do
  lookupResult <- jsVal ^. js (key :: String)
  isUndefinedResult <- ghcjsPure $ isUndefined lookupResult
  bool (fromJSVal lookupResult) (pure Nothing) isUndefinedResult

callJavascriptAsync
  :: (TriggerEvent t m, PerformEvent t m, MonadJSM (Performable m))
  => Event t (JSM a) -> m (Event t a)
callJavascriptAsync evt =
  performEventAsync $ ffor evt $ \javascriptCall ->
    (\callback ->
      liftJSM . void . forkJSM $ do
        result <- javascriptCall
        liftIO $ callback result)

-- UTIL
consoleLog :: ToJSVal a => a -> JSM ()
consoleLog val' =
  void $ jsg ("console" :: String) ^. js1 ("log" :: String) val'
