{-# LANGUAGE OverloadedStrings #-}
{-# OPTIONS_GHC -fno-warn-warnings-deprecations #-}

module Frontend.CSS where

import Clay

clayCss :: Css
clayCss = do
  ".nav-bar" ? do
    display flex
    backgroundColor "#f8f8f8"
    padding (px 10) (px 0) (px 0) (px 80)
    "h3" ? do
      padding (px 20) (px 20) (px 0) (px 0)
    "a" ? do
      height $ other "fit-content"
      height $ other "-moz-fit-content"
  ".nav" ? do
    display flex
    justifyContent spaceBetween
    fontSize (px 16)
    fontWeight bold
    color "#898989"
    width (px 250)
    margin (px 2) (px 0) (px 0) (px 90)
  "a" ? cursor pointer
  ".account-dropdown" ? do
    display flex
    position absolute
    right (px 80)
    top (px 30)
    cursor pointer
    fontSize $ px 15
    fontColor "#4183c4"
    fontWeight bold
    ".ui.fluid.dropdown" ? do
      position absolute
      right $ px 11
      ".text" ? do
        visibility hidden
    ".dropdown.icon" ? do
      visibility hidden
  ".ui.menu.secondary" ? do
    alignItems center

  ".whitelist-dropdown" ? do
    display flex
    position relative
    ".ui.fluid.dropdown" ? do
      position absolute
      height $ px 36
      marginLeft $ px 20
      ".text" ? do
        visibility hidden
    ".dropdown.icon" ? do
      visibility hidden


  ".user-management" ? do
    padding (px 40) (px 80) (px 40) (px 80)
  ".user-management-bar" ? do
    display flex
    flexDirection row
    justifyContent spaceBetween
    ".invite-user-button-container" ? do
      width $ px 150
  ".remove-user-btn" ? do
    important $ textAlign $ other "right"
  ".change-user-role-body" ? do
    display flex
    flexDirection column
    borderTop solid (px 1) $ rgba 34 36 38 0.15
    marginTop $ px 11
    paddingTop $ px 11
    ".menu" ? do
      display flex
      flexDirection row
      justifyContent spaceBetween
      border solid (px 0) transparent
      boxShadow . pure $ none
      ".item" ? do
        display flex
        flexDirection column
        justifyContent center
        alignItems center
        width $ px 190
        height $ px 200
        border solid (px 1) $ rgba 34 36 38 0.22
        textAlign center
        marginLeft $ px 21
        marginRight $ px 21
  ".user-role-update-body" ? do
    display flex
    justifyContent center
    flexDirection column
    alignItems center
    marginTop $ px 19
    borderTop solid (px 1) $ rgba 34 36 38 0.15
    height $ px 122
  ".modal-box" ? ".update-2fa-body" ? do
    display flex
    -- justifyContent center
    flexDirection column
    marginTop $ px 19
    borderTop solid (px 1) $ rgba 34 36 38 0.15
    "header.short" ? do
      paddingBottom $ px 0
  ".two-factor-key" ? do
    fontWeight bold
    textAlign center
    marginTop $ px 19
  ".update-2fa-footer" ? do
    display flex
    justifyContent flexEnd
    alignItems center
    height $ px 65
    marginTop $ px 14
    paddingRight $ px 13
    borderTop solid (px 1) $ rgba 34 36 38 0.15
  ".change-pw-body" ? do
    display flex
    justifyContent center
    alignItems center
    marginTop $ px 19
    borderTop solid (px 1) $ rgba 34 36 38 0.15
    height $ px 64
  ".change-pw-form" ? do
    borderTop solid (px 1) $ rgba 34 36 38 0.15
    ".message" ? do
      margin (px 11) (px 15) (px 0) (px 15)
  ".change-pw-form-footer" ? do
    display flex
    justifyContent flexEnd
    alignItems center
    height $ px 65
    marginTop $ px 14
    paddingRight $ px 13
    borderTop solid (px 1) $ rgba 34 36 38 0.15
  ".change-user-role-backdrop" ? do
    backgroundColor white
    position fixed
    top (px 0)
    bottom (px 0)
    left (px 0)
    right (px 0)
  ".cancel-role-widget" ? do
    fontSize $ em 2
    fontWeight bold
    textAlign center
    position absolute
    right $ pct 2
    top $ pct 2
  ".operation-state-error" ? do
    display flex
    flexDirection column
    justifyContent center
    alignItems center
    ".operation-state-error-title" ? do
      fontSize $ px 24
      textAlign center
    ".operation-state-error-desc" ? do
      display inline
      fontSize $ px 16
      textAlign center
      "p" ? do
        fontColor $ rgba 0 0 0 0.6
      "a" ? do
        fontColor blue
    ".operation-state-flex-inline" ? do
      display inline
      textAlign center
      paddingLeft $ px 21
      paddingRight $ px 21
    ".red-box" ? do
      display flex
      justifyContent center
      alignItems center
      fontWeight bolder
      fontColor white
      backgroundColor "#db2828"
      height $ px 26
      width $ px 28
      borderRadius (px 4) (px 4) (px 4) (px 4)
    ".orange-box" ? do
      display flex
      justifyContent center
      alignItems center
      fontWeight bolder
      fontColor white
      backgroundColor "#f2711c"
      height $ px 26
      width $ px 28
      borderRadius (px 4) (px 4) (px 4) (px 4)

  ".error-container" ? do
    display flex
    flexDirection column
    "width" -: "fit-content"
    position relative
    margin (px 0) auto (px 0) auto
    paddingTop (px 200)
  ".error-message" ? do
    textAlign center
    width (vw 60)
    margin (px 0) auto (px 0) auto
    padding (px 43) (px 200) (px 43) (px 200)
    marginTop (px 43)
    topRedBorder
  ".modal-message, .modal-error-message, .modal-inform-message, .modal-warning-message" ? do
    textAlign center
    margin (px 0) auto (px 0) auto
    width $ pct 90
    margin (px 20) (px 20) (px 20) (px 20)
    padding (px 20) (px 20) (px 20) (px 20)
  ".left.aligned.modal-message, .left.aligned.modal-inform-message" ? do
    textAlign start
  ".modal-message" ? do
    "border-radius" -: "4px"
    border solid (px 1) lightgrey
    ".header" ? paddingBottom (px 15)
  ".modal-message-text" ? do
    fontFamily ["HelveticaNeue"] [sansSerif]
    fontSize $ px 16
    color $ rgba 0 0 0 0.6
    paddingTop $ px 15
  ".modal-validation-text" ? do
    fontFamily ["HelveticaNeue"] [sansSerif]
    fontSize $ px 16
    fontWeight bold
  ".modal-error-message" ? do
    topRedBorder
  ".modal-inform-message" ? do
    topGreenBorder
  ".modal-warning-message" ? do
    topOrangeBorder
  ".whitelist-error" ? do
    topRedBorder
  ".card-container" ? do
    width $ em 35
    margin (px 0) auto (px 0) auto
    ".card" ? do
      width $ px 500
  ".form-container" ? do
    display flex
    flexDirection column
    position relative
    width $ em 35
    margin (px 0) auto (px 0) auto
    paddingTop (px 200)
    ".form-header" ? do
      paddingBottom (px 20)
    ".welcome-message" ? do
      paddingTop (px 30)
    ".form-controls" ? do
      display flex
      paddingTop (px 25)
      padding (px 30) (px 30) (px 30) (px 30)
  ".input-field" ? do
    marginTop (px 20)
  ".search-input-field" ? do
    width $ pct 100
  ".field-name" ? do
    display flex
    fontSize (px 13)
    fontWeight bold
    height (px 34)
    position relative
  ".field-error-label" ? do
    position absolute
    marginLeft auto
    marginRight auto
    left (px 0)
    right (px 0)
    textAlign center
    "width" -: "max-content"
  ".submit" ? do
    height (px 90)
    marginTop (px 30)
    display flex
    flexDirection column
  ".close-button" ? do
    position absolute
    cursor pointer
    right (px 20)
  ".name" ? do
    position absolute
    bottom (px 0)
  ".token" ? do
    display grid
    padding (px 40) (px 70)( px 40) (px 70)
    ".token-info" ? do
      margin (px 40) (px 0) (px 40) (px 0)
      ".card" ? do
        height $ px 230
        width (pct 100)
        padding (px 33) (px 33)( px 33) (px 33)
        display flex
        flexDirection column
        ".addresses" ? do
          display flex
          flexDirection row
          height $ px 90
        ".address, .amount" ? do
          margin (px 10) (px 10) (px 10) (px 10)

  ".modal-backdrop" ? do
    zIndex 20
    position fixed
    top $ px 0
    left $ px 0
    height $ pct 100
    width $ pct 100
    backgroundColor $ rgba 0 0 0 0.7
  ".modal-box" ? do
    zIndex 20
    position fixed
    overflowY auto
    top $ pct 50
    left $ pct 50
    transform $ translate (pct (-50)) (pct (-50))
    maxHeight $ pct 100
    minWidth $ px 442
    width $ other "fit-content"
    backgroundColor "#FFF"
    borderRadius (px 4) (px 4) (px 4) (px 4)
    boxShadow . pure $ bsColor (rgba 0 0 0 0.6) $ shadowWithSpread (px 0) (px 15) (px 50) (px 0)
    overflowX hidden
    ".header" ? do
      margin (px 0) (px 0) (px 0) (px 0)
      padding (px 15) (px 15) (px 15) (px 15)
    ".content" ? do
      maxWidth (px 720)
      padding (px 0) (px 0) (px 10) (px 0)
      "p" ? do
        padding (px 0) (px 15) (px 0) (px 15)
        textAlign center
      ".input-field" ? padding (px 0) (px 15) (px 0) (px 15)
      ".search-input-field" ? do
        padding (px 15) (px 15) (px 0) (px 15)
        ".input" ? do
          width $ pct 100
    ".controls" ? do
      padding (px 0) (px 15) (px 0) (px 15)
      display flex
      flexDirection row
      justifyContent flexEnd
      minHeight (px 30)
    ".message" ? do
      margin (px 11) (px 20) (px 0) (px 20)
  ".debug" ? do
    display flex
    flexDirection column
    padding (px 40) (px 70)( px 40) (px 70)
    ".debug-actions" ? do
      display flex
      padding (px 20) (px 35)( px 20) (px 35)
      ".debug-action-list" ? do
        width $ px 300
      ".debug-result" ? do
        marginLeft $ px 40
  ".dropdown-menu-modal" ? do
    position fixed
    top $ px 0
    bottom $ px 0
    right $ px 0
    left $ px 0
    zIndex 18
  ".warning" ? do
    position relative
    display inlineBlock
    marginRight (px 8)
  ".upper-left-nav" ? do
    display flex
    flexDirection column
    paddingBottom $ px 15
  ".gas-wallet-balance-container" ? do
    display flex
    flexDirection row
    alignItems center
    justifyContent spaceAround
    height $ px 26
    width $ px 96
    borderRadius (px 4) (px 4) (px 4) (px 4)
    backgroundColor "#00b5ad"
    fontColor white
    fontFamily ["HelveticaNeue"] [sansSerif]
    fontWeight bold
    fontSize $ px 12
  ".pause-contract-disabled" ? do
    display flex
    flexDirection row
    width $ px 182
    height $ px 36
    borderRadius (px 4) (px 4) (px 4) (px 4)
    backgroundColor "#e0e1e2"
    opacity 0.45
    ".pause-button-container" ? do
      display flex
      justifyContent center
      alignItems center
      height $ px 36
      width $ px 36
      borderRadius (px 4) (px 4) (px 4) (px 4)
      backgroundColor "#cecece"
      padding (px 0) (px 0) (px 2) (px 4)
    ".pause-button-caption" ? do
      width $ pct 100
      display flex
      justifyContent center
      alignItems center
      fontWeight bold
      fontFamily ["HelveticaNeue"] [sansSerif]
      fontSize $ px 14
      paddingTop (px 2)
  ".pause-contract" ? do
    display flex
    flexDirection row
    width $ px 182
    height $ px 36
    borderRadius (px 4) (px 4) (px 4) (px 4)
    backgroundColor "#e0e1e2"
    cursor pointer
    ".pause-button-container" ? do
      display flex
      justifyContent center
      alignItems center
      height $ px 36
      width $ px 36
      borderRadius (px 4) (px 4) (px 4) (px 4)
      backgroundColor "#cecece"
      padding (px 0) (px 0) (px 2) (px 4)
    ".pause-button-caption" ? do
      width $ pct 100
      display flex
      justifyContent center
      alignItems center
      fontWeight bold
      fontFamily ["HelveticaNeue"] [sansSerif]
      fontSize $ px 14
      paddingTop (px 2)
  ".create-operation-body" ? do
    flexDirection column
    justifyContent center
    marginTop $ px 18
    ".content" ? do
      display flex
      flexDirection column
  ".create-operation-text" ? do
    fontFamily ["HelveticaNeue"] [sansSerif]
    fontSize $ px 16
    color $ rgba 0 0 0 0.6
    paddingTop $ px 10
  ".op-description-container" ? do
    display flex
    justifyContent center
    alignItems center
    ".op-description" ? do
      display flex
      flexDirection column
      justifyContent center
      alignItems center
      marginTop $ px 20
      borderRadius (px 4) (px 4) (px 4) (px 4)
      border solid (px 1) $ rgba 34 36 38 0.15
      boxShadowWithSpread (px 0) (px 1) (px 2) (px 0) $ rgba 34 36 38 0.15
      padding (px 20) (px 20) (px 20) (px 20)
      widthFitContent
  ".signature-info" ? do
    display flex
    flexDirection column
    justifyContent center
    alignItems center
    marginTop $ px 20
  ".sign-content" ? do
    display flex
    flexDirection column
    justifyContent center
    alignItems center
    paddingLeft $ px 21
    paddingRight $ px 21
  ".sign-ledger-hash" ? do
    display flex
    flexDirection column
    justifyContent center
    alignItems center
    width $ px 490
    height $ px 68
    borderRadius (px 4) (px 4) (px 4) (px 4)
    backgroundColor "#f8f8f9"
    boxShadowWithSpread (px 0) (px 0) (px 0) (px 1) $ rgba 34 36 38 0.22
    marginTop $ px 14
    marginBottom $ px 14
    fontSize $ px 15
    fontWeight bold
    lineHeight $ px 1.33
  ".footer-filler" ? do
    height $ px 35
  ".workflow-button-footer" ? do
    display flex
    flexDirection row
    justifyContent flexEnd
    paddingRight $ px 17
    ".button.grey" ? do
      marginRight $ px 14
  ".ledger-status" ? do
    display flex
    flexDirection column
    alignItems center
    width $ px 740
    ".label" ? do
      display flex
    "div" ? do
      paddingTop (px 8)
      paddingBottom (px 8)
  ".workflow-success" ? do
    margin (px 0) auto (px 0) auto
    widthFitContent
  ".address-input" ? do
    display flex
    marginBottom (px 20)
    ".input-field" ? do
      paddingLeft (px 20)
      paddingRight (px 20)
      width (px 320)
  ".operation-description" ? do
    margin (px 30) auto (px 30) auto
    widthFitContent
  ".description" ? do
    margin (px 30) (px 30) (px 30) (px 30)
    ".instruction" ? do
      fontSize (px 16)
      fontColor (rgba 0 0 0 0.6)
      paddingTop (px 10)
  ".ledger-prompt" ? do
    display flex
    justifyContent center
  ".operations-container" ? do
    marginTop $ px 41
  ".operations-table" ? do
    width $ pct 100 -- px 980
    borderRadius (px 4) (px 4) (px 4) (px 4)
    borderCollapse collapse
    ".table-header" ? do
      fontFamily ["HelveticaNeue"] [sansSerif]
      border solid (px 1) $ rgba 34 36 38 0.1
      backgroundColor "#f9fafb"
    ".table-row" ? do
      fontFamily ["HelveticaNeue"] [sansSerif]
      borderBottom solid (px 1) $ rgba 34 36 38 0.15
      borderLeft solid (px 1) $ rgba 34 36 38 0.15
      borderRight solid (px 1) $ rgba 34 36 38 0.15
      height $ px 56
    ".no-action-message" ? do
      textAlign center
    "th" ? do
      width $ pct 33.33
      height $ px 45
      fontSize $ px 14
      fontWeight bold
      textAlign start
      padding (px 11) (px 11) (px 11) (px 11)
    "td" ? do
      padding (px 11) (px 11) (px 11) (px 11)
      textAlign start
    "tr" ? do
      padding (px 11) (px 11) (px 11) (px 11)
  ".blockchain-action-warning" ? do
    width $ px 678
    height $ px 134
    display flex
    justifyContent center
    alignItems center
    borderTop solid (px 2) "#f2711c"
    borderBottom solid (px 1) $ rgba 34 36 38 0.15
    borderRight solid (px 1) $ rgba 34 36 38 0.15
    borderLeft solid (px 1) $ rgba 34 36 38 0.15
  ".actions-td" ? do
    display flex
    flexDirection row
  ".sign-operation-btn" ? do
    display inline
    marginRight $ px 17
  ".cancel-op-modal-body" ? do
    display flex
    flexDirection column
    alignItems center
    justifyContent center
    ".cancel-op-content" ? do
      display flex
      flexDirection column
      padding (px 11) (px 11) (px 11) (px 11)
    ".success-check-container" ? do
      display flex
      justifyContent center
      alignItems center
      height $ px 26
      width $ px 31
      backgroundColor "#00b5ad"
      borderRadius (px 4) (px 4) (px 4) (px 4)
      fontColor white
    ".fail-x-container" ? do
      display flex
      justifyContent center
      alignItems center
      height $ px 26
      width $ px 31
      backgroundColor "#d01919"
      borderRadius (px 4) (px 4) (px 4) (px 4)
      fontColor white
  ".cancel-workflow-button-footer" ? do
    display flex
    flexDirection row
    justifyContent flexEnd
    fontSize $ px 14
    ".ui.button.grey" ? do
      width $ px 74
      height $ px 36
      marginRight $ px 17
    ".ui.button.green" ? do
      height $ px 36
      marginRight $ px 15
  ".operations" ? do
    display flex
    ".operation-button" ? do
      display flex
      flexDirection row
      width $ px 182
      height $ px 36
      borderRadius (px 4) (px 4) (px 4) (px 4)
      backgroundColor "#e0e1e2"
      marginLeft $ px 20
      cursor pointer
      ".operation-button-icon" ? do
        display flex
        justifyContent center
        alignItems center
        height $ px 36
        width $ px 36
        borderRadius (px 4) (px 4) (px 4) (px 4)
        backgroundColor "#cecece"
        padding (px 0) (px 0) (px 2) (px 4)
      ".fas" ? do
        display flex
        justifyContent center
        alignItems center
        height $ px 36
        width $ px 36
        borderRadius (px 4) (px 4) (px 4) (px 4)
        backgroundColor "#cecece"
        padding (px 0) (px 0) (px 2) (px 4)
      ".operation-button-caption" ? do
        width $ pct 100
        display flex
        justifyContent center
        alignItems center
        fontWeight bold
        fontFamily ["HelveticaNeue"] [sansSerif]
        fontSize $ px 14
        paddingTop (px 2)
  ".mint-input" ? do
    display flex
    ".operation-amount-field" ? do
      width $ px 230
    ".mint-destination-field" ? do
      width $ px 430
  ".holder-whitelist" ? do
    width $ px 720
    height $ px 500
  ".addresses-input" ? do
    "ul" ? do
      paddingLeft $ px 17
      marginTop $ px 8
      "li" ? do
        "list-style" -: "none"
  ".validation-results" ? do
    display flex
    flexWrap $ other "wrap"
    ".message" ? do
      width $ px 300
      height $ px 50
    ".message:first-child" ? do
      marginTop $ px 11
  ".listed-addresses" ? do
    display flex
    flexDirection column
    margin (px 25) (px 50) (px 25) (px 23)
    ".listed-address" ? do
      display flex
      justifyContent spaceBetween
      paddingTop $ px 3
      paddingBottom $ px 3
      borderBottom solid (px 1) $ rgba 34 36 38 0.15
    ".listed-address:last-child" ? do
      borderBottom solid (px 0) $ rgba 34 36 38 0.15
  ".past-operation-table-controls" ? do
    display flex
    justifyContent spaceBetween
    ".pagination-controls" ? do
      display flex
      ".pagination-ellipsis" ? do
        padding (px 15) (px 15) (px 0) (px 10)
      ".pagination-current" ? do
        padding (px 8) (px 16) (px 8) (px 16)
        border solid (px 1) "#d3d3d3"
        borderRadius (px 5) (px 5) (px 5) (px 5)
        marginLeft $ px 3
        marginRight $ px 5
  ".past-operations-menu" ? do
    paddingBottom $ px 20
  ".two-factor-auth-controls" ? do
    display flex
    paddingTop $ px 25
  ".two-factor-auth-controls-change-roles" ? do
    display flex
    justifyContent flexEnd
    paddingTop $ px 25
  ".balance-text" ? do
    fontWeight bold
    fontSize $ px 15
  ".modal-loading" ? do
    paddingTop (px 40)
    paddingBottom (px 60)
  ".copy-to-clipboard" ? do
    display flex


widthFitContent :: Css
widthFitContent = do
  width $ other "fit-content"
  width $ other "-moz-fit-content"

topRedBorder :: Css
topRedBorder = topBorder "#db2828"

topGreenBorder :: Css
topGreenBorder = topBorder "#16ab39"

topOrangeBorder :: Css
topOrangeBorder = topBorder "#f2711c"

topBorder :: Color -> Css
topBorder topColor = do
  "border-radius" -: "4px"
  boxShadow . pure $ bsColor (rgba 34 36 38 0.15) $ shadowWithSpread (px 0) (px 1) (px 2) (px 0)
  border solid (px 1) (rgba 34 36 38 0.15)
  borderTopWidth (px 2)
  borderTopColor topColor
