{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecursiveDo #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Frontend.Token.Signing where

import Control.Lens hiding ((:<))
import Control.Monad.Reader
import Data.Bool
import qualified Data.ByteString as BS
import Data.ByteString.Base58
import Data.Foldable (for_)
import qualified Data.Map.Monoidal as MMap
import Data.Semigroup
import qualified Data.Set as Set
import qualified Data.Text as T
import qualified Data.Text.Encoding as T
import Data.Traversable (for)
import Database.Id.Class
import Frontend.Widgets
import Obelisk.Route.Frontend
import Reflex.Dom
import qualified Reflex.Dom.SemanticUI as SemUi
import Rhyolite.Api

import Common.App
import Common.Route
import Common.Schema
import Frontend.App
import Frontend.Ledger
import Frontend.OperationText
import Frontend.Watch
import Tezos.Multisig.Schema
import Tezos.Token.Schema
import Tezos.Types

signOnLedgerPromptWorkflow
  :: (AppModalWidget t m, SetRoute t (R FrontendRoute) m)
  => Maybe SigningInfo -> MultisigCall -> Maybe (Id PendingOperation) -> OperationText -> Workflow t m (Event t ())
signOnLedgerPromptWorkflow maybeSigningInfo multisigCall maybeOpId opText =
  case maybeSigningInfo of
    Nothing ->
      setPKHWorkflow
    Just signingInfo -> do
      case maybeOpId of
        Nothing -> reviewOperationW signingInfo False
        Just _ ->
          case _multisigCall_payload multisigCall of
            MultisigPayload_Call _ tokenOperation ->
              case tokenOperation of
                Mint amount address -> Workflow $
                  modalBoxFormW (_operationText_short opText) $ mdo
                    SemUi.divider def
                    divClass "create-operation-body" $ do
                      SemUi.header (def
                        & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
                        & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text (_operationText_definition opText)
                      elClass "div" "create-operation-text" $ el "p" $ text "The first signer has set the following values for this operation:"
                    elClass "div" "ui mint-input" $ do
                      elClass "div" "operation-amount-field" $
                        disabledTextInputFieldW "Amount to Mint" (T.pack $ show amount)
                      elClass "div" "mint-destination-field" $
                        disabledTextInputFieldW "Destination Address" (toContractIdText address)
                    SemUi.divider def
                    (cancelE, continueE) <- divClass "controls" $ do
                      cancelE' <- modalCancelButtonW "Cancel"
                      continueE' <- greenButtonW "Continue" $ constDyn False
                      return (cancelE', continueE')
                    return (cancelE, (reviewOperationW signingInfo) <$> (False <$ continueE))
                Burn amount address -> Workflow $
                  modalBoxFormW (_operationText_short opText) $ mdo
                    SemUi.divider def
                    divClass "create-operation-body" $ do
                      SemUi.header (def
                        & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
                        & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text (_operationText_definition opText)
                      elClass "div" "create-operation-text" $ el "p" $ text "The first signer has set the following values for this operation:"
                    elClass "div" "ui mint-input" $ do
                      elClass "div" "operation-amount-field" $
                        disabledTextInputFieldW "Amount to Burn" (T.pack $ show amount)
                      elClass "div" "mint-destination-field" $
                        disabledTextInputFieldW "From Address" (toContractIdText address)
                    SemUi.message def $ do
                      SemUi.paragraph $ text "If you’d like to modify the operation’s values you must create a new operation."
                    SemUi.divider def
                    (cancelE, continueE) <- divClass "controls" $ do
                      cancelE' <- modalCancelButtonW "Cancel"
                      continueE' <- greenButtonW "Continue" $ constDyn False
                      return (cancelE', continueE')
                    return (cancelE, (reviewOperationW signingInfo) <$> (False <$ continueE))
                AddToWhitelist address ->
                  whitelistInputReview signingInfo [address]
                AddToWhitelistBatch addresses ->
                  whitelistInputReview signingInfo addresses
                RemoveFromWhitelist address ->
                  whitelistInputReview signingInfo [address]
                _ ->
                  reviewOperationW signingInfo False
            MultisigPayload_Reconfig _ addresses ->
              updateSignersListInputReview signingInfo addresses


  where
    reserveOperation signingInfo sigCount =
      case maybeOpId of
        Just opId -> ledgerPrompt signingInfo sigCount opId multisigCall
        Nothing -> Workflow $
          modalBoxFormW (_operationText_short opText) $ mdo
            SemUi.divider def
            divClass "modal-loading" loadingW
            pb <- getPostBuild
            token <- getAuthToken
            opE <- requestingIdentity $ ApiRequest_Private token (PrivateRequest_AddPendingOperation multisigCall) <$ pb
            let (_failureOpIdE, successOpIdE) = fanEither opE
            return (never, uncurry (ledgerPrompt signingInfo sigCount) <$> successOpIdE)

    ledgerPrompt signingInfo sigCount opId finalMultisigCall = Workflow $
      modalBoxFormW (_operationText_short opText) $ mdo
        let operationBytes = multisigCallBytesToSign finalMultisigCall
        SemUi.divider def
        divClass "sign-content" $
          ledgerStatusW (Just $ _signingInfo_publicKeyHash signingInfo) True
        divClass "op-description-container" $ divClass "op-description" $ do
          el "h4" $ text "Operation Description:"
          renderDescription $ _multisigCall_payload multisigCall
        divClass "signature-info" $ do
          el "h3" $ text "Respond to the prompt on your ledger device."
          el "p" $ text "Your Ledger device should show the following prompt:"
        calculatedHashE <- divClass "sign-content" $ divClass "sign-ledger-hash" $ do
          el "p" $ text "Sign Hash?"
          postBuild <- getPostBuild
          let runBlake2bHashRequest = ApiRequest_Public (PublicRequest_RunBlake2bHash Blake2bHashSize_32 (BS.cons 5 operationBytes)) <$ postBuild
          runBlake2bHashResponse <- requestingIdentity runBlake2bHashRequest
          let (_, hashSuccessE) = fanEither runBlake2bHashResponse
          operationHashD <- holdDyn "" $ T.decodeUtf8 . encodeBase58 bitcoinAlphabet <$> hashSuccessE
          el "p" $ dynText operationHashD
          pure hashSuccessE
        SemUi.divider def
        mSignature <- callJavascriptAsync $ signHashedOperation (DerivationPath $ _signingInfo_derivationPath signingInfo) <$> calculatedHashE
        divClass "footer-filler" blank
        pure (never, (ledgerSignAttempt sigCount signingInfo opId) <$> mSignature)

    ledgerSignAttempt sc@(SignatureCount sigCount) signingInfo opId mSignature =
      case mSignature of
        Just signature -> Workflow $
          modalBoxFormW (_operationText_short opText) $ do
            addOpResult <- addOperationSignature signingInfo opId sc signature
            let (failedOpSig, successOpSig) = fanEither addOpResult
            SemUi.divider def
            signaturePositionDE <- divClass "sign-content" $ do
              -- handle success
              widgetHold_ blank $ ffor successOpSig $ \case
                Just opHash -> do
                  el "h3" $ text "Signing successful. This operation has been sent to the blockchain."
                  el "p" $ text $  toBase58Text opHash
                Nothing -> do
                  el "h3" $ text "Signing successful. Your signature has been saved."
                  let remainingSigs = numOfRequiredSignatures - sigCount
                  el "p" $ text $ "After "
                    <> (T.pack $ show $ remainingSigs)
                    <> " signature(s) is gathered the "
                    <> (T.toLower $ _operationText_short $ lookupOperationText $ _multisigCall_payload multisigCall)
                    <> " operation will be sent to the blockchain."
              -- handle errors
              widgetHold (return never) $ ffor failedOpSig $ \err -> case err of
                BTGError_OperationSignaturePositionChange newPos -> divClass "operation-state-error" $ do
                  divClass "orange-box" $ text "!"
                  elClass "p" "operation-state-error-title" $ text "Your signing position has been changed."
                  divClass "modal-error-message" $ do
                    elClass "p" "operation-state-error-desc" $ text "Other admins have signed this operation while you were signing. There are now enough signatures to send this operation to the blockchain."
                    saveBtn <- modalSubmitButtonW "Save signature as third signer and send operation to the blockchain" $ constDyn False
                    elClass "p" "" $ text "or"
                    cancelBtn <- modalCancelButtonW "Cancel signing. Operation will not be sent until a third admin signs."
                    return $ leftmost [Right <$> (newPos <$ saveBtn), Left <$> cancelBtn]
                BTGError_OperationDismissed errMsg -> divClass "operation-state-error" $ do
                  divClass "red-box" $ text "x"
                  elClass "p" "operation-state-error-title" $ text $ errMsg
                  elClass "p" "operation-state-error-desc" $ text "This operation was cancelled by another admin while you were signing and has been deleted."
                  return never
                BTGError_OperationSignatureSatisfied errMsg -> divClass "operation-state-error" $ do
                  divClass "red-box" $ text "x"
                  elClass "p" "operation-state-error-title" $ text $ errMsg
                  elClass "p" "operation-state-error-desc" $ text "This operation was signed by a third admin and was sent to the blockchain before your signature was completed."
                  return never
                BTGError_OperationSignatureInvalid -> divClass "operation-state-error" $ do
                  divClass "red-box" $ text "x"
                  elClass "p" "operation-state-error-title" $ text $ T.pack $ show err
                  elClass "p" "operation-state-error-desc" $ text "The Ledger device used to sign did not have the PKH needed to sign the operation. Make sure to use the Ledger device with the PKH shown on the signing screens. You may go back to restart the signing process with a different Ledger device."
                  return never
                _ -> do
                  errorMessageW $ T.pack $ show err
                  return never
            signaturePositionE' <- switchHold never <=< dyn $ ffor signaturePositionDE $ \positionEv -> return positionEv
            let (cancelBtn, signaturePositionE) = fanEither signaturePositionE'
            SemUi.divider def
            doneE <- divClass "controls" $ do
              greenButtonW "Done" $ constDyn False
            pure (leftmost [doneE, cancelBtn], (reserveOperation signingInfo) <$> (fmap SignatureCount signaturePositionE))
        Nothing ->
          clearAndReviewOperationW signingInfo opId

    clearAndReviewOperationW signingInfo opId =
      case maybeOpId of
        Just _ -> reviewOperationW signingInfo True
        Nothing -> Workflow $
          modalBoxFormW (_operationText_short opText) $ mdo
            SemUi.divider def
            divClass "modal-loading" loadingW
            pb <- getPostBuild
            token <- getAuthToken
            opE <- requestingIdentity $ ApiRequest_Private token (PrivateRequest_CancelOperation opId) <$ pb
            return (never, reviewOperationW signingInfo True <$ opE)

    reviewOperationW signingInfo showError  = Workflow $ do
      modalBoxFormW (_operationText_short opText) $ mdo
        SemUi.divider def
        divClass "sign-content" $ do
          ledgerStatusW (Just $ _signingInfo_publicKeyHash signingInfo) True
          bool blank (errorMessageW "The Ledger device prompt was rejected or timed out. Please try again.") showError
          divClass "op-description-container" $ divClass "op-description" $ do
            el "h4" $ text "Operation Description:"
            renderDescription $ _multisigCall_payload multisigCall
        signatureCountEv <- signeeNumberW maybeOpId signOnLedger
        SemUi.divider def
        (cancelE, signOnLedger) <- signLedgerFooterW
        pure (cancelE, (reserveOperation signingInfo) <$> signatureCountEv)

    whitelistInputReview signingInfo addresses = Workflow $
      modalBoxFormW (_operationText_short opText) $ mdo
        SemUi.divider def
        divClass "create-operation-body" $ do
          SemUi.header (def
            & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
            & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text (_operationText_definition opText)
          elClass "div" "create-operation-text" $ el "p" $ text "The first signer has set the following values for this operation:"
        elClass "div" "ui addresses-input" $ mdo
          elClass "div" "input-field" $ elClass "div" "field-name" $ elClass "span" "name" $ text "Addresses"
          showAllD <- holdDyn False $ True <$ showAllE
          showAllE <- switchHold never <=< dyn $ ffor showAllD $ \case
            False -> el "ul" $ do
              _ <- for (take 4 addresses) $ \address ->
                el "li" $ text $ toContractIdText address
              if length addresses > 4
                then do
                  (showMoreEl, _) <- el' "a" $ text $ "Show " <> (T.pack $ show $ length addresses - 4) <> " more addresses..."
                  return $ domEvent Click showMoreEl
                else
                  return never
            True -> el "ul" $ do
              _ <- for addresses $ \address ->
                el "li" $ text $ toContractIdText address
              return never
          return ()

        SemUi.message def $ do
          SemUi.paragraph $ text "If you’d like to modify the operation’s values you must create a new operation."
        SemUi.divider def
        (cancelE, continueE) <- divClass "controls" $ do
          cancelE' <- modalCancelButtonW "Cancel"
          continueE' <- greenButtonW "Continue" $ constDyn False
          return (cancelE', continueE')
        return (cancelE, (reviewOperationW signingInfo) <$> (False <$ continueE))

    updateSignersListInputReview signingInfo publicKeys = Workflow $
      modalBoxFormW (_operationText_short opText) $ mdo
        SemUi.divider def
        divClass "create-operation-body" $ do
          SemUi.header (def
            & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
            & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text (_operationText_definition opText)
          elClass "div" "create-operation-text" $ el "p" $ text "The operation originator has set the following values for this operation:"
        elClass "div" "ui addresses-input" $ mdo
          elClass "div" "input-field" $ elClass "div" "field-name" $ elClass "span" "name" $ text "Addresses"
          divClass "listed-addresses" $ do
            dynAuthorizedKeys <- watchAuthorizedKeys $ constDyn AuthorizedKeysQuery_ActiveKeys
            widgetHold_ blank $ ffor (updated dynAuthorizedKeys) $ \(First maybeAuthorizedKeys) -> do
              let authorizedKeys = maybe [] _authorizedKeys_publicKeys maybeAuthorizedKeys
                  (removed, existing, added) = threeWayPartition (Set.fromList $ snd <$> authorizedKeys) (Set.fromList $ snd <$> publicKeys)
              for_ added $ \addedPublicKey -> divClass "listed-address" $ do
                el "div" $ text $ toPublicKeyHashText addedPublicKey
                el "div" $ text "Add address"
              for_ removed $ \removedPublicKey -> divClass "listed-address" $ do
                el "div" $ el "s" $ text $ toPublicKeyHashText removedPublicKey
                el "div" $ text "Remove address"
              for_ existing $ \existingPublicKey -> divClass "listed-address" $ do
                el "div" $ text $ toPublicKeyHashText existingPublicKey
                el "div" $ text "Existing address"

        SemUi.message def $ do
          SemUi.paragraph $ text "If you’d like to modify the operation’s values you must create a new operation."
        SemUi.divider def
        (cancelE, continueE) <- divClass "controls" $ do
          cancelE' <- modalCancelButtonW "Cancel"
          continueE' <- greenButtonW "Continue" $ constDyn False
          return (cancelE', continueE')
        return (cancelE, reviewOperationW signingInfo False <$ continueE)
        where
          threeWayPartition setA setB =
            (Set.difference setA setB, Set.intersection setA setB, Set.difference setB setA)

addOperationSignature
  :: AppModalWidget t m
  => SigningInfo -> Id PendingOperation -> SignatureCount -> Signature -> m (Event t (Either BTGError (Maybe OperationHash)))
addOperationSignature signingInfo theId initialCountPosition sig = do
  pb <- getPostBuild
  token <- getAuthToken

  let signature = OperationSignature
        { _operationSignature_pendingOperation = theId
        , _operationSignature_signature = sig
        , _operationSignature_signingKey = _signingInfo_publicKey signingInfo
        }
  resE <- requestingIdentity $ ApiRequest_Private token (PrivateRequest_AddOperationSignature signature initialCountPosition) <$ pb
  return $ resE

signeeNumberW :: AppModalWidget t m => Maybe (Id PendingOperation) -> Event t () -> m (Event t SignatureCount)
signeeNumberW mPendingId signOnLedgerEv = divClass "signature-info" $ do
  case mPendingId of
    Nothing -> do
      el "h3" $ text $ "Signature 1 of " <> (T.pack $ show numOfRequiredSignatures)
      el "p" $ text $ "This operation requires " <> (T.pack $ show numOfRequiredSignatures) <> " signatures."
      el "p" $ text $ "Yours will be the first signature."
      return $ SignatureCount 1 <$ signOnLedgerEv
    Just pendingId -> do
      dmOpSigs <- watchOperationSignature $ constDyn $ OperationSignatureQuery_ByPendingOperation pendingId
      switchHold never <=< dyn $ ffor dmOpSigs $ \opSigMap -> do
        let sigNumber = 1 + (MMap.size opSigMap)
        el "h3" $ text $ "Signature " <> (T.pack $ show sigNumber) <> " of " <> (T.pack $ show numOfRequiredSignatures)
        el "p" $ text $ "This operation requires " <> (T.pack $ show numOfRequiredSignatures) <> " signatures."
        el "p" $ text $ "Yours will be the " <> (if sigNumber == 1 then "first" else if sigNumber == 2 then "second" else "third") <> " signature."
        bool blank blockchainActionWarning $ sigNumber == numOfRequiredSignatures
        return $ SignatureCount sigNumber <$ signOnLedgerEv
  where
    blockchainActionWarning = divClass "blockchain-action-warning" $
        el "h4" $ text $ "This operation will be sent to the blockchain immediately after your signature is collected."

signLedgerFooterW :: AppModalWidget t m => m (Event t (), Event t ())
signLedgerFooterW = divClass "workflow-button-footer" $ do
  cancelE' <- modalCancelButtonW "Cancel"
  signOnLedger' <- greenButtonW "Sign on Ledger device" $ constDyn False
  return (cancelE', signOnLedger')

signOperationWorkflow
  :: (AppModalWidget t m, SetRoute t (R FrontendRoute) m)
  => TokenInfo -> Maybe SigningInfo -> OperationText -> (Event t () -> m (Event t TokenOperation)) -> Workflow t m (Event t ())
signOperationWorkflow tokenInfo mSigningInfo opText opInputWidget =
  case mSigningInfo of
    Nothing ->
      setPKHWorkflow
    Just signingInfo -> Workflow $
      modalBoxFormW (_operationText_short opText) $ mdo
        SemUi.divider def
        operationInput <- divClass "create-operation-body" $ do
          SemUi.header (def
            & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
            & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text (_operationText_definition opText)
          maybe blank (elClass "div" "create-operation-text" . el "p" . text) (_operationText_details opText)
          opInputWidget submitEv
        SemUi.divider def
        (cancelEv, submitEv) <- divClass "controls" $ do
          cancelEv' <- modalCancelButtonW "Cancel"
          continue' <- greenButtonW "Continue" $ constDyn False
          enterE <- getGlobalKeydownEventFor Enter
          let submitEv' = leftmost [continue', enterE]
          return (cancelEv', submitEv')
        let multisigCallE =  buildMultisigCall tokenInfo <$> operationInput
        return (cancelEv, (\multisigCall ->
          (connectLedgerWorkflow (_operationText_short opText) Nothing
            (\_ -> signOnLedgerPromptWorkflow (Just signingInfo) multisigCall Nothing opText))) <$> multisigCallE)

setPKHWorkflow :: (AppModalWidget t m, SetRoute t (R FrontendRoute) m) => Workflow t m (Event t ())
setPKHWorkflow = Workflow $ modalBoxFormW "Set PKH" $ do
  SemUi.divider def
  redirectE <- divClass "operation-state-error" $ do
    divClass "red-box" $ text "x"
    elClass "p" "operation-state-error-title" $ text "You must set your PKH before signing."
    -- TODO: User setRoute from Obelisk.Route.Frontend to redirect user to Users page
    divClass "operation-state-flex-inline" $ do
      elClass "p" "operation-state-error-desc" $ text "The key you will use for signing has not been set yet. Go to the"
      (e,_) <- elClass' "a" "operation-state-error-desc" $ text "Users page"
      let goToUserPage = domEvent Click e
      setRoute $ (FrontendRoute_UserManagement :/ ())  <$ goToUserPage
      elClass "p" "operation-state-error-desc" $ text "to set your PKH before signing."
      return goToUserPage
  SemUi.divider def
  doneE <- divClass "controls" $ do
    greenButtonW "Done" $ constDyn False
  return (leftmost [redirectE, doneE], never)

buildMultisigCall :: TokenInfo -> TokenOperation -> MultisigCall
buildMultisigCall tokenInfo tokenOp =
  let multisig = tokenInfo ^. tokenInfo_multiSignatureContractAddress
      counter = 0
      token = tokenInfo ^. tokenInfo_contractAddress
  in MultisigCall multisig counter (MultisigPayload_Call token tokenOp)

buildMultisigReconfig :: TokenInfo -> Int -> [(PublicKey, PublicKeyHash)] -> MultisigCall
buildMultisigReconfig tokenInfo signingThreshold authorizedSigningKeys =
  let multisig = tokenInfo ^. tokenInfo_multiSignatureContractAddress
      counter = 0
  in MultisigCall multisig counter (MultisigPayload_Reconfig signingThreshold authorizedSigningKeys)
