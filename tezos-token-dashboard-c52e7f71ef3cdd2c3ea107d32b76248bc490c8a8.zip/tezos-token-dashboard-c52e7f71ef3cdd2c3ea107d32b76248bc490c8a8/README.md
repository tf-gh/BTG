# BTG Pactual - ReitBZ Admin Dashboard

## Running a local mail server

To access the application, you'll need to receive an email sent to the address configured at `config/backend/first-admin-email`, which you can use to set up the first admin account. You can run a local mailserver for receiving this email with:

```bash
nix-shell -p mailcatcher --run "mailcatcher -f"
```

The inbox should then be accessible at http://localhost:1080.

## Building and running the docker image

### Building:

To build:

```bash
nix-build release.nix -A docker-image
```

To build and load directly into docker:

```bash
docker load < $(nix-build release.nix -A docker-image --no-out-link)
```

### Running:

After loading, you need a secrets directory containing certificate.pem, key.pem, conseil-api-key, and gas-wallet-sk, which will
also be provided to the backend as Obelisk configs:

```bash
# Directory 
mkdir secrets

# If you already have a self-signed certificate for Obelisk development:
cp $HOME/.config/*.pem secrets

# If you don't already have a self-signed certificate:
openssl req -newkey rsa:2048 -new -nodes -x509 -days 365 -keyout secrets/key.pem -out secrets/certificate.pem

cp config/backend/{conseil-api-key,gas-wallet-sk} secrets

# Obelisk is strict when gathering configs, so key.pem needs to be readable by a different user even though it isn't actually
# used by the application
chmod 664 secrets/key.pem
```

Since the Docker image gets wiped whenever it is restarted and we can't do updates in place, an external Postgres instance needs
to be available instead of the standard Obelisk domain socket. On `NixOS`, this can be configured in `/etc/nixos/configuration.nix` 
by adding: 

```nix
services.postgresql = {
  enable = true;
  port = 5432;
  enableTCPIP = true;
  authentication = pkgs.lib.mkOverride 10 ''
    local all all trust
    host all all 0.0.0.0/0 trust
  '';
};
```

Then running `nixos-rebuild switch`. You can verify that the instance is running with `sudo su - postgres -c "psql"`.

The application can then be configured to use this instance by adding the connection string to `secrets/db`: 

```bash 
echo postgresql://postgres@127.0.0.1:5432 > secrets/db
```

And with that directory set up and the config-as-envs in this repo, you can run the docker image with:

```bash
docker run -p 4443:4443 --env-file=config-as-envs --net="host" --mount type=bind,source=$(pwd)/secrets,destination=/run/secrets,ro tezos-token-dashboard:latest
```

The dashboard should be available on https://localhost:4443.

If the browser does not accept the SSL certificate, go to chrome://flags/#allow-insecure-localhost and set the option to true, which will allow a self-signed certificate only on localhost.

Note: The secrets implementation should be compatible with docker secrets named certificate.pem and key.pem, but this has not been tested.

## Tezos Development

Note: The `tezos-client` executable is available in `ob shell` and configured for Babylonnet.

### Creating Tezos account

1. Go to the faucet to get an account/tez - https://faucet.tzalpha.net/
2. Activate that with: `tezos-client activate account <alias> with <file-path>.json`
3. Then you've got yourself an account!

### Multisig Contract Deployment

```bash
tezos-client originate contract <contract_alias> transferring 0 from <account_alias> running <multisig_contract_file> --init '(Pair 0 (Pair 3 <list_of_authorized_signing_keys>))' --burn-cap 10
```

**Example:**

```bash
tezos-client -A obsidian.webhop.org -P 9142 originate contract multisig transferring 0 from btg-dev running /path/to/smart-contracts/MultiSig.tz --init '(Pair 0 (Pair 3 { "edpkuWqQD7Pi57mFjw8QkMyFDRPXHvj6NM48LhiZR7u9LHdMb1M2V9"; "edpkvW78mHP3dt34VK2L7Wqv8QrCv6ggZ87WMoWDMZakXxVuMtUwLB"; "edpkuJUKcMkKhFLLz86i4vVxQ2qintHyHLkV3RiRLfJRw4thYxW8LG"; "sppk7ZL4yNx2KzYv8wxHXDJwuVwrwt6Q6agwbA5aFaCbM1yGHz5LzPz"; "p2pk66cd1R5VygNw8bzeGoysHh71CQyEmj8DDEdHuVN1xQDPWusPQN8" }))' --burn-cap 10
```

Record the contract address in the output as it will be needed when deploying the token contract.

### Token Contract Deployment

```
tezos-client originate contract <contract_alias> transferring 0 from <account_alias> running <(btg contract) --init "$(btg storage <multisig_address>)" --burn-cap <burn_cap>
```

**Example:**

```bash
tezos-client -A obsidian.webhop.org -P 9142 originate contract token transferring 0 from btg-dev running <(btg contract) --init "$(btg storage KT1D7Sgb7ozr6BMixwpjisvkUh8tx2EjGytj)" --burn-cap 20
```

### Proxy Contracts for View Endpoints

To call view endpoints on the token contract, there needs to be a proxy contract deployed on the network whose storage type matches the return type of the endpoint. See [tzip](https://gitlab.com/tzip/tzip/blob/master/A/A1.md) for more information.

**Example:** For calling view endpoints that return a `nat`, a contract with the following parameters needs to be deployed, and its address needs to be passed in to `Tezos.NodeRPC.Helpers.callViewEndpoint` to retrieve the response:

```bash
tezos-client -A obsidian.webhop.org -P 9142 originate contract nat-target transferring 0 from btg-dev running '{ parameter nat ; storage nat; code { CAR ; NIL operation ; PAIR } }' --init 0 --burn-cap 0.3
```
