#!/bin/bash

ob thunk unpack dep/ledgerjs

nix-shell -p nodejs-10_x yarn libudev --run "\
  (cd ./dep/ledgerjs/packages/hw-transport;\
    yarn install && yarn build) &&\
  (cd ./dep/ledgerjs/packages/hw-transport-u2f;\
    yarn install && yarn build) &&\
  (cd ./dep/ledgerjs/packages/hw-app-xtz;\
    echo $'const Transport = require(\"@ledgerhq/hw-transport-u2f\").default; const App = require(\"@ledgerhq/hw-app-xtz\").default; module.exports = { app: App, transport: Transport };' > ./src/index.js &&\
    yarn add webpack webpack-cli && yarn install && yarn build && npx webpack --output-library \"ledger\" --mode development && cp ./dist/main.js ../../../../static/ledger.js)"

ob thunk pack --force dep/ledgerjs
