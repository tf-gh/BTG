{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Main where

import Backend.Token
import Control.Lens hiding ((:<))
import Control.Monad.IO.Class
import Control.Monad.Logger
import Data.Either
import qualified Data.List.NonEmpty as NonEmpty
import Data.Maybe
import Data.Sequence (ViewL (..), viewl)
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.Encoding as T
import Network.HTTP.Client
import Network.HTTP.Client.TLS
import Test.Hspec
import qualified Text.URI as URI
import Tezos.BabylonShim
import Tezos.Common.Chain
import Tezos.Common.NodeRPC.Sources
import Tezos.NodeRPC.Network
import Tezos.Token.Schema
import Tezos.V005.Account
import Tezos.V005.Block
import Tezos.V005.Contract
import Tezos.V005.Micheline (Expression (..), MichelinePrimAp (..))
import Tezos.V005.Michelson hiding (Left, Right)
import Tezos.V005.NodeRPC.Class
import Tezos.V005.Operation
import Tezos.V005.PublicKeyHash
import Tezos.V005.Typecheck

tokenContractId :: ContractId
tokenContractId = "KT1TBehFUfVrDaJ16Fq9nCS2tYoYMgMozK4G"

gasWalletPublicKeyHash :: PublicKeyHash
gasWalletPublicKeyHash = "tz1XVJ8bZUXs7r5NV8dHvuiBhzECvLRLR3jW"

tezosNodeUri :: Text
tezosNodeUri = "http://obsidian.webhop.org:9142"

main :: IO ()
main = do
  tezosPublicNodeContext <- liftIO mkTezosPublicNodeContext
  hspec $ spec tokenContractId gasWalletPublicKeyHash tezosPublicNodeContext

spec :: ContractId -> PublicKeyHash -> PublicNodeContext -> Spec
spec tokenContractId gasWalletPublicKeyHash tezosPublicNodeContext = do
  describe "Read Endpoints" $ do

    it "checkWhitelistedOnContract succeeds" $ do
      runEndpointTest (checkWhitelistedOnContract gasWalletPublicKeyHash tokenContractId tokenContractId) False

  describe "Write Endpoints" $ do

    it "SetPause typechecks" $ do
      runTypecheckTest $ SetPause False

    it "AddToWhitelist typechecks" $ do
      runTypecheckTest $ AddToWhitelist tokenContractId

    it "RemoveFromWhitelist typechecks" $ do
      runTypecheckTest $ RemoveFromWhitelist tokenContractId

    it "Mint typechecks" $ do
      runTypecheckTest $ Mint 100 tokenContractId

    it "Burn typechecks" $ do
      runTypecheckTest $ Burn 100 tokenContractId

    it "Transfer typechecks" $ do
      runTypecheckTest $ Transfer 10 tokenContractId tokenContractId

  where
    runTypecheckTest operation = do
      result <- runStdoutLoggingT $ runRPCCall tezosPublicNodeContext $ do
        chainId <- nodeRPC rChain
        headBlockHash <-  view (withProtocolHash_value . veryBlockLike_hash) <$> getCurrentHead chainId
        nodeRPC $ rTypecheckData chainId headBlockHash $ TypecheckData
          { _typecheckData_data = toMicheline operation
          , _typecheckData_type = getEndpointType operation
          , _typecheckData_gas = 10000
          }
      case result of
        Left err -> expectationFailure $ show err
        Right typecheckDataResult ->
          _typecheckDataResult_gas typecheckDataResult > 0 `shouldBe` True


    runEndpointTest rpcCall expected = do
      result <- runStdoutLoggingT $ runRPCCall tezosPublicNodeContext rpcCall
      case result of
        Right (Right response) -> response `shouldBe` expected
        Right (Left err) -> expectationFailure $ show err
        Left err -> expectationFailure $ show err


mkTezosPublicNodeContext :: IO PublicNodeContext
mkTezosPublicNodeContext = do
  httpManager <- newManager tlsManagerSettings
  return $ PublicNodeContext
    { _publicNodeContext_nodeCtx = NodeRPCContext
      { _nodeRPCContext_httpManager = httpManager
      , _nodeRPCContext_node = tezosNodeUri
      }
    , _publicNodeContext_api = Nothing
    }
