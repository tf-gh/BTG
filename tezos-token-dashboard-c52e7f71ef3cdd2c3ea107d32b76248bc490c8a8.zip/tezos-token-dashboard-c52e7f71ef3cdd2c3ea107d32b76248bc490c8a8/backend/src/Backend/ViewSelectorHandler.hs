{-# LANGUAGE DataKinds #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TupleSections #-}
{-# LANGUAGE TypeApplications #-}

module Backend.ViewSelectorHandler where

import Control.Lens
import Control.Monad (join, msum)
import Control.Monad.IO.Class
import Control.Monad.Logger
import Data.Aeson
import qualified Data.Map as Map
import qualified Data.Map.Monoidal as MMap
import Data.Maybe
import Data.Semigroup (First (..))
import qualified Data.Text as T
import qualified Data.Text.Encoding as T
import Data.Time.Clock
import Data.Time.Clock.POSIX
import Data.Traversable (for)
import Database.Groundhog.Postgresql
import Database.Id.Class
import Database.Id.Groundhog
import Network.HTTP.Client
import Rhyolite.Account
import Rhyolite.App
import Rhyolite.Backend.App
import Rhyolite.Backend.DB
import Rhyolite.Backend.Logging
import Rhyolite.Backend.Sign
import Rhyolite.SemiMap
import Text.URI (URI)
import Tezos.Common.Base58Check
import Tezos.Multisig.Schema
import Tezos.NodeRPC.Network
import Tezos.Token.Schema
import qualified Web.ClientSession as CS

import Backend.Config
import Backend.Conseil
import Backend.Schema
import Backend.Token
import Common.App
import Common.Schema

-- Queries database for requested data and returns it to the frontend
viewSelectorHandler
  :: Config
  -> QueryHandler (BTGViewSelector a) IO
viewSelectorHandler config = QueryHandler $ \vs -> runLoggingEnv (config ^. config_loggingEnv) $ runDb (Identity $ config ^. config_db) $ do

  let userInfoVS = _btgViewSelector_userInfo vs
  userInfoV <- iforM userInfoVS $ \_ q -> fmap (q,) queryUserInfoView

  let tokenInfoVS = _btgViewSelector_tokenInfo vs
  tokenInfoV <- iforM tokenInfoVS $ \_ q -> fmap (q,) queryTokenInfo

  let authorizedKeysVS = _btgViewSelector_authorizedKeys vs
  authorizedKeysV <- iforM authorizedKeysVS $ \_ q -> fmap (q,) queryAuthorizedKeys

  let loginSessionVS = _btgViewSelector_loginSession vs
  loginSessionV <- iforM loginSessionVS $ \(LoginSessionQuery_IsValidSession authToken) q -> fmap (q,) $ queryLoginSession (config ^. config_clientSessionKey) authToken

  let pendingOperationsVS = _btgViewSelector_pendingOperations vs
  pendingOperationsV <- iforM pendingOperationsVS $ \pendOpQuery q -> fmap (q,) $ queryPendingOperations pendOpQuery

  let operationSignatureVS = _btgViewSelector_operationSignature vs
  operationSignatureV <- iforM operationSignatureVS $ \opSigQuery q -> fmap (q,) $ queryOperationSignatures opSigQuery

  let signingInfoVS = _btgViewSelector_signingInfo vs
  signingInfoV <- iforM signingInfoVS $ \signingInfoQuery q -> fmap (q,) $ querySigningInfo signingInfoQuery

  let pastOperationsVS = _btgViewSelector_pastOperations vs
  pastOperationsV <- iforM pastOperationsVS $ \pastOpQuery q ->
    fmap (q,) $ queryPastOperations
      (_nodeRPCContext_httpManager $ _publicNodeContext_nodeCtx $ config ^. config_publicNodeContext)
      (config ^. config_conseilUri) (config ^. config_conseilApiKey)
      pastOpQuery

  return BTGView
    { _btgView_echo = MMap.mapWithKey (\_ v -> (v, First (Just ""))) $ _btgViewSelector_echo vs
    , _btgView_userInfo = userInfoV
    , _btgView_tokenInfo = tokenInfoV
    , _btgView_authorizedKeys = authorizedKeysV
    , _btgView_loginSession = loginSessionV
    , _btgView_pendingOperations = pendingOperationsV
    , _btgView_operationSignature = operationSignatureV
    , _btgView_signingInfo = signingInfoV
    , _btgView_pastOperations = pastOperationsV
    }

queryUserInfoView :: PersistBackend m => m (SemiMap (Id UserInfo) (Maybe UserInfoView))
queryUserInfoView = do
  allUsers :: [(Id UserInfo, UserInfo)] <- fmap (\(a,b) -> (toId a, b)) <$> project (AutoKeyField, UserInfoConstructor) (UserInfo_deletedField /=. (Just True))
  allUserViews <- for allUsers $ \(uid, user) -> do
    maybeSigningInfo <- getUserSigningInfo $ _userInfo_account user

    hasTwoFactorAuth <- listToMaybe <$> select (TwoFactorInfo_accountField ==. _userInfo_account user)
    pure $ (uid, UserInfoView
      { _userInfoView_name = _userInfo_name user
      , _userInfoView_email = _userInfo_email user
      , _userInfoView_role = _userInfo_role user
      , _userInfoView_account  = _userInfo_account user
      , _userInfoView_publicKeyHash = fmap _signingInfo_publicKeyHash maybeSigningInfo
      , _userInfoView_hasTwoFactorAuth = isJust hasTwoFactorAuth
      })
  let userMap = MMap.MonoidalMap $ Map.fromList $ fmap (\(k, info) -> (k, Just info)) allUserViews
  return $ SemiMap_Complete userMap

queryTokenInfo :: PersistBackend m => m (First (Maybe TokenInfo))
queryTokenInfo = do
  maybeTokenInfo <- listToMaybe <$> selectAll
  return $ case maybeTokenInfo of
    Just (_, tokenInfo :: TokenInfo) ->
      First (Just tokenInfo)
    Nothing ->
      First Nothing

queryAuthorizedKeys :: PersistBackend m => m (First (Maybe AuthorizedKeys))
queryAuthorizedKeys = do
  maybeAuthorizedKeys <- listToMaybe <$> select ((AuthorizedKeys_activeField ==. True) `orderBy` [Desc AuthorizedKeys_timestampField])
  return $ First maybeAuthorizedKeys


queryLoginSession :: PersistBackend m => CS.Key -> AppCredential BTG -> m (First Bool)
queryLoginSession csk authToken = do
  case readSignedWithKey csk authToken of
    Just (AuthToken (Identity accId), startTime) -> do
      loginSessions <- select $
        LoginSession_accountField ==. accId &&.
        LoginSession_startTimeField ==. startTime
      return $ First $ not $ null loginSessions
    _ ->
      return $ First False

queryPendingOperations :: PersistBackend m => PendingOperationsQuery -> m (SemiMap (Id PendingOperation) PendingOperation)
queryPendingOperations = \case
  PendingOperationsQuery_Pending -> do
    pending <- project
      (AutoKeyField, PendingOperationConstructor)
      ((PendingOperation_dismissedField /=. (Just True)))
    let pendOpMap = MMap.MonoidalMap $ Map.fromList $ fmap (\(k, info) -> (toId k, info)) pending
    return $ SemiMap_Complete pendOpMap

-- Probably wants to be grouped by PendingOperation and made into a map.
queryOperationSignatures :: PersistBackend m => OperationSignatureQuery -> m (SemiMap (Id OperationSignature) OperationSignature)
queryOperationSignatures (OperationSignatureQuery_ByPendingOperation pendingOpId) = do
  opSigs <- project (AutoKeyField, OperationSignatureConstructor) (OperationSignature_pendingOperationField ==. pendingOpId)
  let opSigMap = MMap.MonoidalMap $ Map.fromList $ fmap (\(k, info) -> (toId k, info)) opSigs
  return $ SemiMap_Complete opSigMap

querySigningInfo :: PersistBackend m => SigningInfoQuery -> m (First (Maybe SigningInfo))
querySigningInfo (SigningInfoQuery_OfUser aid) =
  First <$> getUserSigningInfo aid

getUserSigningInfo :: PersistBackend m => Id Account -> m (Maybe SigningInfo)
getUserSigningInfo accId = do
  maybeSigningInfoId :: Maybe (Id SigningInfo) <- join . listToMaybe <$> project UserInfo_signingInfoField (UserInfo_accountField ==. accId)
  maybeSigningInfo <- for maybeSigningInfoId $ \signingInfoId -> get $ fromId signingInfoId
  return $ join maybeSigningInfo

queryPastOperations
  :: (MonadIO m, MonadLogger m, PersistBackend m)
  => Manager -> URI -> ConseilAPIKey -> PastOperationsQuery -> m (SemiMap OperationHash PastOperation)
queryPastOperations httpManager conseilUri conseilApiKey = \case
  PastOperationsQuery_Conseil -> do
    result <- listToMaybe <$> project (TokenInfo_contractAddressField, TokenInfo_multiSignatureContractAddressField) (TokenInfo_nameField ==. tokenName)
    case result of
      Just (tokenContractAddress, multisigContractAddress) -> do
        maybePastOps <- queryConseil httpManager conseilUri conseilApiKey $ ConseilQuery
          { _conseilQuery_destinations = [ tokenContractAddress, multisigContractAddress ]
          , _conseilQuery_limit = 1000
          }
        case maybePastOps of
          Just pastOps -> do
            let pastOpMap = MMap.MonoidalMap $ Map.fromList $ catMaybes $ flip fmap pastOps $ \pastOp ->
                  let opTimestamp = millisToUTC $ _conseilQueryResult_timestamp pastOp
                      (Right opHash) = fromBase58 @'HashType_OperationHash $ T.encodeUtf8 $ _conseilQueryResult_operationGroupHash pastOp
                      rawOpParameters = _conseilQueryResult_parameters pastOp
                      {-
                         The reason for `T.dropWhile` is that when Conseil can't parse an operation's parameters, an error message is prepended to the value, which
                         needs to be truncated in order for JSON decoding to work.

                         E.g., "Unparsable code: {\"entrypoint\":\"main\", ..."
                      -}
                      maybeOpParameters = decodeStrict $ T.encodeUtf8 (T.dropWhile (/= '{') rawOpParameters)
                      maybeTokenOperation = do
                        opParameters <- maybeOpParameters
                        tokenOperation <- Tezos.Token.Schema.fromOpParameters opParameters
                        return $ MultisigPayload_Call tokenContractAddress tokenOperation
                      maybeMultisigReconfig = do
                        opParameters <- maybeOpParameters
                        (threshold, publicKeys) <- Tezos.Multisig.Schema.fromOpParameters opParameters
                        return $ MultisigPayload_Reconfig threshold ((\pk -> (pk, toPublicKeyHash pk)) <$> publicKeys)
                  in case msum [ maybeTokenOperation, maybeMultisigReconfig ] of
                      Just opParameters ->
                        Just (opHash, PastOperation opTimestamp opParameters opHash)
                      Nothing ->
                        Nothing
            return $ SemiMap_Complete pastOpMap
          Nothing ->
            return $ SemiMap_Complete $ MMap.MonoidalMap mempty
      _ ->
        return $ SemiMap_Complete $ MMap.MonoidalMap mempty
  where
    millisToUTC :: Integer -> UTCTime
    millisToUTC t = posixSecondsToUTCTime $ (fromInteger t) / 1000

