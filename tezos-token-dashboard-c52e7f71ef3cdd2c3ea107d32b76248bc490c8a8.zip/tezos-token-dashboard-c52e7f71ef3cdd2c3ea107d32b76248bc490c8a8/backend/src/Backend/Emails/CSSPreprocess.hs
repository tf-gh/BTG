{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE FlexibleContexts #-}
module Backend.Emails.CSSPreprocess where
import Data.FileEmbed
import qualified Data.ByteString as BS
import Obelisk.Route.Frontend
import Reflex
import Reflex.Dom
-- import Reflex.Dom.Builder.Static
import Language.Haskell.TH.Syntax
import Control.Monad.IO.Class
import System.Process
import System.Directory
import Paths_semantic_css
-- import Common.Route

preprocessCss
--  :: -(DomBuilder t m, RouteToUrl (R FrontendRoute) m, SetRoute t (R FrontendRoute) m)
  :: FilePath
  -> [SetRouteT (SpiderTimeline Global) r0 (RouteToUrlT r1 (PostBuildT DomTimeline (StaticDomBuilderT DomTimeline (PerformEventT DomTimeline DomHost)))) ()]
  -> Q Exp
preprocessCss cssFile emailBodies =
  liftIO (getPreprocessedCss cssFile emailBodies) >>= strToExp

getPreprocessedCss
--  :: -(DomBuilder t m, RouteToUrl (R FrontendRoute) m, SetRoute t (R FrontendRoute) m)
  :: FilePath
  -> [SetRouteT (SpiderTimeline Global) r0 (RouteToUrlT r1 (PostBuildT DomTimeline (StaticDomBuilderT DomTimeline (PerformEventT DomTimeline DomHost)))) ()]
  -> IO String
getPreprocessedCss cssFile emailBodies = do 
  -- The preprocessor is annoying and can't be driven from STDIN etc.
  liftIO $ do 
    cssSrcFile <- getDataFileName cssFile
    BS.writeFile emailBodiesFile ""
    sequence_ $ printEmail <$> emailBodies
    minCss <- readProcess "purifycss" [cssSrcFile, emailBodiesFile, "--min"] ""
    removeFile emailBodiesFile
    return minCss
  where
    -- cssFile = "cssFile.css"
    emailBodiesFile = "emailBodies.html"
    printEmail a = renderEmail a >>= BS.appendFile emailBodiesFile
renderEmail :: SetRouteT (SpiderTimeline Global) r0 (RouteToUrlT r1 (PostBuildT DomTimeline (StaticDomBuilderT DomTimeline (PerformEventT DomTimeline DomHost)))) () -> IO BS.ByteString
renderEmail = fmap snd . renderStatic . flip runRouteToUrlT (const "exampleurl") . runSetRouteT . el "html" . elAttr "body" ("class" =: "ui")
