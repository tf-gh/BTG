{-# LANGUAGE QuasiQuotes #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Backend.Migration where

import Control.Monad
import Control.Monad.IO.Class
import Rhyolite.Backend.DB.PsqlSimple

handleMigrations :: (PostgresRaw m, MonadIO m) => m ()
handleMigrations = do
  migrateUserInfoAccountId
  migrateUserInfoPublicKeyHash
  changePendingOpTargetParamToBytea
  dropContractTypeFromPendingOperation
  addMultisigReconfigPayloadMigration
  migrateAuthorizedKeys
  dropInDbMultisigCounter

migrateUserInfoAccountId :: (PostgresRaw m, MonadIO m) => m ()
migrateUserInfoAccountId = do
  [Only hasUserInfo] <- [queryQ|
    SELECT EXISTS
      (SELECT 1 FROM information_schema.columns
        WHERE table_name = 'UserInfo'
        AND table_schema = 'public'
      )
  |]

  [Only userInfoIsMissingAccount] <- [queryQ|
    SELECT NOT EXISTS
      (SELECT 1 FROM information_schema.columns
        WHERE column_name = 'account'
        AND table_name = 'UserInfo'
        AND table_schema = 'public'
      )
  |]

  when (hasUserInfo && userInfoIsMissingAccount) $ void $ [traceExecuteQ|
    ALTER TABLE "UserInfo" ADD COLUMN "account" bigint NULL;
    UPDATE "UserInfo"
    SET account = a.id
    FROM "Account" a
    WHERE a.account_email = email;
    ALTER TABLE "UserInfo" ALTER COLUMN "account" SET NOT NULL;
  |]

migrateUserInfoPublicKeyHash :: (PostgresRaw m, MonadIO m) => m ()
migrateUserInfoPublicKeyHash = do
  [Only hasUserInfoWithPKH] <- [queryQ|
    SELECT EXISTS
      (SELECT 1 FROM information_schema.columns
        WHERE column_name = 'publicKeyHash'
        AND table_name = 'UserInfo'
        AND table_schema = 'public'
      )
  |]

  when hasUserInfoWithPKH $ void $ [traceExecuteQ|
    ALTER TABLE "UserInfo" DROP COLUMN "publicKeyHash";
  |]

changePendingOpTargetParamToBytea :: (PostgresRaw m, MonadIO m) => m ()
changePendingOpTargetParamToBytea = do
  [Only hasTokenOperationTable] <- [queryQ|
    SELECT EXISTS
      (SELECT 1 FROM information_schema.columns
        WHERE column_name = 'operation#targetParameter'
        AND data_type = 'character varying'
        AND table_name = 'PendingOperation'
        AND table_schema = 'public'
      )
  |]

  when hasTokenOperationTable $ void $ [traceExecuteQ|
    TRUNCATE "PendingOperation" CASCADE;
    ALTER TABLE "PendingOperation" DROP COLUMN "operation#targetParameter";
    ALTER TABLE "PendingOperation" ADD COLUMN "operation#targetParameter" BYTEA;
  |]

dropContractTypeFromPendingOperation :: (PostgresRaw m, MonadIO m) => m ()
dropContractTypeFromPendingOperation = do
  [Only hasContractType] <- [queryQ|
    SELECT EXISTS
      (SELECT 1 FROM information_schema.columns
        WHERE column_name = 'operation#targetParameterType'
        AND table_name = 'PendingOperation'
        AND table_schema = 'public'
      )
  |]
  when hasContractType $ void [traceExecuteQ|
    ALTER TABLE "PendingOperation" DROP COLUMN "operation#targetParameterType";
  |]

addMultisigReconfigPayloadMigration :: (PostgresRaw m, MonadIO m) => m ()
addMultisigReconfigPayloadMigration = do
  [Only hasMultisigPayload] <- [queryQ|
    SELECT EXISTS
      (SELECT 1 FROM information_schema.columns
        WHERE table_name = 'MultisigPayload'
        AND table_schema = 'public'
      )
  |]

  when (not hasMultisigPayload) $ void [traceExecuteQ|
    DROP TABLE IF EXISTS "PendingOperation" CASCADE;
    DROP TABLE IF EXISTS "SentOperation" CASCADE;
    DROP TABLE IF EXISTS "OperationSignature" CASCADE;
  |]

migrateAuthorizedKeys :: (PostgresRaw m, MonadIO m) => m ()
migrateAuthorizedKeys = do
  [Only hasAuthorizedKey] <- [queryQ|
    SELECT EXISTS
      (SELECT 1 FROM information_schema.columns
        WHERE table_name = 'AuthorizedKey'
        AND table_schema = 'public'
      )
  |]

  when hasAuthorizedKey $ void [traceExecuteQ|
    DROP TABLE "AuthorizedKey" CASCADE;
  |]

dropInDbMultisigCounter :: (PostgresRaw m, MonadIO m) => m ()
dropInDbMultisigCounter = do
  [Only hasMultisigCounter] <- [queryQ|
    SELECT EXISTS
      (SELECT 1 FROM information_schema.columns
        WHERE table_name = 'TokenInfo'
        AND column_name = 'storedMultisigCounter'
        AND table_schema = 'public'
      )
  |]

  when hasMultisigCounter $ void [traceExecuteQ|
    ALTER TABLE "TokenInfo" DROP COLUMN "storedMultisigCounter";
  |]
