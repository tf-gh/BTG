{-# LANGUAGE AllowAmbiguousTypes #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PackageImports #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE TypeApplications #-}

module Backend.Token where

import Prelude hiding (id, span)

import Control.Lens hiding (Empty)
import Control.Monad.Except
import Control.Monad.Logger
import Control.Monad.Reader
import "cryptonite" Crypto.Hash (Blake2b, Digest, hash)
import Data.Aeson.Lens (_JSON)
import qualified Data.Aeson.Lens as Ae
import qualified Data.ByteArray as BA
import qualified Data.ByteString as BS
import Data.Dependent.Sum (DSum (..))
import Data.Either
import Data.Foldable (toList)
import qualified Data.List as List
import qualified Data.List.NonEmpty as NonEmpty
import qualified Data.Map as Map
import Data.Maybe (fromMaybe, isJust)
import Data.Sequence as Seq
import qualified Data.Set as Set
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.Encoding as T
import Tezos.BabylonShim
import qualified Tezos.Common.Binary as TB
import Tezos.Common.Chain
import Tezos.Common.Json
import Tezos.Common.NodeRPC.Types
import Tezos.NodeRPC.Helpers
import Tezos.NodeRPC.Network
import Tezos.V005.Contract
import Tezos.V005.Micheline
import Tezos.V005.Michelson hiding (Left, Right)
import Tezos.V005.NodeRPC.Class
import Tezos.V005.NodeRPC.CrossCompat
import Tezos.V005.Operation
import Tezos.V005.PublicKey
import Tezos.V005.Signature
import Tezos.V005.Types as V005

import Backend.OperationInjection
import Common.App
import Common.Schema
import Tezos.ExtraLenses
import Tezos.Multisig.Schema

newtype MultiSignatureContractId = MultiSignatureContractId { unMultiSignatureContractId :: ContractId }

data MultiSignatureContractStorage = MultiSignatureContractStorage
  { _multiSigContractStorage_storedCounter :: TezosWord64
  , _multiSigContractStorage_threshold :: TezosWord64
  , _multiSigContractStorage_allowedSigningKeys :: Seq PublicKey
  }

runRPCCall
  :: PublicNodeContext -> ExceptT RpcError (ReaderT PublicNodeContext m) a -> m (Either RpcError a)
runRPCCall node =
  flip runReaderT node . runExceptT @RpcError

getContract
  :: (MonadIO m, MonadLogger m, MonadReader s m, HasPublicNodeContext s, MonadError e m, AsRpcError e)
  => ContractId -> m Account
getContract contractId = do
    chainId <- nodeRPC rChain
    currentHead <- getCurrentHead chainId
    accountCrossCompat <- nodeRPC $ rContract contractId (ChainTag_Hash chainId) $
      view (withProtocolHash_value . veryBlockLike_hash) currentHead
    case accountCrossCompat of
      AccountV004 _ ->
        error "Received V004 account from node RPC, expected V005"
      AccountV005 acc ->
        return acc

getMultiSignatureContractStorage
  :: (MonadIO m, MonadLogger m, MonadReader s m, HasPublicNodeContext s, MonadError e m, AsRpcError e)
  => MultiSignatureContractId -> m (Maybe MultiSignatureContractStorage)
getMultiSignatureContractStorage msContractId = do
  contract <- getContract $ unMultiSignatureContractId msContractId
  let maybeStorage = fmap _contractScript_storage $ _account_script contract
  pure $ case maybeStorage of
    -- storage (pair (nat %stored_counter) (pair (nat %threshold) (list %keys key))) ;
    Just (Pair (Expression_Int storedCounter) (Pair (Expression_Int threshold) (Expression_Seq keys))) ->
      Just $ MultiSignatureContractStorage
        { _multiSigContractStorage_storedCounter = storedCounter
        , _multiSigContractStorage_threshold = threshold
        , _multiSigContractStorage_allowedSigningKeys = Seq.fromList $ rights $ toList $ fmap (\(Expression_String key) -> tryFromBase58 publicKeyConstructorDecoders $ T.encodeUtf8 key) keys
        }
    _ ->
      Nothing

getAdministratorFromContract
  :: (MonadIO m, MonadLogger m, MonadReader s m, HasPublicNodeContext s, MonadError e m, AsRpcError e)
  => PublicKeyHash -> ContractId -> m (Either String ContractId)
getAdministratorFromContract gasWallet tokenContract = do
    chainId <- nodeRPC rChain
    headBlockHash <- view (withProtocolHash_value . veryBlockLike_hash) <$> getCurrentHead chainId
    callViewEndpoint chainId headBlockHash gasWallet tokenContract
      "KT1PceKbaUerXY3KLeWnG8XAQn8KqaEtmtPF" -- Target contract address for babylonnet.
      "getAdministrator" (Prim0 "Unit")

getPausedStateFromContract
  :: (MonadIO m, MonadLogger m, MonadReader s m, HasPublicNodeContext s, MonadError e m, AsRpcError e)
  => PublicKeyHash -> ContractId -> m (Either ContractError Bool)
getPausedStateFromContract gasWallet tokenContract =
    callVoidEndpoint gasWallet tokenContract "getPaused" (Prim0 "Unit")

checkWhitelistedOnContract
  :: (MonadIO m, MonadLogger m, MonadReader s m, HasPublicNodeContext s, MonadError e m, AsRpcError e)
  => PublicKeyHash -> ContractId -> ContractId -> m (Either ContractError Bool)
checkWhitelistedOnContract gasWallet tokenContract address = do
  result <- callVoidEndpoint gasWallet tokenContract "checkWhitelisted" $ toMicheline address
  return $ case result of
    Right (Expression_Prim primExpression) ->
      let MichelinePrimitive primVal = _michelinePrimAp_prim primExpression
      in Right $ read $ T.unpack primVal
    Right expression ->
      Left $ ContractError_UnexpectedReturnType expression
    Left err ->
      Left err

getTokenHolderBalanceFromContract
  :: (MonadIO m, MonadLogger m, MonadReader s m, HasPublicNodeContext s, MonadError e m, AsRpcError e)
  => PublicKeyHash -> ContractId -> ContractId -> m (Either ContractError Integer)
getTokenHolderBalanceFromContract gasWallet tokenContract address = do
  chainId <- nodeRPC rChain
  headBlockHash <- view (withProtocolHash_value . veryBlockLike_hash) <$> getCurrentHead chainId
  result <- callViewEndpoint chainId headBlockHash gasWallet tokenContract
    "KT1GSuYsHtr38FwN2KpG1e9jcvyh49zJ6Wkr" -- Target contract address for babylonnet.
    "getBalance" (toMicheline address)
  return $ case result of
    Right (Expression_Int tezosWord) ->
      Right $ toInteger $ unTezosWord64 tezosWord
    Right expression ->
      Left $ ContractError_UnexpectedReturnType expression
    Left err ->
      Left $ ContractError_Unknown $ T.pack err

getTotalTokenSupplyFromContract
  :: (MonadIO m, MonadLogger m, MonadReader s m, HasPublicNodeContext s, MonadError e m, AsRpcError e)
  => PublicKeyHash -> ContractId -> m (Either ContractError Integer)
getTotalTokenSupplyFromContract gasWallet tokenContract = do
  chainId <- nodeRPC rChain
  headBlockHash <- view (withProtocolHash_value . veryBlockLike_hash) <$> getCurrentHead chainId
  result <- callViewEndpoint chainId headBlockHash gasWallet tokenContract
    "KT1GSuYsHtr38FwN2KpG1e9jcvyh49zJ6Wkr" -- Target contract address for babylonnet.
    "getTotalSupply" (Prim0 "Unit")
  return $ case result of
    Right (Expression_Int tezosWord) ->
      Right $ toInteger $ unTezosWord64 tezosWord
    Right expression ->
      Left $ ContractError_UnexpectedReturnType expression
    Left err ->
      Left $ ContractError_Unknown $ T.pack err

callVoidEndpoint
  :: (MonadIO m, MonadLogger m, MonadReader s m, HasPublicNodeContext s, MonadError e m, AsRpcError e, FromMicheline a)
  => PublicKeyHash -> ContractId -> Text -> Expression -> m (Either ContractError a)
callVoidEndpoint gasWallet tokenContract endpoint parameter = do
    chainId <- nodeRPC rChain
    headBlockHash <- view (withProtocolHash_value . veryBlockLike_hash) <$> getCurrentHead chainId
    simRes <- dryRunEndpoint chainId headBlockHash gasWallet tokenContract (T.encodeUtf8 endpoint) (Pair parameter noopLambda)
    case parseSimulationErrors <$> simRes ^? operationWithMetadata_contents . traverse of
      Just (ContractError_Rejected (Pair (Expression_String "VoidResult") expression)) ->
        case fromMicheline expression of
          Left err -> return $ Left $ ContractError_Unknown $ T.pack err
          Right a -> return $ Right a
      Just a -> return $ Left a
      Nothing -> return $ Left $ ContractError_Unknown "Something went wrong with dry run"
  where
    noopLambda = Expression_Seq $ mempty

sendTransactions
  :: ( MonadIO m
     , MonadLogger m
     , MonadReader s m
     , HasPublicNodeContext s
     , MonadError e m
     , AsRpcError e)
  => PublicKeyHash
  -> Seq OpContentsTransaction
  -> Seq OpContentsTransaction
  -> m (Seq OperationHash, Seq ContractError)
sendTransactions gasWallet contextTransactions toSend = do
  chainId <- nodeRPC rChain
  headBlockHash <- view (withProtocolHash_value . veryBlockLike_hash) <$> getCurrentHead chainId
  referenceBlocks <- nodeRPC $ rBlocks chainId (RawLevel 5) $ Set.singleton headBlockHash
  referenceBlockHash <- case Seq.viewr <$> headBlockHash `Map.lookup` referenceBlocks of
      Just (_ Seq.:> ref) -> pure ref
      _ -> error "Could not find reference block"
  protocolConstants <- nodeRPC $ rProtoConstants chainId headBlockHash

  let unAccountCrossCompat a =
        case a of
          AccountV004 _ ->
            error "Received V004 account from node RPC, expected V005"
          AccountV005 acc ->
            acc
  gasWalletBlockCounter <- fmap (succ . fromMaybe (error "Could not get gas wallet counter at current head") . _account_counter . unAccountCrossCompat) $ nodeRPC $
    rContract (Implicit gasWallet) (ChainTag_Hash chainId) headBlockHash
  let maxCosts = maximumCostsAndFees protocolConstants
      mkOCM (ctr, opTr) = OpContentsManager gasWallet 10 ctr (_costsAndFees_gas maxCosts) (_costsAndFees_storage maxCosts) opTr
      opContentsManagers = mkOCM <$> Seq.fromList (Prelude.zip [gasWalletBlockCounter..] (toList (contextTransactions <> toSend)))
      wrapOp (tag :=> contents) = tag :=> Op { _op_branch = headBlockHash, _op_contents = contents, _op_signature = dummySignature }
      dryrunBatch = wrapOp $ batchOperations $ NonEmpty.fromList $ toList $ (BatchableOp OpKindManagerTag_Transaction :=>) . OpContents_Transaction <$> opContentsManagers

  simRes <- nodeRPC $ rRunOperation chainId headBlockHash $ OpWithChain dryrunBatch chainId

  let toProcessResults = Seq.drop (Seq.length contextTransactions) $ Seq.zip opContentsManagers $ simRes ^. operationWithMetadata_contents
      (toSendResults, failedResults) = Seq.spanl isRight $ flip fmap toProcessResults $ \(oneTrans, oneRes) ->
        if not $ isSuccessOp oneRes
          then
            Left $ parseSimulationErrors oneRes
          else
            let thisOp = OpSingleTransactionTag :=> Op
                           { _op_branch = referenceBlockHash
                           , _op_contents = OpContentsList_Single $ OpContents_Transaction oneTrans
                           , _op_signature = Nothing
                           }
            in case calculateGasCosts protocolConstants (opLength thisOp) oneRes of
              Left a -> Left a
              Right costs -> do
                Right $ updateWithCosts costs thisOp

  injectionResponses <- mapM injectOperation $ (fmap (fromRight (error "spanl isRight passed a Left")) toSendResults)
  -- TODO: Stop injecting when the injection endpoint returns an error.

  let (sents, errOrBlocked) = Seq.spanl isRight injectionResponses

  return (fmap (fromRight "spanl isRight passed a Left") sents, (fromLeft ContractError_Blocked <$> errOrBlocked) <> (fromLeft ContractError_Blocked <$> failedResults))

  where
    dummySignature = Just "edsigtXomBKi5CTRf5cjATJWSyaRvhfYNHqSUGrn4SdbYRcGwQrUGjzEfQDTuqHhuA8b2d8NarZjz8TRf65WkpQmo423BtomS8Q"
    opLength :: DSum OpsKindTag Op -> Int
    opLength = BS.length . TB.encode
    isSuccessOp :: OperationContents -> Bool
    isSuccessOp a = isJust $
          a ^? _OperationContents_Transaction
          . operationContentsTransaction_metadata
          . managerOperationMetadata_operationResult
          . operationResult_status
          . _OperationResultStatus_Applied

parseSimulationErrors :: OperationContents -> ContractError
parseSimulationErrors simResult = fromMaybe unknownError $ mconcat
    [ const ContractError_GasExhausted <$> gasExhausted ^? traverse
    , const ContractError_StorageExhausted <$> storageExhausted ^? traverse
    , ContractError_Rejected <$> rejections ^? traverse . Ae.key "with" . _JSON
    ]
  where
   unknownError = ContractError_Unknown "Couldn't find errors but operation did not succeed"
   rejections = Seq.filter (fromMaybe False . fmap isMichelsonError . (^? Ae.key "id")) errorsJson
   fromJsonRpcError (JsonRpcError a) = a
   errorsJson = fmap fromJsonRpcError <$> fromMaybe Seq.Empty $
     simResult ^? _OperationContents_Transaction
     . operationContentsTransaction_metadata
     . managerOperationMetadata_operationResult
     . operationResult_errors . _Just
   -- And now we're off into json parsing for a moment becuase the gigantic
   -- tezos error schema is not imported...
   isMichelsonError errTxt = case T.split (=='.') <$> errTxt ^? Ae._String of
     Just ["proto", _, "michelson_v1", "script_rejected"] -> True
     _ -> False
   gasExhaustedIds = [ "proto.004-Pt24m4xi.gas_exhausted.operation" ]
   gasExhausted = Seq.filter (fromMaybe False . fmap (`elem` gasExhaustedIds) . (^? Ae.key "id")) errorsJson
   storageExhaustedIds = [ "proto.003-PsddFKi3.storage_exhausted.operation" ]
   storageExhausted = Seq.filter (fromMaybe False . fmap (`elem` storageExhaustedIds) . (^? Ae.key "id")) errorsJson

data CostsAndFees = CostsAndFees
  { _costsAndFees_gas :: TezosWord64
  , _costsAndFees_storage :: TezosWord64
  , _costsAndFees_fee :: Tez
  }

feeCalculation :: ProtoInfo -> TezosWord64 -> Int -> Tez
feeCalculation ProtoInfo { _protoInfo_costPerByte = costPerByte } consumedGas opLength
  = microTez $ 1281 + 21 + baseFee + (fromIntegral (getMicroTez costPerByte) * opLength) + perGasFee consumedGas
  where
    baseFee = 1281
    perGasFee gas = fromIntegral $ gas `div` 10

maximumCostsAndFees :: ProtoInfo -> CostsAndFees
maximumCostsAndFees
  protoInfo@ProtoInfo
    { _protoInfo_hardGasLimitPerOperation = gas
    , _protoInfo_hardStorageLimitPerOperation = storage
    , _protoInfo_maxOperationDataLength = maxLength
    }
  = CostsAndFees
    { _costsAndFees_gas = gas
    , _costsAndFees_storage = storage
    , _costsAndFees_fee = feeCalculation protoInfo gas maxLength
    }

-- calculateGasCostsOrErrors should always find costs if we call it, but might
-- pass back a ContractError if the cost we calculate plus tolerance exceeds
-- the limit.

calculateGasCosts :: ProtoInfo -> Int -> OperationContents -> Either ContractError CostsAndFees
calculateGasCosts protocolConstants opLength simRes =
    case simRes ^? costLens of
      Nothing -> Left $ ContractError_Unknown "Cost missing from successful response"
      Just costs -> do
        let internalOpConsumedGas = flip sumOf simRes $
              internalOpLens . operationResultTransaction_consumedGas
            internalOpPaidStorageDiff = flip sumOf simRes $
              internalOpLens . operationResultTransaction_paidStorageSizeDiff
            consumedGas = internalOpConsumedGas
              + costs ^. operationResultTransaction_consumedGas
            availGas = consumedGas + 100
            paidStorageDiff = internalOpPaidStorageDiff
              + costs ^. operationResultTransaction_paidStorageSizeDiff
            availStorage = paidStorageDiff + 10
            fee = feeCalculation protocolConstants availGas opLength

        when (availGas > gas_max) $ Left $ ContractError_TooMuchGas $
          "Operation would require too much gas. Estimated: "
             <> displayTezosWord64 availGas
             <> ". Max: " <> displayTezosWord64 gas_max
        when (availStorage > storage_max) $ Left $ ContractError_TooMuchStorage $
          "Operation would require too much storage. Estimated: "
            <> displayTezosWord64 availStorage
            <> ". Max: " <> displayTezosWord64 storage_max

        Right $ CostsAndFees
          { _costsAndFees_gas = availGas
          , _costsAndFees_storage = availStorage
          , _costsAndFees_fee = fee
          }
  where
    displayTezosWord64 = T.pack . show . toInteger
    gas_max = _protoInfo_hardGasLimitPerOperation protocolConstants
    storage_max = _protoInfo_hardStorageLimitPerOperation protocolConstants
    costLens = _OperationContents_Transaction
          . operationContentsTransaction_metadata
          . managerOperationMetadata_operationResult
          . operationResult_content . _Just
    internalOpLens
          = _OperationContents_Transaction
          . operationContentsTransaction_metadata
          . managerOperationMetadata_internalOperationResults
          . _Just
          . traverse
          . _InternalOperationResult_Transaction
          . internalOperationContentsTransaction_result

updateWithCosts :: CostsAndFees -> DSum OpsKindTag Op -> DSum OpsKindTag Op
updateWithCosts CostsAndFees
  { _costsAndFees_gas = gas
  , _costsAndFees_storage=storage
  , _costsAndFees_fee=fee}
  opToUpdate
  = opToUpdate
     & onlyTransactions
     . op_contents
     . _OpContentsList_Single
     . _OpContents_Transaction
     %~ ( (opContentsManager_fee .~ fee)
        . (opContentsManager_gasLimit .~ gas)
        . (opContentsManager_storageLimit .~ storage)
        )

buildMultisigOp
  :: CostsAndFees
  -> BlockHash
  -> PublicKeyHash
  -> TezosWord64
  -> MultisigCallWithSignatures
  -> DSum OpsKindTag Op
buildMultisigOp
  CostsAndFees { _costsAndFees_gas = gas, _costsAndFees_storage = storage }
  block account counter parameter =
  OpSingleTransactionTag :=> Op
    { _op_branch = block
    , _op_contents = opContents
    , _op_signature = dummySignature
    }
  where
    contract = _multisigCall_multisig $ _multisigCallWithSignatures_call parameter
    opTransfer = OpContentsTransaction 0 contract $ Just $ OpParameters (EntrypointOther $ EntrypointName "main") $ toMicheline parameter
    opContents = OpContentsList_Single $ OpContents_Transaction $ OpContentsManager account 10 counter gas storage opTransfer
    -- This needs to fit the format of a valid signature for simulation and calculating length, but is not checked.
    dummySignature = Just "edsigtXomBKi5CTRf5cjATJWSyaRvhfYNHqSUGrn4SdbYRcGwQrUGjzEfQDTuqHhuA8b2d8NarZjz8TRf65WkpQmo423BtomS8Q"

endpointCallToOpContentsTransaction :: IsEndpointCall a => ContractId -> a -> OpContentsTransaction
endpointCallToOpContentsTransaction contract a =
  OpContentsTransaction 0 contract $ Just $ OpParameters (EntrypointOther $ EntrypointName $ T.encodeUtf8 $ getEndpoint a) $ toMicheline a

alignSignaturesWithSigningKeys :: [OperationSignature] -> [PublicKey] -> [Maybe Signature]
alignSignaturesWithSigningKeys opSigs keys =
  let orderedOpSigs = (\key -> List.find (\sig -> _operationSignature_signingKey sig == key) opSigs) <$> keys
  in fmap _operationSignature_signature <$> orderedOpSigs

getGasWalletCounterOnChain
  :: (MonadIO m, MonadLogger m, MonadReader s m, HasPublicNodeContext s, MonadError e m, AsRpcError e)
  => PublicKeyHash
  -> m TezosWord64
getGasWalletCounterOnChain gasWallet = do
  gasWalletAccount <- getContract (Implicit gasWallet)
  return $ fromMaybe (error "No counter value for gas wallet") $ _account_counter gasWalletAccount


toPublicKeyHash :: PublicKey -> PublicKeyHash
toPublicKeyHash publicKey =
  case publicKey of
    PublicKey_Ed25519 pkHv ->
      PublicKeyHash_Ed25519 $ runHash pkHv
    PublicKey_Secp256k1 pkHv ->
      PublicKeyHash_Secp256k1 $ runHash pkHv
    PublicKey_P256 pkHv ->
      PublicKeyHash_P256 $ runHash pkHv
  where
    runHash = HashedValue . toShort . BS.pack . BA.unpack . (Crypto.Hash.hash :: BS.ByteString -> Digest (Blake2b 160)) . fromShort . unHashedValue
