{-# LANGUAGE DeriveAnyClass #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE TemplateHaskell #-}

module Backend.Conseil where

import Backend.Config
import Control.Monad.Except
import Control.Monad.Logger
import Data.Aeson
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.Encoding as T
import Network.HTTP.Client
import Network.HTTP.Types.Header
import Network.HTTP.Types.Status
import Text.URI (URI)
import qualified Text.URI as URI
import Tezos.V005.Contract

data ConseilQuery = ConseilQuery
  { _conseilQuery_destinations :: [ContractId]
  , _conseilQuery_limit :: Int
  }

instance ToJSON ConseilQuery where
  toJSON query = object
    [ "fields" .= (["timestamp", "parameters", "operation_group_hash"] :: [Text])
    , "predicates" .=
      [ object
        [ "field" .= ("destination" :: Text)
        , "operation" .= ("in" :: Text)
        , "set" .= fmap toContractIdText (_conseilQuery_destinations query)
        ]
      , object
        [ "field" .= ("kind" :: Text)
        , "operation" .=  ("in" :: Text)
        , "set" .= ([ "transaction" ] :: [Text])
        ]
      ]
    , "orderBy" .=
      [ object
        [ "field" .= ("timestamp" :: Text)
        , "direction" .= ("desc" :: Text)
        ]
      ]
    , "limit" .= _conseilQuery_limit query
    ]


data ConseilQueryResult = ConseilQueryResult
  { _conseilQueryResult_timestamp :: Integer
  , _conseilQueryResult_parameters :: Text
  , _conseilQueryResult_operationGroupHash :: Text
  }

instance FromJSON ConseilQueryResult where
  parseJSON =  withObject "ConseilQueryResult" $ \o -> do
    oTimestamp <- o .: "timestamp"
    oParameters <- o .: "parameters"
    oOperationGroupHash <- o .: "operation_group_hash"
    pure $ ConseilQueryResult oTimestamp oParameters oOperationGroupHash


queryConseil
  :: (MonadIO m, MonadLogger m)
  => Manager -> URI -> ConseilAPIKey -> ConseilQuery -> m (Maybe [ConseilQueryResult])
queryConseil httpManager conseilUri conseilApiKey conseilQuery = do
  initialRequest <- liftIO $ parseRequest $ T.unpack $ URI.render conseilUri <> "/operations"
  let request = initialRequest
        { method = "POST"
        , requestBody = RequestBodyLBS $ encode conseilQuery
        , requestHeaders =
            [ (hContentType, "application/json")
            , ("apiKey", T.encodeUtf8 $ unConseilAPIKey conseilApiKey)
            ]
        }
  response <- liftIO $ httpLbs request httpManager
  case statusCode $ responseStatus response of
    200 ->
      return $ decode $ responseBody response
    statusCodeValue -> do
      $(logErrorS) "TOKEN" $ T.pack (show statusCodeValue) <> " response from Conseil API: " <> T.pack (show (responseBody response))
      return Nothing



