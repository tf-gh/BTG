{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE TemplateHaskell #-}

module Backend.Config where

import Control.Lens
import Control.Monad (join)
import Control.Monad.IO.Class
import qualified Data.Aeson as Aeson
import Data.ByteString (ByteString)
import Data.Map (Map)
import qualified Data.Map as Map
import Data.Pool
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.Encoding as T
import Database.Groundhog.Postgresql
import Network.HTTP.Client
import Network.HTTP.Client.TLS
import Rhyolite.Backend.Email
import Rhyolite.Backend.Logging
import Text.URI (URI)
import qualified Text.URI as URI
import Tezos.NodeRPC.Network
import Tezos.V005.PublicKeyHash
import qualified Web.ClientSession as CS

import Common.App

newtype ConseilAPIKey = ConseilAPIKey { unConseilAPIKey :: Text }

data Config
  = Config
  { _config_db :: !(Pool Postgresql)
  , _config_baseUrl :: !Text
  , _config_clientSessionKey :: !CS.Key
  , _config_emailEnv :: !EmailEnv
  , _config_loggingEnv :: !LoggingEnv
  , _config_publicNodeContext :: !PublicNodeContext
  , _config_gasWallet :: !PublicKeyHash
  , _config_conseilUri :: !URI
  , _config_conseilApiKey :: !ConseilAPIKey
  , _config_firstAdminEmail :: !EmailAddress
  }

makeLenses ''Config

mkConfig :: MonadIO m => Map Text ByteString -> LoggingEnv -> Pool Postgresql ->  m Config
mkConfig configs logger db = do
  csk <- liftIO $ CS.getKey "clientSessionKey"
  let (Just emailEnv) = do
        maybeEmailText <- Map.lookup "backend/email" configs
        Aeson.decodeStrict maybeEmailText
  let (Just baseUrl) = Map.lookup "common/route" configs
  let (Just (Right gasWallet)) = tryReadPublicKeyHashText . T.strip . T.decodeUtf8 <$> Map.lookup "backend/gas-wallet-pkh" configs
  let (Just conseilUri) = join $ URI.mkURI . T.strip . T.decodeUtf8 <$> Map.lookup "backend/conseil-uri" configs
  let (Just conseilApiKey) = T.strip . T.decodeUtf8 <$> Map.lookup "backend/conseil-api-key" configs
  let (Just tezosNodeUri) = join $ URI.mkURI . T.strip . T.decodeUtf8 <$> Map.lookup "backend/tezos-node-uri" configs
  let (Just firstAdminEmail) = T.strip . T.decodeUtf8 <$> Map.lookup "backend/first-admin-email" configs
  httpManager <- liftIO $ newManager tlsManagerSettings

  return $ Config
    { _config_db = db
    , _config_clientSessionKey = csk
    , _config_emailEnv = emailEnv
    , _config_baseUrl = T.decodeUtf8 baseUrl
    , _config_loggingEnv = logger
    , _config_publicNodeContext = PublicNodeContext
      { _publicNodeContext_nodeCtx = NodeRPCContext
        { _nodeRPCContext_httpManager = httpManager
        , _nodeRPCContext_node = URI.render tezosNodeUri
        }
      , _publicNodeContext_api = Nothing
      }
    , _config_gasWallet = gasWallet
    , _config_conseilUri = conseilUri
    , _config_conseilApiKey = ConseilAPIKey conseilApiKey
    , _config_firstAdminEmail = EmailAddress firstAdminEmail
    }
