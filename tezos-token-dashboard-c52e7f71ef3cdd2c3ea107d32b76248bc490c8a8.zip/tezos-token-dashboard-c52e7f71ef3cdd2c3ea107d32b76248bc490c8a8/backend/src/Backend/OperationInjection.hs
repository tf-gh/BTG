{-# LANGUAGE DataKinds #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE TypeApplications #-}

module Backend.OperationInjection
  ( injectOperation
  , testReadingInjectionMethod
  ) where

import Control.Lens hiding ((.=))
import Control.Monad.Except
import Control.Monad.Logger
import Control.Monad.Reader
import Data.Aeson
import qualified Data.ByteString as BS
import qualified Data.ByteString.Base16 as BS16
import qualified Data.ByteString.Lazy as LBS
import Data.Dependent.Sum (DSum (..))
import qualified Data.Map as Map
import qualified Data.Text as T
import qualified Data.Text.Encoding as T
import Network.HTTP.Client
import Network.HTTP.Types.Header
import Network.HTTP.Types.Status
import Obelisk.ExecutableConfig.Lookup
import Tezos.Common.Base58Check
import qualified Tezos.Common.Binary as TB
import Tezos.Common.NodeRPC.Types
import Tezos.NodeRPC.Network
import qualified Tezos.Signature.Sign as TS
import Tezos.V005.NodeRPC.Class
import Tezos.V005.Operation

import Common.App
import Tezos.ExtraLenses

data InjectionMethod
  = InMemorySigningKey TS.SecretKeyInMemory
  | LambdaEndpoint String String
  deriving (Show)

instance FromJSON InjectionMethod where
  parseJSON =  withObject "InjectionMethod" $ \o -> do
    maybeSecretKey <- o .:? "secretKey"
    maybeUrl <- o .:? "url"
    maybeApiKey <- o .:? "apiKey"
    case (maybeSecretKey, maybeUrl, maybeApiKey) of
      (Just secretKeyRaw, Nothing, Nothing) ->
        case TS.tryReadSecretKeyInMemory $ T.encodeUtf8 $ T.pack secretKeyRaw of
          Right secretKey ->
            return $ InMemorySigningKey secretKey
          Left _ ->
            fail "Invalid signing key."
      (Nothing, Just url, Just apiKey) ->
        return $ LambdaEndpoint url apiKey
      _ ->
        fail "Invalid injection configuration."

injectOperation
  :: forall m s e .
     ( MonadIO m
     , MonadLogger m
     , MonadReader s m
     , HasPublicNodeContext s
     , MonadError e m
     , AsRpcError e
     )
  => DSum OpsKindTag Op -> m (Either ContractError OperationHash)
injectOperation operation = do
  let encodedOperation = TB.encode operation

  injectionMethod <- liftIO getInjectionMethod
  case injectionMethod of

    Right (InMemorySigningKey secretKey) ->
      case TS.sign secretKey $ BS.cons 3 encodedOperation of
        Just signature -> do
          let signedOp = operation & onlyTransactions . op_signature .~ Just signature
          Right <$> nodeRPC (rInjectOperation signedOp)
        _ ->
          return $ Left $ ContractError_Injection "Error signing with in memory secret key."

    Right (LambdaEndpoint url apiKey) -> do
      initialRequest <- liftIO $ parseRequest url
      let request = initialRequest
            { method = "POST"
            , requestBody = RequestBodyLBS $ encode $ object
                [ "op" .=  T.decodeUtf8 (BS16.encode encodedOperation) ]
            , requestHeaders =
                [ (hContentType, "application/json")
                , ("x-api-key", T.encodeUtf8 $ T.pack apiKey)
                ]
            }
      httpManager <- asks (_nodeRPCContext_httpManager . view nodeRPCContext)
      response <- liftIO $ httpLbs request httpManager
      case statusCode $ responseStatus response of
        200 ->
          -- Stripping and removing double quotes since the lambda endpoint is returning the hash with an added newline and double quote.
          -- Will report to Blockscale, but since this works and is a forward compatible solution, it isn't urgent.
          let responseBodyText = T.replace "\"" "" $ T.strip $ T.decodeUtf8 $ LBS.toStrict $ responseBody response
          in case fromBase58 @'HashType_OperationHash $ T.encodeUtf8 responseBodyText of
            Right operationHash ->
              return $ Right operationHash
            Left _ ->
              return $ Left $ ContractError_Injection $ "Error reading operation hash returned from lambda injection endpoint: " <>  responseBodyText
        _ -> do
          let errorResponse = T.decodeUtf8 $ LBS.toStrict $ responseBody response
          $(logErrorS) "TOKEN" $ "Error injecting operation: " <> errorResponse
          return $ Left $ ContractError_Injection errorResponse

    Left _ ->
      return $ Left $ ContractError_Unknown "Error reading configuration file for signing method."

getInjectionMethod :: IO (Either String InjectionMethod)
getInjectionMethod = do
  let configFileName = "backend/gas-wallet-sk"
  configs <- liftIO getConfigs
  case Map.lookup configFileName configs of
    Just gasWalletSecretKey ->
      return $ eitherDecodeStrict gasWalletSecretKey
    Nothing ->
      return $ Left $ "Config not found at " <> T.unpack configFileName

testReadingInjectionMethod :: IO ()
testReadingInjectionMethod = do
  injectionMethod <- getInjectionMethod
  case injectionMethod of
    Right _ -> return ()
    Left err -> error $ "Error reading configuration for operation injection: " <> err
