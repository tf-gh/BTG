{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}

module Backend.Emails where

import Common.Route
import Data.Functor.Identity
import Obelisk.Route
import Obelisk.Route.Frontend
import Reflex.Dom
import Rhyolite.Account
import Rhyolite.Sign
import Data.Text


data EmailBodyConfig
  = EmailBodyConfig
  { emailBodyConfig_title :: Text
  , emailBodyConfig_description :: Text
  , emailBodyConfig_secondaryMessage :: Text
  , emailBodyConfig_buttonValue :: Text
  , emailBodyConfig_route :: R FrontendRoute
  , emailBodyConfig_css :: Text
  }

emailExamples :: (DomBuilder t m, RouteToUrl (R FrontendRoute) m, SetRoute t (R FrontendRoute) m) => [m ()]
emailExamples = [resetPasswordEmail_example, inviteUserEmail_example]

resetPasswordEmail_example :: (DomBuilder t m, RouteToUrl (R FrontendRoute) m, SetRoute t (R FrontendRoute) m) => m ()
resetPasswordEmail_example = buildPasswordResetEmail "" (Signed "PLACEHOLDER")

buildPasswordResetEmail
  :: (DomBuilder t m, RouteToUrl (R FrontendRoute) m, SetRoute t (R FrontendRoute) m)
  => Text -> Signed (PasswordResetToken Identity) -> m ()
buildPasswordResetEmail emailCss resetToken = buildEmail $ EmailBodyConfig
  { emailBodyConfig_title = "Reset Password"
  , emailBodyConfig_description = "A password recovery request has been made for your account."
  , emailBodyConfig_secondaryMessage = "If you did not make this request you can ignore this email."
  , emailBodyConfig_buttonValue = "Reset Password"
  , emailBodyConfig_route = FrontendRoute_ResetPassword :/ AccountRoute_PasswordReset resetToken
  , emailBodyConfig_css = emailCss
  }

inviteUserEmail_example :: (DomBuilder t m, RouteToUrl (R FrontendRoute) m, SetRoute t (R FrontendRoute) m) => m ()
inviteUserEmail_example = buildUserInviteEmail "" (Signed "PLACEHOLDER")

buildUserInviteEmail
  :: (DomBuilder t m, RouteToUrl (R FrontendRoute) m, SetRoute t (R FrontendRoute) m)
  => Text -> Signed (PasswordResetToken Identity) -> m ()
buildUserInviteEmail emailCss resetToken = buildEmail $ EmailBodyConfig
  { emailBodyConfig_title = "You’ve been invited!"
  , emailBodyConfig_description = "You’ve been invited to Token Management Dashboard."
  , emailBodyConfig_secondaryMessage = "Click below to create an account."
  , emailBodyConfig_buttonValue = "Create Account"
  , emailBodyConfig_route = FrontendRoute_CreateAccount :/ AccountRoute_PasswordReset resetToken
  , emailBodyConfig_css = emailCss
  }

buildEmail
  :: (DomBuilder t m, RouteToUrl (R FrontendRoute) m, SetRoute t (R FrontendRoute) m)
  => EmailBodyConfig -> m ()
buildEmail config = do
  el "html" $ do
    el "head" $
      el "style" $ text $ emailBodyConfig_css config
    elAttr "body" ("class" =: "ui") $ do
      elAttr "header"
        ("class" =: "ui header left aligned" <>
         "style" =: "height: fit-content; background-color: #f8f8f8; padding:30px 20px 30px 80px;"
         ) $ text "Token Management Dashboard"
      elClass "div" "ui center aligned" $ do
        elClass "div" "column twelve wide" $ do
          elAttr "div"
            ("class" =: "ui header center aligned huge" <>
             "style" =: "padding-top: 50px; padding-bottom: 40px;"
            ) $ text $ emailBodyConfig_title config
          elAttr "div" ("style" =: "text-align: center") $ do
            elAttr "h3" ("style" =: "padding-bottom: 20px;") $ text $ emailBodyConfig_description config
            el "p" $ text $ emailBodyConfig_secondaryMessage config
            routeToUrl <- askRouteToUrl
            elAttr "form" ("action" =: routeToUrl (emailBodyConfig_route config) <> "target" =: "_blank") $
              elAttr "button"
                ("class" =: "ui button blue" <>
                "style" =: "width: 400px; margin-top: 40px; margin-bottom: 30px;" <>
                "type" =: "submit"
                ) $ text $ emailBodyConfig_buttonValue config
            elAttr "p" ("style" =: "padding-bottom: 10px;") $ text "Or use this link:"
            elAttr "div" ("style" =: "width: 80%; max-width: 800px; word-break: break-all; margin:0 auto 0 auto;") $ routeLink (emailBodyConfig_route config) $ text $ routeToUrl $ emailBodyConfig_route config
  pure ()
