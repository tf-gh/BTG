{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}

module Tezos.BabylonShim where

import Prelude hiding (pattern Left, pattern Right)

import qualified Data.Text as T
import Tezos.V005.Micheline
import Tezos.V005.Michelson

class ToMicheline a => IsEndpointCall a where
  getEndpoint :: a -> T.Text
  getEndpointType :: a -> Expression

getContractExpression :: IsEndpointCall a => a -> Expression
getContractExpression call = 
  Expression_Prim $ MichelinePrimAp 
    (MichelinePrimitive "CONTRACT")
    (pure $ getEndpointType call)
    (pure $ Annotation_Field $ getEndpoint call)

