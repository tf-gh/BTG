module Common.Api where

commonStuff :: String
commonStuff = "Here is a string defined in code common to the frontend and backend."
