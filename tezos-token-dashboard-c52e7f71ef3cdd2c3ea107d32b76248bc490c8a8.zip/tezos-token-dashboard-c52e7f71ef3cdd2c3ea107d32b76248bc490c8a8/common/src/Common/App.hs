{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE UndecidableInstances #-}
{-# LANGUAGE DeriveAnyClass #-}
{-# LANGUAGE DeriveFunctor #-}
{-# LANGUAGE DeriveFoldable #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DeriveTraversable #-}
{-# LANGUAGE EmptyCase #-}

module Common.App where

import Control.Lens
import Data.Aeson
import Data.Align
import Data.Map.Monoidal
import qualified Data.Map.Monoidal as MMap
import Data.Text (Text)
import Data.ByteString
import qualified Data.Text as T
import Data.Semigroup (First)
import Data.Time
import Data.Witherable
import Data.Word
import GHC.Generics
import Reflex hiding (Request)
import Rhyolite.Account
import Rhyolite.App
import Rhyolite.Request.TH
import Database.Id.Class
import Rhyolite.Schema
import Rhyolite.SemiMap
import Rhyolite.Sign
import qualified Tezos.V005.Account as TZ
import Tezos.V005.Contract
import Tezos.V005.Micheline
import Tezos.Multisig.Schema
import Tezos.V005.Types (OperationHash)

import Common.Schema

data BTG = BTG

tokenName :: Text
tokenName = "ReitBZ" -- TODO: don't hardcode, add to setup form

tokenTickerSymbol :: Text
tokenTickerSymbol = "RBZ" -- TODO: don't hardcode, add to setup form

authCookieKey :: Text
authCookieKey = "auth"

data LoginResponse = LoginResponse
  { _loginResponse_authToken :: AppCredential BTG
  , _loginResponse_userInfo :: UserInfo
  }
  deriving (Generic, FromJSON, ToJSON)

-- TODO: Place in a config file
haveIBeenPwnedApiHost :: Text
haveIBeenPwnedApiHost = "https://api.pwnedpasswords.com/range"

numOfRequiredSignatures :: Int
numOfRequiredSignatures = 3

data SignatureCount = SignatureCount Int
  deriving (Eq, Ord, Show, Generic, FromJSON, ToJSON)

type BTGResponse r = Either BTGError r

data BTGError
  = BTGError_AuthError Text
  | BTGError_UserError Text
  | BTGError_OperationDismissed Text -- operation signature fails due to operation being cancelled
  | BTGError_OperationSignatureSatisfied Text -- operation signature fails due to operation already being sent to blockchain
  | BTGError_OperationSignaturePositionChange Int -- operation signature halted due to signature position change
  | BTGError_OperationSignatureInvalid -- operation signature failed due to invalid signature and/or wrong signing ledger device
  | BTGError_RequiresTwoFactorAuth
  deriving (Eq, Ord, Generic, FromJSON, ToJSON)

instance Show BTGError where
  show (BTGError_AuthError msg) = T.unpack msg
  show (BTGError_UserError msg) = T.unpack msg
  show (BTGError_OperationDismissed msg ) = T.unpack msg
  show (BTGError_OperationSignatureSatisfied msg ) = T.unpack msg
  show (BTGError_OperationSignaturePositionChange pos ) = show pos
  show (BTGError_OperationSignatureInvalid) = "Signing failed. Wrong Ledger device."
  show (BTGError_RequiresTwoFactorAuth) = "This action requires two-factor authentication."


data ContractError
  = ContractError_TooMuchGas Text
  | ContractError_TooMuchStorage Text
  | ContractError_GasExhausted
  | ContractError_StorageExhausted
  | ContractError_Rejected Expression
  | ContractError_UnexpectedReturnType Expression
  | ContractError_Blocked
  | ContractError_Injection Text
  | ContractError_Unknown Text
  deriving (Show)

-- I believe at the moment we will only ever get one actual error at a time
-- from the node; if that proves to be incorrect we might revisit this.
instance Semigroup ContractError where
  (<>) = const

data AppAction = AppAction_DeleteUser
               | AppAction_ChangeUserType
               | AppAction_SetupToken
               | AppAction_InviteUser
               | AppAction_OperationRow
               | AppAction_PendingOperationAction
  deriving (Eq, Ord, Show)

newtype TokenAddress = TokenAddress {unTokenAddress :: Text}
  deriving (ToJSON, FromJSON, Generic)

newtype EmailAddress = EmailAddress { unEmailAddress :: Text }
  deriving (ToJSON, FromJSON, Generic)

checkUserPermissions :: AppAction -> UserInfo -> Bool
checkUserPermissions action userInfo =
  let userRole = _userInfo_role userInfo
  in case action of
    AppAction_DeleteUser -> userRole == Role_Admin
    AppAction_ChangeUserType -> userRole == Role_Admin
    AppAction_SetupToken -> userRole == Role_Admin
    AppAction_InviteUser -> userRole == Role_Admin
    AppAction_OperationRow -> userRole == Role_Admin
    AppAction_PendingOperationAction -> userRole == Role_Admin

data Blake2bHashSize
  = Blake2bHashSize_20
  | Blake2bHashSize_32
  deriving (Generic, FromJSON, ToJSON)

data WhitelistCheck = WhitelistCheck
  { _whitelistCheck_alreadyWhitelisted :: Bool
  , _whitelistCheck_pendingOperation :: Maybe (Id PendingOperation, PendingOperation)
  } deriving (Generic, FromJSON, ToJSON)

data TwoFactorMAC = TwoFactorMAC
  { _twoFactorMAC_Secret :: ByteString
  , _twoFactorMAC_UID :: Id Account
  } deriving (Generic, FromJSON, ToJSON)

data TwoFactorSecret = TwoFactorSecret
  { _twoFactorSecret_Secret :: Text
  , _twoFactorSecret_QR :: Text
  -- this is for enforcing that the key was generated by us.
  , _twoFactorSecret_MAC :: Signed TwoFactorMAC
  } deriving (Generic, FromJSON, ToJSON)

instance HasRequest BTG where
  data PublicRequest BTG a where
    PublicRequest_Login :: Email -> Text -> Maybe Word32 -> PublicRequest BTG (BTGResponse LoginResponse)
    PublicRequest_CreateAccount :: Signed (PasswordResetToken Identity) -> Text -> Text -> PublicRequest BTG (BTGResponse LoginResponse)
    PublicRequest_PasswordResetRequest :: Email -> PublicRequest BTG (BTGResponse ())
    PublicRequest_PasswordReset :: Signed (PasswordResetToken Identity) -> Text -> Maybe Word32 -> PublicRequest BTG (BTGResponse LoginResponse)
    PublicRequest_RunBlake2bHash :: Blake2bHashSize -> ByteString -> PublicRequest BTG (BTGResponse ByteString)
    PublicRequest_GetTotalTokenSupply :: PublicRequest BTG (BTGResponse Integer)
  data PrivateRequest BTG a where
    PrivateRequest_Logout :: PrivateRequest BTG (BTGResponse ())
    PrivateRequest_DeleteAccount :: Id UserInfo -> PrivateRequest BTG (Either BTGError ())
    PrivateRequest_Validate :: PrivateRequest BTG (BTGResponse LoginResponse)
    PrivateRequest_InviteUser :: EmailAddress -> PrivateRequest BTG (BTGResponse ())
    PrivateRequest_ChangeUserRole :: Id UserInfo -> Role -> Maybe Word32 -> PrivateRequest BTG (BTGResponse ())
    PrivateRequest_ChangePassword :: Text -> Text -> Maybe Word32 -> PrivateRequest BTG (BTGResponse ())
    PrivateRequest_New2FASecret :: PrivateRequest BTG (BTGResponse TwoFactorSecret)
    PrivateRequest_Set2FASecret :: Signed TwoFactorMAC -> Word32 -> PrivateRequest BTG (BTGResponse ())
    PrivateRequest_CreateTokenInfo :: Text -> Text -> Text -> PrivateRequest BTG (BTGResponse ())
    PrivateRequest_DeleteTokenInfo :: PrivateRequest BTG (BTGResponse ())
    PrivateRequest_SeeGasWalletBalance :: PrivateRequest BTG (BTGResponse TZ.Account)
    PrivateRequest_UpdateSigningInfo :: SigningInfo -> PrivateRequest BTG (BTGResponse ())
    PrivateRequest_AddPendingOperation :: MultisigCall -> PrivateRequest BTG (BTGResponse (Id PendingOperation, MultisigCall))
    PrivateRequest_DismissOperation :: Id PendingOperation -> PrivateRequest BTG (BTGResponse ())
    PrivateRequest_AddOperationSignature :: OperationSignature -> SignatureCount -> PrivateRequest BTG (BTGResponse (Maybe OperationHash))
    PrivateRequest_CancelOperation :: Id PendingOperation -> PrivateRequest BTG (BTGResponse ())
    PrivateRequest_GetPaused :: ContractId -> PrivateRequest BTG (BTGResponse Bool)
    PrivateRequest_CheckWhitelist :: ContractId -> PrivateRequest BTG (BTGResponse WhitelistCheck)
    PrivateRequest_CheckWhitelistBatch :: [ContractId] -> PrivateRequest BTG (BTGResponse [(ContractId, Bool)])
    PrivateRequest_GetTokenHolderBalance :: ContractId -> PrivateRequest BTG (BTGResponse Integer)
  type AppCredential BTG = Signed (AuthToken Identity, UTCTime)


data UserInfoQuery = UserInfoQuery_AllUsers
                   | UserInfoQuery_User (Id UserInfo)
  deriving (Eq, Ord, Show, Read, Generic)
instance ToJSON UserInfoQuery
instance FromJSON UserInfoQuery
instance ToJSONKey UserInfoQuery
instance FromJSONKey UserInfoQuery

data TokenInfoQuery = TokenInfoQuery_Token
  deriving (Eq, Ord, Show, Read, Generic)
instance ToJSON TokenInfoQuery
instance FromJSON TokenInfoQuery
instance ToJSONKey TokenInfoQuery
instance FromJSONKey TokenInfoQuery

data AuthorizedKeysQuery = AuthorizedKeysQuery_ActiveKeys
  deriving (Eq, Ord, Show, Read, Generic)
instance ToJSON AuthorizedKeysQuery
instance FromJSON AuthorizedKeysQuery
instance ToJSONKey AuthorizedKeysQuery
instance FromJSONKey AuthorizedKeysQuery

data LoginSessionQuery = LoginSessionQuery_IsValidSession (AppCredential BTG)
  deriving (Eq, Ord, Show, Generic)
instance ToJSON LoginSessionQuery
instance FromJSON LoginSessionQuery
instance ToJSONKey LoginSessionQuery
instance FromJSONKey LoginSessionQuery

data PendingOperationsQuery = PendingOperationsQuery_Pending
  deriving (Eq, Ord, Show, Read, Generic)
instance ToJSON PendingOperationsQuery
instance FromJSON PendingOperationsQuery
instance ToJSONKey PendingOperationsQuery
instance FromJSONKey PendingOperationsQuery

data OperationSignatureQuery = OperationSignatureQuery_ByPendingOperation (Id PendingOperation)
  deriving (Eq, Ord, Show, Read, Generic)
instance ToJSON OperationSignatureQuery
instance FromJSON OperationSignatureQuery
instance ToJSONKey OperationSignatureQuery
instance FromJSONKey OperationSignatureQuery

data SigningInfoQuery = SigningInfoQuery_OfUser (Id Account)
  deriving (Eq, Ord, Show, Read, Generic)
instance ToJSON SigningInfoQuery
instance FromJSON SigningInfoQuery
instance ToJSONKey SigningInfoQuery
instance FromJSONKey SigningInfoQuery

data PastOperationsQuery = PastOperationsQuery_Conseil
  deriving (Eq, Ord, Show, Read, Generic)
instance ToJSON PastOperationsQuery
instance FromJSON PastOperationsQuery
instance ToJSONKey PastOperationsQuery
instance FromJSONKey PastOperationsQuery

data BTGView a = BTGView
  { _btgView_echo :: MonoidalMap Text (a, First (Maybe Text))
  , _btgView_userInfo :: MonoidalMap UserInfoQuery (a, SemiMap (Id UserInfo) (Maybe UserInfoView))
  , _btgView_tokenInfo :: MonoidalMap TokenInfoQuery (a, First (Maybe TokenInfo))
  , _btgView_authorizedKeys:: MonoidalMap AuthorizedKeysQuery (a, First (Maybe AuthorizedKeys))
  , _btgView_loginSession :: MonoidalMap LoginSessionQuery (a, First Bool)
  , _btgView_pendingOperations :: MonoidalMap PendingOperationsQuery (a, SemiMap (Id PendingOperation) PendingOperation)
  , _btgView_operationSignature :: MonoidalMap OperationSignatureQuery (a, SemiMap (Id OperationSignature) OperationSignature)
  , _btgView_signingInfo :: MonoidalMap SigningInfoQuery (a, First (Maybe SigningInfo))
  , _btgView_pastOperations :: MonoidalMap PastOperationsQuery (a, SemiMap OperationHash PastOperation)
  }
  deriving (Eq, Show, Functor, Foldable, Generic)

data BTGViewSelector a = BTGViewSelector
  { _btgViewSelector_echo :: MonoidalMap Text a
  , _btgViewSelector_userInfo :: MonoidalMap UserInfoQuery a
  , _btgViewSelector_tokenInfo :: MonoidalMap TokenInfoQuery a
  , _btgViewSelector_authorizedKeys:: MonoidalMap AuthorizedKeysQuery a
  , _btgViewSelector_loginSession :: MonoidalMap LoginSessionQuery a
  , _btgViewSelector_pendingOperations :: MonoidalMap PendingOperationsQuery a
  , _btgViewSelector_operationSignature :: MonoidalMap OperationSignatureQuery a
  , _btgViewSelector_signingInfo :: MonoidalMap SigningInfoQuery a
  , _btgViewSelector_pastOperations :: MonoidalMap PastOperationsQuery a
  }
  deriving (Eq, Show, Functor, Foldable, Generic, Traversable)

instance HasView BTG where
  type View BTG = BTGView
  type ViewSelector BTG = BTGViewSelector

instance Group (BTGViewSelector SelectedCount) where
  negateG = fmap negateG

instance Additive (BTGViewSelector SelectedCount)

instance (Semigroup a) => Monoid (BTGViewSelector a) where
  mempty = nil
  mappend = salign

instance (Semigroup a) => Semigroup (BTGViewSelector a) where
  (<>) = mappend

instance Align BTGViewSelector where
  nil = BTGViewSelector
    { _btgViewSelector_echo = MMap.empty
    , _btgViewSelector_userInfo = MMap.empty
    , _btgViewSelector_tokenInfo = MMap.empty
    , _btgViewSelector_authorizedKeys = MMap.empty
    , _btgViewSelector_loginSession = MMap.empty
    , _btgViewSelector_pendingOperations = MMap.empty
    , _btgViewSelector_operationSignature = MMap.empty
    , _btgViewSelector_signingInfo = MMap.empty
    , _btgViewSelector_pastOperations = MMap.empty
    }
  alignWith f a b = BTGViewSelector
    { _btgViewSelector_echo = alignWith f (_btgViewSelector_echo a) (_btgViewSelector_echo b)
    , _btgViewSelector_userInfo = alignWith f (_btgViewSelector_userInfo a) (_btgViewSelector_userInfo b)
    , _btgViewSelector_tokenInfo = alignWith f (_btgViewSelector_tokenInfo a) (_btgViewSelector_tokenInfo b)
    , _btgViewSelector_authorizedKeys = alignWith f (_btgViewSelector_authorizedKeys a) (_btgViewSelector_authorizedKeys b)
    , _btgViewSelector_loginSession = alignWith f (_btgViewSelector_loginSession a) (_btgViewSelector_loginSession b)
    , _btgViewSelector_pendingOperations = alignWith f (_btgViewSelector_pendingOperations a) (_btgViewSelector_pendingOperations b)
    , _btgViewSelector_operationSignature = alignWith f (_btgViewSelector_operationSignature a) (_btgViewSelector_operationSignature b)
    , _btgViewSelector_signingInfo = alignWith f (_btgViewSelector_signingInfo a) (_btgViewSelector_signingInfo b)
    , _btgViewSelector_pastOperations = alignWith f (_btgViewSelector_pastOperations a) (_btgViewSelector_pastOperations b)
    }

instance Filterable BTGViewSelector where
  mapMaybe f a = BTGViewSelector
    { _btgViewSelector_echo = fmapMaybe f $ _btgViewSelector_echo a
    , _btgViewSelector_userInfo = fmapMaybe f $ _btgViewSelector_userInfo a
    , _btgViewSelector_tokenInfo = fmapMaybe f $ _btgViewSelector_tokenInfo a
    , _btgViewSelector_authorizedKeys = fmapMaybe f $ _btgViewSelector_authorizedKeys a
    , _btgViewSelector_loginSession = fmapMaybe f $ _btgViewSelector_loginSession a
    , _btgViewSelector_pendingOperations = fmapMaybe f $ _btgViewSelector_pendingOperations a
    , _btgViewSelector_operationSignature = fmapMaybe f $ _btgViewSelector_operationSignature a
    , _btgViewSelector_signingInfo = fmapMaybe f $ _btgViewSelector_signingInfo a
    , _btgViewSelector_pastOperations = fmapMaybe f $ _btgViewSelector_pastOperations a
    }

instance Filterable BTGView where
  mapMaybe f a = BTGView
    { _btgView_echo = fmapMaybeFst f $ _btgView_echo a
    , _btgView_userInfo = fmapMaybeFst f $ _btgView_userInfo a
    , _btgView_tokenInfo = fmapMaybeFst f $ _btgView_tokenInfo a
    , _btgView_authorizedKeys = fmapMaybeFst f $ _btgView_authorizedKeys a
    , _btgView_loginSession = fmapMaybeFst f $ _btgView_loginSession a
    , _btgView_pendingOperations = fmapMaybeFst f $ _btgView_pendingOperations a
    , _btgView_operationSignature = fmapMaybeFst f $ _btgView_operationSignature a
    , _btgView_signingInfo = fmapMaybeFst f $ _btgView_signingInfo a
    , _btgView_pastOperations = fmapMaybeFst f $ _btgView_pastOperations a
    }

instance (Semigroup a) => Monoid (BTGView a) where
  mempty = BTGView
    { _btgView_echo = MMap.empty
    , _btgView_userInfo = MMap.empty
    , _btgView_tokenInfo = MMap.empty
    , _btgView_authorizedKeys = MMap.empty
    , _btgView_loginSession = MMap.empty
    , _btgView_pendingOperations = MMap.empty
    , _btgView_operationSignature = MMap.empty
    , _btgView_signingInfo = MMap.empty
    , _btgView_pastOperations = MMap.empty
    }
  mappend a b = BTGView
    { _btgView_echo = _btgView_echo a <> _btgView_echo b
    , _btgView_userInfo = _btgView_userInfo a <> _btgView_userInfo b
    , _btgView_tokenInfo = _btgView_tokenInfo a <> _btgView_tokenInfo b
    , _btgView_authorizedKeys = _btgView_authorizedKeys a <> _btgView_authorizedKeys b
    , _btgView_loginSession = _btgView_loginSession a <> _btgView_loginSession b
    , _btgView_pendingOperations = _btgView_pendingOperations a <> _btgView_pendingOperations b
    , _btgView_operationSignature = _btgView_operationSignature a <> _btgView_operationSignature b
    , _btgView_signingInfo = _btgView_signingInfo a <> _btgView_signingInfo b
    , _btgView_pastOperations = _btgView_pastOperations a <> _btgView_pastOperations b
    }

instance (Semigroup a) => Semigroup (BTGView a) where
  (<>) = mappend

instance (Semigroup a) => Query (BTGViewSelector a) where
  type QueryResult (BTGViewSelector a) = BTGView a
  crop vs v =
      BTGView
        { _btgView_echo = MMap.intersectionWith const (_btgView_echo v) (_btgViewSelector_echo vs)
        , _btgView_userInfo = MMap.intersectionWith const (_btgView_userInfo v) (_btgViewSelector_userInfo vs)
        , _btgView_tokenInfo = MMap.intersectionWith const (_btgView_tokenInfo v) (_btgViewSelector_tokenInfo vs)
        , _btgView_authorizedKeys = MMap.intersectionWith const (_btgView_authorizedKeys v) (_btgViewSelector_authorizedKeys vs)
        , _btgView_loginSession = MMap.intersectionWith const (_btgView_loginSession v) (_btgViewSelector_loginSession vs)
        , _btgView_pendingOperations = MMap.intersectionWith const (_btgView_pendingOperations v) (_btgViewSelector_pendingOperations vs)
        , _btgView_operationSignature = MMap.intersectionWith const (_btgView_operationSignature v) (_btgViewSelector_operationSignature vs)
        , _btgView_signingInfo = MMap.intersectionWith const (_btgView_signingInfo v) (_btgViewSelector_signingInfo vs)
        , _btgView_pastOperations = MMap.intersectionWith const (_btgView_pastOperations v) (_btgViewSelector_pastOperations vs)
        }

instance ToJSON a => ToJSON (BTGView a)
instance FromJSON a => FromJSON (BTGView a)
instance ToJSON a => ToJSON (BTGViewSelector a)
instance FromJSON a => FromJSON (BTGViewSelector a)

makeRequestForDataInstance ''PublicRequest ''BTG
makeRequestForDataInstance ''PrivateRequest ''BTG
