{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecursiveDo #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TupleSections #-}
{-# LANGUAGE TypeApplications #-}

module Frontend where

import Clay (render)
import Control.Lens
import Control.Monad (join)
import Control.Monad.Reader
import Data.Align
import Data.Bool
import Data.Either
import Data.Either.Combinators (rightToMaybe)
import Data.Functor (($>))
import Data.Functor.Identity (Identity (..))
import Data.Maybe hiding (catMaybes)
import Data.Semigroup
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.Encoding as T
import qualified Data.Text.Lazy as LT
import Data.These
import Formatting (sformat, fixed)
import GHCJS.DOM (currentWindowUnchecked)
import GHCJS.DOM.EventM (on)
import GHCJS.DOM.GlobalEventHandlers (keyDown)
import qualified Obelisk.Configs as Cfg
import Obelisk.Frontend
import Obelisk.Generated.Static
import Obelisk.Route
import Obelisk.Route.Frontend
import Reflex.Dom
import qualified Reflex.Dom.SemanticUI as SemUi
import Rhyolite.Account
import Rhyolite.Api
import Rhyolite.App
import Rhyolite.Frontend.App hiding (FrontendConfig)
import Rhyolite.Frontend.Cookie
import Rhyolite.Frontend.Modal.Base
import Rhyolite.Frontend.Modal.Class
import qualified Tezos.V005.Types as TZ
import Web.Cookie

import Common.App
import Common.Route
import Common.Schema
import Frontend.App
import Frontend.CSS
import Frontend.Token
import Frontend.Users
import Frontend.Watch
import Frontend.Widgets

frontend :: Frontend (R FrontendRoute)
frontend = Frontend
  { _frontend_head = headW
  , _frontend_body = do
    route <- getConfigText "common/route"
    let websocketUrl = case route of
          Nothing -> error "Invalid websocket route"
          Just wsroute -> toWebSocketAddr $ wsroute <> (renderBackendRoute checkedRouteEncoder $ BackendRoute_Listen :/ ())

    prerender_ blank $ do
      _ <- runRhyoliteWidget websocketUrl $ runModalT (ModalBackdropConfig $ "class"=:"modal-backdrop") bodyW
      pure ()
  }
  where
    toWebSocketAddr addr = case T.unpack addr of
      'h':'t':'t':'p':'s':rest -> T.pack $ 'w':'s':'s':rest
      'h':'t':'t':'p':rest -> T.pack $ 'w':'s':rest
      _ -> error $ "Invalid websocket route: addr is " <> (T.unpack addr)
    getConfigText key = do
      val <- Cfg.getConfig key
      pure $ T.decodeUtf8 <$> val

headW :: DomBuilder t m => m ()
headW = do
  el "title" $ text "Tezos Token Dashboard"
  mkStyleSheetLink $ static @"semantic.min.css"
  mkStyleSheetLink $ static @"fontawesome-free-5.3.1-web/css/all.min.css"
  elAttr "script" ("type" =: "text/javascript" <> "src" =: static @"ledger.js") blank
  el "style" . text . LT.toStrict . render $ clayCss
    where
      mkStyleSheetLink name =
        elAttr "link" ("rel" =: "stylesheet" <> "href" =: name) blank

bodyW
  :: forall t m. (BaseAppWidget t m, ModalConstraints t m, RouteConstraints t FrontendRoute m, SetRoute t (R FrontendRoute) (ModalM m))
  => m ()
bodyW = mdo
  authCookieE <- signInWithCookieW
  signedInUserD <- holdDyn Nothing $ leftmost [ authCookieE, switchDyn loginResponseDE ]
  dynMaybeToken <- watchTokenInfo $ constDyn TokenInfoQuery_Token
  dynMaybeMaybeToken <- holdDyn Nothing $ Just <$> updated dynMaybeToken

  loginResponseDE <- widgetHold (pure never) $ ffor (updated signedInUserD) $ \loginState -> mdo
    isValidSessionD <- case loginState of
      Just loginSession -> do
        isValidSessionFirstD <- watchIsValidSession $ constDyn $ LoginSessionQuery_IsValidSession $ _loginResponse_authToken loginSession
        pure $ getFirst <$> isValidSessionFirstD
      Nothing ->
        pure $ constDyn False

    window <- currentWindowUnchecked
    globalKeydownE <- wrapDomEvent window (`on` keyDown) getKeyEvent
    let mkFrontendConfig signedInUser = FrontendConfig
          { _frontendConfig_signedInUser = signedInUser
          , _frontendConfig_globalKeydownEvent = keyCodeLookup . fromIntegral <$> globalKeydownE
          }

    loginDE <- dyn $ ffor dynMaybeMaybeToken $ \mmTokenInfo ->
      flip runReaderT (mkFrontendConfig $ (\(LoginResponse authToken userInfo) -> SignedInUser authToken userInfo) <$> loginState) $ mdo
        (signInE, logoutE) <- headerW loginState
        case mmTokenInfo of
          Nothing ->
            pure never
          Just (First maybeTokenInfo) -> mdo
            showLoginD <- holdDyn False $ leftmost [ True <$ signInE, False <$ ffilter isJust loggedInE ]
            routeD <- askRoute
            uniqRouteD <- holdUniqDyn routeD
            loggedInDE <- flip runRoutedT uniqRouteD $ subRoute $ \route -> do
              case route of
                FrontendRoute_Main -> do
                  pb <- getPostBuild
                  setRoute $ (FrontendRoute_Token :/ ()) <$ pb
                  pure never
                FrontendRoute_Token ->
                  switchHold never <=< dyn $ ffor showLoginD $ \case
                    True -> do
                      workflowDyn <- workflow signInWorkflow
                      pure $ Just <$> switchDyn workflowDyn
                    False -> do
                      tokenPage maybeTokenInfo
                      pure never
                FrontendRoute_UserManagement -> do
                  case loginState of
                    Just _ -> do
                      userManagementPage maybeTokenInfo
                      pure never
                    Nothing -> do
                      workflowDyn <- workflow signInWorkflow
                      pure $ Just <$> switchDyn workflowDyn
                FrontendRoute_CreateAccount -> do
                  createAccountTokenD <- askRoute
                  workflowD <- workflow $ createAccountWorkflow loginState createAccountTokenD
                  let loggedInInnerE = switchDyn workflowD
                  setRoute $ (FrontendRoute_Main :/ ()) <$ ffilter isJust loggedInInnerE
                  pure loggedInInnerE
                FrontendRoute_ResetPassword -> do
                  case loginState of
                    Just _ -> do
                      pb <- getPostBuild
                      setRoute $ (FrontendRoute_Main :/ ()) <$ pb
                      pure never
                    Nothing -> do
                      resetPasswordTokenD <- askRoute
                      workflowDyn <- workflow $ resetPasswordWorkflow resetPasswordTokenD
                      pure $ Just <$> switchDyn workflowDyn
                FrontendRoute_Debug -> do
                  debugW
                  pure never
            let loggedInE = switchDyn loggedInDE
                sessionExpiredE = ffilter (== False) $ updated isValidSessionD
            setRoute $ (FrontendRoute_Main :/ ()) <$ sessionExpiredE
            pure $ leftmost [ Nothing <$ logoutE, loggedInE, Nothing <$ sessionExpiredE ]
    switchHold never loginDE
  pure ()

data AccountAction
  = ChangePassword
  | SignOut
  deriving (Eq, Ord)

instance Show AccountAction where
  show = \case
    ChangePassword -> "Change Password"
    SignOut -> "Sign Out"

headerW
  :: forall t m. (AppWidget t m, RouteConstraints t FrontendRoute m)
  => Maybe LoginResponse -> m (Event t (), Event t ())
headerW maybeLoginResponse = do
  elClass "div" "nav-bar" $ do
    divClass "upper-left-nav" $ do
      el "h3" $ text "Token Management Dashboard"
      case maybeLoginResponse of
        Just loginResponse -> do
          divClass "gas-wallet-balance-container" $ do
            elClass "i" "fas fa-gas-pump" blank
            let reqPrep = ApiRequest_Private (_loginResponse_authToken loginResponse) $ PrivateRequest_SeeGasWalletBalance
            pb <- getPostBuild
            res <- requestingIdentity $ reqPrep <$ pb
            widgetHold_ blank $ ffor res $ \case
              Left err -> do
                liftIO $ print err
                text "Unknown"
              Right tzAccount -> do
                text $ sformat (fixed 2) (div (TZ.getMicroTez (TZ._account_balance tzAccount)) 1000000)
                text " ꜩ"
        Nothing -> blank
    case maybeLoginResponse of
      Just (loginResponse :: LoginResponse)-> mdo
        SemUi.menu (def & SemUi.menuConfig_secondary SemUi.|~ True) $ do
         routeSelector (FrontendRoute_Token :/ ()) SemUi.menuItem' def $
           text "Token"
         routeSelector (FrontendRoute_UserManagement :/ ()) SemUi.menuItem' def $
           text "User Management"
        let ddConfig = def
              { SemUi._dropdownConfig_placeholder = pure $ (_userInfo_email $ _loginResponse_userInfo loginResponse) <> " - My Account"
              , SemUi._dropdownConfig_selection = pure False
              , SemUi._dropdownConfig_fluid = pure True
              , SemUi._dropdownConfig_inline = pure True
              , SemUi._dropdownConfig_pointing = pure False
              , SemUi._dropdownConfig_compact = pure True
              , SemUi._dropdownConfig_unselectable = True
              , SemUi._dropdownConfig_search = Nothing
              }
        accDropdown <- divClass "account-dropdown" $ do
          dd <- dropdownMenu ddConfig ChangePassword never $ SemUi.TaggedStatic [ChangePassword, SignOut]
          text $ (_userInfo_email $ _loginResponse_userInfo loginResponse) <> (" - My Account" :: Text)
          return dd
        let accountDropdownEv = updated accDropdown
            (signOutEv, changePwEv) = fanEither $ ffor accountDropdownEv $ \case
              SignOut -> Left ("Sign Out" :: Text)
              _ -> Right ("Change Password" :: Text)
        triggerModal <- delay 0.3 changePwEv
        widgetHold_ blank $ ffor changePwEv $ \_ ->
          tellModal $ triggerModal $> (\closeE -> do
            workflowDyn <- workflow $ changePasswordWorkflow $ _loginResponse_authToken loginResponse
            pure $ leftmost [closeE, switchDyn workflowDyn])
        logoutEvent <- signOutW (_loginResponse_authToken loginResponse) signOutEv
        setRoute $ (FrontendRoute_Main :/ ()) <$ logoutEvent
        return (never, logoutEvent)
      Nothing -> do
        (signInEl, _) <- elClass' "div" "account-dropdown" $ text "Sign In"
        return (domEvent Click signInEl, never)


changePasswordWorkflow
  :: AppModalWidget t m
  => AppCredential BTG -> Workflow t m (Event t ())
changePasswordWorkflow authToken = Workflow $ mdo
  modalBoxFormW "Change Password" $ mdo
    SemUi.divider def
    SemUi.message def $ text "Any other sessions for your account will be signed out after changing your password."
    currentPw <- (fmap textToSecureMem . fst) <$> passwordInputFieldW' "Current Password" [] False (leftmost [ updatePasswordE, enterE ]) blank
    newPw <- updatePasswordW False $ leftmost [ updatePasswordE, enterE ]
    _ <- widgetHold blank $ ffor invalidPasswordFailureE $ \e -> SemUi.message def { SemUi._messageConfig_color = pure (Just SemUi.Red) } $ text $ T.pack $ show e
    loadingD <- holdDyn False $ leftmost [ True <$ succE, False <$ failE ]
    SemUi.divider def
    updatePasswordE <- divClass "controls" $ greenButtonW "Update Password" loadingD
    enterE <- getGlobalKeydownEventFor Enter

    let pwdsEv = align currentPw newPw
        changePasswordReq = fmapMaybe (\case
          These oldPwd newPwd -> Just $ ApiRequest_Private authToken $ PrivateRequest_ChangePassword oldPwd newPwd Nothing
          _ -> Nothing) pwdsEv
    changePasswordResp <- requestingIdentity changePasswordReq

    let (failE, succE) = fanEither changePasswordResp
    let invalidPasswordFailureE = ffilter (/= BTGError_RequiresTwoFactorAuth) failE
    let requiresTwoFactorAuthFailureE = ffilter (== BTGError_RequiresTwoFactorAuth) failE

    currentPasswordD <- holdDyn mempty currentPw
    newPasswordD <- holdDyn mempty newPw
    let passwordsD = zipDyn currentPasswordD newPasswordD

    return (never, leftmost
      [ changePasswordConfirmationWorkflow <$ succE
      , uncurry twoFactorAuthenticationWorkflow <$> tag (current passwordsD) requiresTwoFactorAuthFailureE
      ])
    where
      changePasswordConfirmationWorkflow = Workflow $ do
        modalBoxFormW "Change Password" $ do
          SemUi.divider def
          SemUi.header (def 
            & SemUi.headerConfig_size SemUi.|?~ SemUi.H3 
            & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text "Your password has been updated"
          SemUi.divider def
          doneE <- divClass "controls" $ greenButtonW "Done" $ constDyn False
          enterE <- getGlobalKeydownEventFor Enter
          return (leftmost [ doneE, enterE ], never)
      twoFactorAuthenticationWorkflow oldPw newPw = Workflow $
        modalBoxFormW "Change Password" $ mdo
          SemUi.divider def
          SemUi.message def $ text "To change your password enter the 6 digit 2 factor authentication code from your authorization app."
          oneTimePasswordInputE <- textInputFieldW "6-digit 2FA code" Nothing Nothing [] $ leftmost [ enterE, verifyE ]
          let checkOneTimePasswordRequestE = ApiRequest_Private authToken . PrivateRequest_ChangePassword oldPw newPw . Just <$> fmapMaybe validateOneTimePasswordInput oneTimePasswordInputE
          checkOneTimePasswordResponseE <- requestingIdentity checkOneTimePasswordRequestE
          let (otpCheckFailureE, otpCheckSuccessE) = fanEither checkOneTimePasswordResponseE
          widgetHold_ blank $ otpCheckFailureE $> errorMessageW "6-digit 2FA code is incorrect."
          loadingD <- holdDyn False $ leftmost
            [ True <$ checkOneTimePasswordRequestE
            , False <$ checkOneTimePasswordResponseE
            ]
          enterE <- getGlobalKeydownEventFor Enter
          SemUi.divider def
          (goBackE, verifyE) <- divClass "controls" $ do
            goBackE' <- modalCancelButtonW "Go Back"
            verifyE' <- greenButtonW "Verify" loadingD
            return (goBackE', verifyE')
          return (never, leftmost
            [ changePasswordWorkflow authToken <$ goBackE
            , changePasswordConfirmationWorkflow <$ otpCheckSuccessE
            ])


signOutW
  :: BaseAppWidget t m
  => AppCredential BTG -> Event t a -> m (Event t ())
signOutW authToken signOutE = do
  -- delete login sessions
  let logoutRequest = ApiRequest_Private authToken PrivateRequest_Logout <$ signOutE
  _ <- requestingIdentity logoutRequest

  -- clear auth cookie
  doc <- askDocument
  performEvent $ ffor signOutE $ \_ -> do
    defCookie <- defaultCookie authCookieKey Nothing
    setPermanentCookie doc $ defCookie { setCookiePath = Just "/" }
    return ()

routeSelector
  :: (DomBuilder t m, SemUi.HasElConfig t e, RouteConstraints t FrontendRoute m)
  => R FrontendRoute -> (e -> ch -> m (a,b)) -> e -> ch -> m b
routeSelector dest con cfg child = snd <$> do
  r <- askRoute
  let activated = ffor r $ bool "" "active" . (== dest)
  routeLink dest $ con (cfg & SemUi.classes <>~ SemUi.Dyn activated) child

signInWithCookieW
  :: BaseAppWidget t m
  => m (Event t (Maybe LoginResponse))
signInWithCookieW = do
  maybeAuthToken <- do
    doc <- askDocument
    cookie <- getCookieJson doc authCookieKey
    pure $ join $ rightToMaybe <$> cookie
  case maybeAuthToken of
    Just authToken -> do
      pb <- getPostBuild
      pbDelayed <- delay 0.01 pb
      let validationRequestE = ApiRequest_Private authToken PrivateRequest_Validate <$ pbDelayed
      validationResponseE <- requestingIdentity validationRequestE
      pure $ fforMaybe validationResponseE $ \case
        Left _ -> Just Nothing
        Right result -> Just $ Just result
    Nothing -> do
      pb <- getPostBuild
      pbDelayed <- delay 0.01 pb
      pure $ Nothing <$ pbDelayed


signInWorkflow
  :: forall t m. AppWidget t m
  => Workflow t m (Event t LoginResponse)
signInWorkflow = Workflow $
  formContainerW "Sign In" $ mdo
    emailInput <- textInputFieldW "Email" Nothing Nothing [] signInAttemptE
    (passwordInput, forgotPasswordE) <- passwordInputFieldW signInAttemptE $ do
      (forgotPasswordEl,_) <- el' "a" $ text "Forgot Password?"
      pure $ domEvent Click forgotPasswordEl

    signInAttemptE <- elClass "div" "submit" $ mdo
      widgetHold_ blank $ (errorMessageW "Email address or password is incorrect.") <$ invalidCredentialsFailureE
      loadingD <- holdDyn False $ leftmost [ True <$ signInRequestE, False <$ loginResponseE ]
      submitButtonW True "Sign In" loadingD

    let signInRequestE = flip fmapMaybe signInE $ \case
          These e p -> Just $ ApiRequest_Public $ PublicRequest_Login e p Nothing
          _ -> Nothing
    loginResponseE <- requestingIdentity signInRequestE
    let (failureE, successE) = fanEither loginResponseE
    let invalidCredentialsFailureE = ffilter (/= BTGError_RequiresTwoFactorAuth) failureE
    let requiresTwoFactorAuthFailureE = ffilter (== BTGError_RequiresTwoFactorAuth) failureE

    addCookieE <- signInCompleteW successE

    emailD <- holdDyn "" emailInput
    passwordD <- holdDyn mempty passwordInput
    let signInE = align emailInput passwordInput

    pure (addCookieE, leftmost
      [ resetPasswordRequestWorkflow <$ forgotPasswordE
      , uncurry twoFactorAuthenticationLoginWorkflow <$> tag (current $ zipDyn emailD passwordD) requiresTwoFactorAuthFailureE
      ])
  where
    twoFactorAuthenticationLoginWorkflow email pw = Workflow $
      formContainerW "2-Factor Authentication" $ mdo
        SemUi.message def $ text "To sign in enter the 6 digit 2 factor authentication code from your authorization app."
        oneTimePasswordInputE <- textInputFieldW "6-digit 2FA code" Nothing Nothing [] $ leftmost [ enterE, verifyE ]
        let checkOneTimePasswordRequestE = ApiRequest_Public . PublicRequest_Login email pw . Just <$> fmapMaybe validateOneTimePasswordInput oneTimePasswordInputE
        checkOneTimePasswordResponseE <- requestingIdentity checkOneTimePasswordRequestE
        let (otpCheckFailureE, otpCheckSuccessE) = fanEither checkOneTimePasswordResponseE
        widgetHold_ blank $ otpCheckFailureE $> errorMessageW "6-digit 2FA code is incorrect."
        loadingD <- holdDyn False $ leftmost
          [ True <$ checkOneTimePasswordRequestE
          , False <$ checkOneTimePasswordResponseE
          ]
        enterE <- getGlobalKeydownEventFor Enter
        verifyE <- elClass "div" "submit" $ submitButtonW True "Verify" loadingD
        addCookieE <- signInCompleteW otpCheckSuccessE
        return (addCookieE, never)

resetPasswordRequestWorkflow
  :: AppWidget t m
  => Workflow t m (Event t LoginResponse)
resetPasswordRequestWorkflow = Workflow $ do
  formContainerW "Recover Password" $ mdo
    -- Can't find the SemUi element for this.
    elAttr "div" ("style" =: "text-align: center") $
      text "Enter the email address associated with your account and we'll send you a password reset email."
    emailE <- (fmap T.toLower) <$> textInputFieldW "Email Address" Nothing Nothing [] submitE
    emailD <- holdDyn "" emailE
    submitE <- elClass "div" "submit" $
      submitButtonW True "Send Email" workingDyn
    workingDyn <- holdDyn False (True <$ emailE)
    let sendPasswordResetRequestE = ApiRequest_Public . PublicRequest_PasswordResetRequest <$> emailE
    res <- requestingIdentity sendPasswordResetRequestE
    let nextPage = resetPasswordWorkflowCheckEmail emailD <$ ffilter isRight res
    pure (never, nextPage)

resetPasswordWorkflowCheckEmail
  :: AppWidget t m
  => Dynamic t Text -> Workflow t m (Event t LoginResponse)
resetPasswordWorkflowCheckEmail email = Workflow $ do
  formContainerW "Check your email." $ do
    elAttr "div" ("style" =: "text-align: center") $
      text "If the email address you entered belongs to a user account, you'll have a password reset email in your inbox."
    SemUi.header (def & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ dynText email
    pure (never, never)

signInCompleteW
  :: AppWidget t m
  => Event t LoginResponse
  -> m (Event t LoginResponse)
signInCompleteW loginResponseE = do
  doc <- askDocument
  performEvent_ $ ffor loginResponseE $ \loginResponse -> do
    cookie <- defaultCookieJson authCookieKey $ Just $ _loginResponse_authToken loginResponse
    setPermanentCookie doc $ cookie { setCookiePath = Just "/" }

  pure loginResponseE

createAccountWorkflow
  :: AppWidget t m
  => Maybe LoginResponse -> Dynamic t (AccountRoute Identity) -> Workflow t m (Event t (Maybe (LoginResponse)))
createAccountWorkflow loginState tokenD = Workflow $ do
  case loginState of
    Just loginResponse -> errorContainerW "Create Account" $ do
      SemUi.header (def
        & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned
        & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $ text "You are signed in."
      SemUi.paragraph $ text "You must sign out to create a new account."
      (signOutEl, _) <- elClass' "button" "ui button light-grey" $ text "Sign Out"
      removeCookieE <- signOutW (_loginResponse_authToken loginResponse) $ domEvent Click signOutEl
      pure (Nothing <$ removeCookieE, never)

    Nothing -> formContainerW "Create Account" $ mdo
      widgetHold_ blank $ (errorMessageW . T.pack . show) <$> failureE
      nameInput <- textInputFieldW "Full Name" Nothing Nothing [] createAccountAttemptE
      passwordInput <- updatePasswordW True createAccountAttemptE
      createAccountAttemptE <- elClass "div" "submit" $ do
        loadingD <- holdDyn False $ leftmost [ True <$ createAccountRequestE, False <$ createAccountResponseE ]
        submitButtonW True "Create Account" loadingD

      let createAccountRequestE = fmapMaybe (\case
            (token, These name p) -> Just $ ApiRequest_Public $ PublicRequest_CreateAccount token name p
            _ -> Nothing) $ attach (current $ unAccountRoute <$> tokenD) (align nameInput passwordInput)
      createAccountResponseE <- requestingIdentity createAccountRequestE
      let (failureE, successE) = fanEither createAccountResponseE

      nameB <- hold "" nameInput
      pure (never, (\(name, loginResponse) -> accountCreatedWorkflow name loginResponse) <$> attach nameB successE)

accountCreatedWorkflow :: AppWidget t m => Text -> LoginResponse -> Workflow t m (Event t (Maybe (LoginResponse)))
accountCreatedWorkflow name loginResponse = Workflow $
  formContainerW "Account Created!" $ do
    elClass "div" "welcome-message" $
      SemUi.header (def
       & SemUi.headerConfig_aligned SemUi.|~ Just SemUi.CenterAligned) $ text $ "Welcome, " <> name <> "."
    getStartedE <- elClass "div" "submit" $ do
      submitButtonW True "Get Started" (constDyn False)
    pure (Just loginResponse <$ getStartedE, never)

resetPasswordWorkflow
  :: AppWidget t m
  => Dynamic t (AccountRoute Identity)
  -> Workflow t m (Event t LoginResponse)
resetPasswordWorkflow tokenD = Workflow $ do
  formContainerW "Set a New Password" $ mdo
    SemUi.message def $ text "Any other sessions for your account will be signed out after changing your password."
    widgetHold_ blank $ errorMessageW . T.pack . show <$> invalidPasswordFailureE
    passwordE <- updatePasswordW False submitE
    submitE <- elClass "div" "submit" $
      submitButtonW True "Update Password and Sign In" loadingD
    loadingD <- holdDyn False $ leftmost [True <$ passwordE, False <$ resetResultE]

    passwordD <- holdDyn mempty passwordE
    let sendPasswordResetE = ApiRequest_Public . (\(passwordResetToken, newPassword) -> PublicRequest_PasswordReset passwordResetToken newPassword Nothing) <$>
          attach (current $ unAccountRoute <$> tokenD) passwordE
    resetResultE <- requestingIdentity sendPasswordResetE

    let (failureE, successE) = fanEither resetResultE
    let invalidPasswordFailureE = ffilter (/= BTGError_RequiresTwoFactorAuth) failureE
    let requiresTwoFactorAuthFailureE = ffilter (== BTGError_RequiresTwoFactorAuth) failureE

    loginEvt <- signInCompleteW successE
    return (never, leftmost
      [ resetPasswordWorkflowDone <$> loginEvt
      , (\(passwordResetToken, newPassword) -> twoFactorAuthenticationWorkflow passwordResetToken newPassword) <$> tag (current $ zipDyn (unAccountRoute <$> tokenD) passwordD) requiresTwoFactorAuthFailureE
      ])
    where
      twoFactorAuthenticationWorkflow passwordResetToken newPassword = Workflow $
        formContainerW "Two-Factor Authentication" $ mdo
          SemUi.message def $ text "To set your new password enter the 6 digit 2 factor authentication code from your authorization app."
          oneTimePasswordInputE <- textInputFieldW "6-digit 2FA code" Nothing Nothing [] verifyE
          let checkOneTimePasswordRequestE = ApiRequest_Public . PublicRequest_PasswordReset passwordResetToken newPassword . Just <$> fmapMaybe validateOneTimePasswordInput oneTimePasswordInputE
          checkOneTimePasswordResponseE <- requestingIdentity checkOneTimePasswordRequestE
          let (otpCheckFailureE, otpCheckSuccessE) = fanEither checkOneTimePasswordResponseE
          widgetHold_ blank $ errorMessageW . T.pack . show <$> otpCheckFailureE
          loadingD <- holdDyn False $ leftmost
            [ True <$ checkOneTimePasswordRequestE
            , False <$ checkOneTimePasswordResponseE
            ]
          (goBackE, verifyE) <- divClass "two-factor-auth-controls" $ do
            goBackE' <- buttonW "Go Back" SemUi.Grey (constDyn False)
            verifyE' <- submitButtonW True "Verify" loadingD
            return (goBackE', verifyE')
          return (never, leftmost
            [ resetPasswordWorkflow tokenD <$ goBackE
            , resetPasswordWorkflowDone <$> otpCheckSuccessE
            ])

resetPasswordWorkflowDone
  :: AppWidget t m
  => LoginResponse
  -> Workflow t m (Event t LoginResponse)
resetPasswordWorkflowDone loginResponse = Workflow $ do
  formContainerW "Your password has been reset." $ do
    continue <- elClass "div" "submit" $
      submitButtonW True "Continue" $ constDyn False
    return (loginResponse <$ continue, never)

debugW
  :: forall t m. AppWidget t m
  => m ()
debugW = do
  maybeSignedInUser <- asks $ _frontendConfig_signedInUser
  case maybeSignedInUser of
    Just (SignedInUser authToken _) ->
      elClass "div" "debug" $ do
      elClass "div" "debug-warning" $ do
        SemUi.message (def
          & SemUi.messageConfig_type SemUi.|?~ SemUi.WarningMessage) $ do
          el "strong" $ text "Warning: "
          text "This page is only for internal use, and should not be accessible from within the app or shown to end-users."
      elClass "div" "ui debug-actions" $ do
        actionResult <- elClass "div" "ui debug-list" $ do
          deleteTokenE <- submitButtonW False "Delete Token" $ constDyn False
          let deleteTokenRequest = ApiRequest_Private authToken PrivateRequest_DeleteTokenInfo <$ deleteTokenE
          deleteTokenResponse <- requestingIdentity deleteTokenRequest
          pure $ ("Token deleted.",) <$> deleteTokenResponse
        elClass "div" "ui debug-result" $ mdo
          widgetHold_ blank $ uncurry responseMessageW <$> actionResult
          pure ()
    Nothing ->
      blank
