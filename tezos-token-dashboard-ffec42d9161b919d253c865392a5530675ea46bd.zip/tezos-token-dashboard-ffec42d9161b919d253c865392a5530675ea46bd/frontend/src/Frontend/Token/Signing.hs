{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecursiveDo #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TupleSections #-}

module Frontend.Token.Signing where

import Control.Lens hiding ((:<))
import Control.Monad.Reader
import Data.Bool
import qualified Data.ByteString as BS
import Data.ByteString.Base58
import Data.Foldable (for_)
import Data.List.NonEmpty (NonEmpty (..))
import qualified Data.List.NonEmpty as NonEmpty
import Data.List.Split (chunksOf)
import Data.Maybe 
import Data.Functor (($>))
import qualified Data.Map.Monoidal as MMap
import Data.Semigroup
import qualified Data.Set as Set
import qualified Data.Text as T
import qualified Data.Text.Encoding as T
import Data.Traversable (for)
import Database.Id.Class
import Frontend.Widgets
import Obelisk.Route.Frontend
import Reflex.Dom
import qualified Reflex.Dom.SemanticUI as SemUi
import Rhyolite.Api

import Common.App
import Common.Route
import Common.Schema
import Frontend.App
import Frontend.Ledger
import Frontend.OperationText
import Frontend.Watch
import Tezos.BabylonShim (getEndpoint)
import Tezos.Wrapped.Schema
import Tezos.Token.Schema
import Tezos.Types
import Tezos.V005.Michelson (toMicheline, wrapEndpointCall)

signingWorkflow 
  :: (AppModalWidget t m, SetRoute t (R FrontendRoute) m)
  => Maybe SigningInfo -> (SigningInfo -> Workflow t m (Event t ())) -> Workflow t m (Event t ())
signingWorkflow maybeSigningInfo nextWorkflow = 
  case maybeSigningInfo of
    Just signingInfo -> 
      nextWorkflow signingInfo
    Nothing ->
      setPKHWorkflow

createOperationWorkflow
  :: AppModalWidget t m
  => TokenInfo -> SigningInfo -> OperationText -> (Event t () -> m (Event t TokenOperation)) -> Workflow t m (Event t ())
createOperationWorkflow tokenInfo signingInfo opText opInputWidget = Workflow $
  modalBoxFormW (_operationText_short opText) $ mdo
    SemUi.divider def
    operationInput <- divClass "create-operation-body" $ do
      SemUi.header (def
        & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
        & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text (_operationText_definition opText)
      maybe blank (elClass "div" "create-operation-text" . el "p" . text) (_operationText_details opText)
      opInputWidget submitEv
    SemUi.divider def
    (cancelEv, submitEv) <- divClass "controls" $ do
      cancelEv' <- modalCancelButtonW "Cancel"
      continue' <- greenButtonW "Continue" $ constDyn False
      enterE <- getGlobalKeydownEventFor Enter
      let submitEv' = leftmost [continue', enterE]
      return (cancelEv', submitEv')
    let multisigCallE = buildMultisigCall tokenInfo <$> operationInput
    return (cancelEv, (\multisigCall ->
      (connectLedgerWorkflow (_operationText_short opText) Nothing
        (\_ -> signOperationWorkflow signingInfo multisigCall Nothing opText))) <$> multisigCallE)

signOperationWorkflow
  :: AppModalWidget t m
  => SigningInfo -> Maybe WrappedCall -> Maybe (Id PendingOperation) -> OperationText -> Workflow t m (Event t ())
signOperationWorkflow signingInfo maybeMultisigCall maybeOpId opText =
  case maybeOpId of
    Nothing -> reviewOperationW False
    Just _ -> case maybeMultisigCall of
      Nothing -> Workflow $ modalBoxFormW (_operationText_short opText) $ mdo
        SemUi.divider def
        divClass "create-operation-body" $ do
          SemUi.header (def
            & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
            & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text (_operationText_definition opText)
          elClass "div" "create-operation-text" $ el "p" $ text "The configured token contract does not appear to support this operation.  Please consult a system administrator for assistance."
        SemUi.divider def
        cancelE <- divClass "controls" $ modalCancelButtonW "Cancel"
        return (cancelE, never)
      Just multisigCall -> case _wrappedCall_payload multisigCall of
        WrappedPayload_Call _ tokenOperation _ ->
          case tokenOperation of
            Mint amount address -> Workflow $
              modalBoxFormW (_operationText_short opText) $ mdo
                SemUi.divider def
                divClass "create-operation-body" $ do
                  SemUi.header (def
                    & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
                    & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text (_operationText_definition opText)
                  elClass "div" "create-operation-text" $ el "p" $ text "The first signer has set the following values for this operation:"
                elClass "div" "ui mint-input" $ do
                  elClass "div" "operation-amount-field" $
                    disabledTextInputFieldW "Amount to Mint" (T.pack $ show amount)
                  elClass "div" "mint-destination-field" $
                    disabledTextInputFieldW "Destination Address" (toContractIdText address)
                SemUi.divider def
                (cancelE, continueE) <- divClass "controls" $ do
                  cancelE' <- modalCancelButtonW "Cancel"
                  continueE' <- greenButtonW "Continue" $ constDyn False
                  return (cancelE', continueE')
                return (cancelE, reviewOperationW <$> (False <$ continueE))
            Burn amount address -> Workflow $
              modalBoxFormW (_operationText_short opText) $ mdo
                SemUi.divider def
                divClass "create-operation-body" $ do
                  SemUi.header (def
                    & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
                    & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text (_operationText_definition opText)
                  elClass "div" "create-operation-text" $ el "p" $ text "The first signer has set the following values for this operation:"
                elClass "div" "ui mint-input" $ do
                  elClass "div" "operation-amount-field" $
                    disabledTextInputFieldW "Amount to Burn" (T.pack $ show amount)
                  elClass "div" "mint-destination-field" $
                    disabledTextInputFieldW "From Address" (toContractIdText address)
                SemUi.message def $ do
                  SemUi.paragraph $ text "If you’d like to modify the operation’s values you must create a new operation."
                SemUi.divider def
                (cancelE, continueE) <- divClass "controls" $ do
                  cancelE' <- modalCancelButtonW "Cancel"
                  continueE' <- greenButtonW "Continue" $ constDyn False
                  return (cancelE', continueE')
                return (cancelE, reviewOperationW <$> (False <$ continueE))
            AddToWhitelist address ->
              whitelistInputReview [address]
            AddToWhitelistBatch addresses ->
              whitelistInputReview addresses
            RemoveFromWhitelist address ->
              whitelistInputReview [address]
            _ ->
              reviewOperationW False
        WrappedPayload_Reconfig _ addresses ->
          updateSignersListInputReview addresses
          
  where
    whitelistInputReview addresses = Workflow $
      modalBoxFormW (_operationText_short opText) $ mdo
        SemUi.divider def
        divClass "create-operation-body" $ do
          SemUi.header (def
            & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
            & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text (_operationText_definition opText)
          elClass "div" "create-operation-text" $ el "p" $ text "The first signer has set the following values for this operation:"
        elClass "div" "ui addresses-input" $ mdo
          elClass "div" "input-field" $ elClass "div" "field-name" $ elClass "span" "name" $ text "Addresses"
          showAllD <- holdDyn False $ True <$ showAllE
          showAllE <- switchHold never <=< dyn $ ffor showAllD $ \case
            False -> el "ul" $ do
              _ <- for (take 4 addresses) $ \address ->
                el "li" $ text $ toContractIdText address
              if length addresses > 4
                then do
                  (showMoreEl, _) <- el' "a" $ text $ "Show " <> (T.pack $ show $ length addresses - 4) <> " more addresses..."
                  return $ domEvent Click showMoreEl
                else
                  return never
            True -> el "ul" $ do
              _ <- for addresses $ \address ->
                el "li" $ text $ toContractIdText address
              return never
          return ()

        SemUi.message def $ do
          SemUi.paragraph $ text "If you’d like to modify the operation’s values you must create a new operation."
        SemUi.divider def
        (cancelE, continueE) <- divClass "controls" $ do
          cancelE' <- modalCancelButtonW "Cancel"
          continueE' <- greenButtonW "Continue" $ constDyn False
          return (cancelE', continueE')
        return (cancelE, reviewOperationW <$> (False <$ continueE))

    updateSignersListInputReview publicKeys = Workflow $
      modalBoxFormW (_operationText_short opText) $ mdo
        SemUi.divider def
        divClass "create-operation-body" $ do
          SemUi.header (def
            & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
            & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text (_operationText_definition opText)
          elClass "div" "create-operation-text" $ el "p" $ text "The operation originator has set the following values for this operation:"
        elClass "div" "ui addresses-input" $ mdo
          elClass "div" "input-field" $ elClass "div" "field-name" $ elClass "span" "name" $ text "Addresses"
          divClass "listed-addresses" $ do
            dynAuthorizedKeys <- watchAuthorizedKeys $ constDyn AuthorizedKeysQuery_ActiveKeys
            widgetHold_ blank $ ffor (updated dynAuthorizedKeys) $ \(First maybeAuthorizedKeys) -> do
              let authorizedKeys = maybe [] _authorizedKeys_publicKeys maybeAuthorizedKeys
                  (removed, existing, added) = threeWayPartition (Set.fromList $ snd <$> authorizedKeys) (Set.fromList $ snd <$> publicKeys)
              for_ added $ \addedPublicKey -> divClass "listed-address" $ do
                el "div" $ text $ toPublicKeyHashText addedPublicKey
                el "div" $ text "Add address"
              for_ removed $ \removedPublicKey -> divClass "listed-address" $ do
                el "div" $ el "s" $ text $ toPublicKeyHashText removedPublicKey
                el "div" $ text "Remove address"
              for_ existing $ \existingPublicKey -> divClass "listed-address" $ do
                el "div" $ text $ toPublicKeyHashText existingPublicKey
                el "div" $ text "Existing address"

        SemUi.message def $ do
          SemUi.paragraph $ text "If you’d like to modify the operation’s values you must create a new operation."
        SemUi.divider def
        (cancelE, continueE) <- divClass "controls" $ do
          cancelE' <- modalCancelButtonW "Cancel"
          continueE' <- greenButtonW "Continue" $ constDyn False
          return (cancelE', continueE')
        return (cancelE, reviewOperationW False <$ continueE)
        where
          threeWayPartition setA setB =
            (Set.difference setA setB, Set.intersection setA setB, Set.difference setB setA)

    reviewOperationW showError = Workflow $ case maybeMultisigCall of
      Just multisigCall -> modalBoxFormW (_operationText_short opText) $ mdo
        SemUi.divider def
        divClass "sign-content" $ do
          ledgerStatusW (Just $ _signingInfo_publicKeyHash signingInfo) True
          bool blank (errorMessageW "The Ledger device prompt was rejected or timed out. Please try again.") showError
          divClass "op-description-container" $ divClass "op-description" $ do
            el "h4" $ text "Operation Description:"
            renderDescription $ _wrappedCall_payload multisigCall
        signatureCountD <- signeeNumberW maybeOpId
        SemUi.divider def
        (cancelE, signOnLedger) <- signLedgerFooterW
        pure (cancelE, (\sigCount ->
          reserveOperationWorkflow opText maybeOpId multisigCall (\opId finalMultisigCall -> 
            signOnLedgerWorkflow opId finalMultisigCall sigCount)) <$> tag (current signatureCountD) signOnLedger)
      Nothing -> modalBoxFormW (_operationText_short opText) $ do
        SemUi.divider def
        divClass "sign-content" $ do
          errorMessageW "This operation appears to be unsupported by the configured token.  Please contact a system administrator for assistance."
        SemUi.divider def
        cancelE <- modalCancelButtonW "Cancel"
        return (cancelE, never)

    signOnLedgerWorkflow opId finalMultisigCall sigCount = Workflow $
      modalBoxFormW (_operationText_short opText) $ mdo
        SemUi.divider def
        divClass "sign-content" $
          ledgerStatusW (Just $ _signingInfo_publicKeyHash signingInfo) True
        divClass "op-description-container" $ divClass "op-description" $ do
          el "h4" $ text "Operation Description:"
          renderDescription $ _wrappedCall_payload finalMultisigCall
        maybeSignatureE <- signOnLedgerW signingInfo finalMultisigCall
        SemUi.divider def
        divClass "footer-filler" blank
        pure (never, (\case 
          Just opSignature -> 
            signatureResultWorkflow signingInfo opText sigCount [(opId, opSignature)] (signOnLedgerWorkflow opId finalMultisigCall)
          Nothing -> 
            clearAndReviewOperationW opId) <$> maybeSignatureE)

    clearAndReviewOperationW opId =
      case maybeOpId of
        Just _ -> reviewOperationW True
        Nothing -> Workflow $
          modalBoxFormW (_operationText_short opText) $ mdo
            SemUi.divider def
            divClass "modal-loading" loadingW
            pb <- getPostBuild
            token <- getAuthToken
            opE <- requestingIdentity $ ApiRequest_Private token (PrivateRequest_CancelOperation opId) <$ pb
            return (never, reviewOperationW True <$ opE)

type UnreservedChunkedOperation = NonEmpty WrappedCall
type ReservedChunkedOperation = NonEmpty (Id PendingOperation, WrappedCall)

createChunkedOperationWorkflow
  :: AppModalWidget t m
  => SigningInfo -> OperationText -> m (Event t UnreservedChunkedOperation) -> Workflow t m (Event t ())
createChunkedOperationWorkflow signingInfo opText opInputWidget = Workflow $
  modalBoxFormW (_operationText_short opText) $ mdo
    SemUi.divider def
    operationInputD <- holdDyn Nothing $ Just <$> operationInputE
    operationInputE <- divClass "create-operation-body" $ do
      SemUi.header (def
        & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
        & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text (_operationText_definition opText)
      maybe blank (elClass "div" "create-operation-text" . el "p" . text) (_operationText_details opText)
      opInputWidget
    SemUi.divider def
    (cancelEv, submitEv) <- divClass "controls" $ do
      cancelEv' <- modalCancelButtonW "Cancel"
      loadingD <- holdDyn True $ False <$ operationInputE
      continue' <- greenButtonW "Continue" loadingD
      enterE <- getGlobalKeydownEventFor Enter
      submitEv' <- headE $ leftmost [continue', enterE]
      return (cancelEv', submitEv')
    chunkedOperationD <- widgetHold (return never) $ ffor (tag (current operationInputD) submitEv) $ \case
      Just unreservedChunkedOperation -> 
        reserveChunkedOperationW unreservedChunkedOperation
      Nothing -> 
        return never
    return (cancelEv, (\chunkedOperation ->
      (connectLedgerWorkflow (_operationText_short opText) Nothing
        (\_ -> signChunkedOperationWorkflow signingInfo chunkedOperation opText))) <$> switchDyn chunkedOperationD)

signChunkedOperationWorkflow
  :: AppModalWidget t m
  => SigningInfo -> ReservedChunkedOperation -> OperationText -> Workflow t m (Event t ())
signChunkedOperationWorkflow signingInfo chunkedOperation opText = Workflow $ do
  modalBoxFormW (_operationText_short opText) $ mdo
    SemUi.divider def
    ledgerStatusW (Just $ _signingInfo_publicKeyHash signingInfo) True
    SemUi.header (def  
      & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned
      & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $ text "Sign the following operations:"

    let chunkSize = maybe 0 getOperationLimit $ viewTokenOperation (_wrappedCall_payload (snd (NonEmpty.head chunkedOperation)))
    SemUi.message (def & (SemUi.messageConfig_elConfig . SemUi.classes) SemUi.|~ SemUi.Classes ["flex"]) $ do 
      SemUi.icon "info circle" def
      text $ T.pack $ "Disbursement operations have a maximum of " <> show chunkSize <> " recipients per operation. Multiple Disburse operations have been included so all token holders are accounted for. Exiting before all operations are signed will cancel the entire process."  

    signaturesD <- foldDyn (<>) [] newSignatureE
    (_, newSignatureE) <- runEventWriterT $ mdo 
      currentOperationIndexD <- holdDyn Nothing $ Just <$> leftmost [ 0 <$ signOnLedgerE, nextOperationE ]
      nextOperationE <- divClass "ui styled accordion" $ mdo 
        nextOperationEs <- for (zip [0 ..] (NonEmpty.toList chunkedOperation)) $ \(i, (opId, multisigCall)) -> mdo 
          let isSignedD = fmap (Just i <) currentOperationIndexD
          let isActiveD = fmap (Just i ==) currentOperationIndexD
          let startNumber = i * chunkSize + 1
          let endNumber = startNumber + extractOperationUnitCount multisigCall - 1
          hasErrorD <- holdDyn False $ leftmost [ False <$ retryE, isNothing <$> maybeSignatureE ]
          resultE <- elDynAttr "div" ((\isActive -> "class" =: ("title" <> if isActive then " active" else "")) <$> isActiveD) $ do
            elDynAttr "i" ((\isSigned -> "class" =: "fas fa-comment-dollar" <> "style" =: ("margin-right:10px;" <> if isSigned then "color:#21ba45" else "")) <$> isSignedD) blank
            el "strong" $ text $ T.pack $ "Disburse Dividends: Holders " <> show startNumber <> " - " <> show endNumber 
            dynWithEvent $ ffor hasErrorD $ \case 
              True -> divClass "content active inline-error" $ do 
                el "br" blank
                errorMessageW "The Ledger device prompt was rejected or timed out. Please try again."
                el "br" blank
                innerRetryE <- greenButtonW "Sign on Ledger device" (constDyn False)
                return $ Left <$> innerRetryE
              False -> do
                innerMaybeSignatureE <- dynWithEvent $ ffor isActiveD $ \case 
                  True -> 
                    divClass "content active" $ do
                      signOnLedgerW signingInfo multisigCall
                  False ->
                    return never
                return $ Right <$> innerMaybeSignatureE
          let (retryE, maybeSignatureE) = fanEither resultE
          let signatureE = fmapMaybe id maybeSignatureE
          tellEvent $ fmap (\sig -> [(opId, sig)]) signatureE
          return $ i + 1 <$ signatureE
        return $ leftmost nextOperationEs
      return ()
    signatureCountD <- signeeNumberW (Just . fst $ NonEmpty.head chunkedOperation)

    allOperationsSignedB <- hold False $ (== length chunkedOperation) . length <$> updated signaturesD
    delayedSignaturesE <- delay 0.01 (updated signaturesD)
    let finishedSigningE = reverse <$> gate allOperationsSignedB delayedSignaturesE

    SemUi.divider def
    (cancelE, signOnLedgerE) <- divClass "controls" $ do
      cancelInnerE <- modalCancelButtonW "Cancel"
      signOnLedgerDE <- widgetHold (greenButtonW "Sign on Ledger device" (constDyn False)) $ signOnLedgerE $> return never
      return (cancelInnerE, switchDyn signOnLedgerDE)

    return (cancelE, (\(sigCount, opSignatures) -> 
      signatureResultWorkflow signingInfo opText sigCount opSignatures $ (\_ -> 
        signChunkedOperationWorkflow signingInfo chunkedOperation opText)) <$> attach (current signatureCountD) finishedSigningE)

addOperationSignatures
  :: AppModalWidget t m
  => SigningInfo -> [(Id PendingOperation, Signature)] -> SignatureCount -> m (Event t (Either BTGError (NonEmpty (Maybe OperationHash))))
addOperationSignatures signingInfo signatures initialCountPosition = do
  pb <- getPostBuild
  token <- getAuthToken
  let opSignatures = (\(pendingOpId, opSignature) -> OperationSignature
        { _operationSignature_pendingOperation = pendingOpId
        , _operationSignature_signature = opSignature
        , _operationSignature_signingKey = _signingInfo_publicKey signingInfo
        }) <$> signatures
  case opSignatures of 
    x:xs -> 
      requestingIdentity $ ApiRequest_Private token (PrivateRequest_AddOperationSignatures (x :| xs) initialCountPosition) <$ pb
    [] -> 
      return never

signeeNumberW 
  :: AppModalWidget t m 
  => Maybe (Id PendingOperation) -> m (Dynamic t SignatureCount)
signeeNumberW mPendingId = divClass "signature-info" $ mdo
  updateSignatureCountE <- case mPendingId of
    Nothing -> do
      el "h3" $ text $ "Signature 1 of " <> T.pack (show numOfRequiredSignatures)
      elClass "p" "modal-message-text" $ do 
        text $ "This operation requires " <> T.pack (show numOfRequiredSignatures) <> " signatures."
        el "br" blank
        text $ "Yours will be the first signature."
      return never
    Just pendingId -> do
      dmOpSigs <- watchOperationSignature $ constDyn $ OperationSignatureQuery_ByPendingOperation pendingId
      dyn $ ffor dmOpSigs $ \opSigMap -> do
        let sigNumber = 1 + (MMap.size opSigMap)
        el "h3" $ text $ "Signature " <> T.pack (show sigNumber) <> " of " <> T.pack (show numOfRequiredSignatures)
        elClass "p" "modal-message-text" $ do 
          text $ "This operation requires " <> T.pack (show numOfRequiredSignatures) <> " signatures."
          el "br" blank
          text $ "Yours will be the " <> (if sigNumber == 1 then "first" else if sigNumber == 2 then "second" else "third") <> " signature."
        bool blank blockchainActionWarning $ sigNumber == numOfRequiredSignatures
        return $ SignatureCount sigNumber
  holdDyn (SignatureCount 1) updateSignatureCountE
  where
    blockchainActionWarning = divClass "blockchain-action-warning" $
        el "h4" $ text $ "This operation will be sent to the blockchain immediately after your signature is collected."

signLedgerFooterW :: AppModalWidget t m => m (Event t (), Event t ())
signLedgerFooterW = divClass "workflow-button-footer" $ do
  cancelE <- modalCancelButtonW "Cancel"
  signOnLedger <- greenButtonW "Sign on Ledger device" $ constDyn False
  return (cancelE, signOnLedger)

setPKHWorkflow :: (AppModalWidget t m, SetRoute t (R FrontendRoute) m) => Workflow t m (Event t ())
setPKHWorkflow = Workflow $ modalBoxFormW "Set PKH" $ do
  SemUi.divider def
  redirectE <- divClass "operation-state-error" $ do
    divClass "red-box" $ text "x"
    elClass "p" "operation-state-error-title" $ text "You must set your PKH before signing."
    -- TODO: User setRoute from Obelisk.Route.Frontend to redirect user to Users page
    divClass "operation-state-flex-inline" $ do
      elClass "p" "operation-state-error-desc" $ text "The key you will use for signing has not been set yet. Go to the"
      (e,_) <- elClass' "a" "operation-state-error-desc" $ text "Users page"
      let goToUserPage = domEvent Click e
      setRoute $ (FrontendRoute_UserManagement :/ ())  <$ goToUserPage
      elClass "p" "operation-state-error-desc" $ text "to set your PKH before signing."
      return goToUserPage
  SemUi.divider def
  doneE <- divClass "controls" $ do
    greenButtonW "Done" $ constDyn False
  return (leftmost [redirectE, doneE], never)

signOnLedgerW :: AppModalWidget t m => SigningInfo -> WrappedCall -> m (Event t (Maybe Signature))
signOnLedgerW signingInfo multisigCall = do 
  divClass "signature-info" $ do
    loadingW 
    el "h3" $ text "Respond to the prompt on your ledger device."
    el "p" $ text "Your Ledger device should show the following prompt:"
  divClass "sign-content" $ divClass "sign-ledger-hash" $ mdo
    el "p" $ text "Sign Hash?"
    postBuild <- getPostBuild
    let runBlake2bHashRequest = ApiRequest_Public (PublicRequest_RunBlake2bHash Blake2bHashSize_32 operationBytes) <$ postBuild
    runBlake2bHashResponse <- requestingIdentity runBlake2bHashRequest
    let (_, hashSuccessE) = fanEither runBlake2bHashResponse
    let operationHashE = T.decodeUtf8 . encodeBase58 bitcoinAlphabet <$> hashSuccessE
    el "p" $ widgetHold_ blank $ text <$> operationHashE
    callJavascriptAsync $ signHashedOperation (DerivationPath $ _signingInfo_derivationPath signingInfo) <$> hashSuccessE
  where 
    operationBytes = BS.cons 5 $ wrappedCallBytesToSign multisigCall 

reserveOperationWorkflow 
  :: AppModalWidget t m 
  => OperationText -> Maybe (Id PendingOperation) -> WrappedCall -> (Id PendingOperation -> WrappedCall -> Workflow t m (Event t ())) -> Workflow t m (Event t ())
reserveOperationWorkflow opText maybeOpId multisigCall nextWorkflow =
  case maybeOpId of
    Just opId -> nextWorkflow opId multisigCall
    Nothing -> Workflow $
      modalBoxFormW (_operationText_short opText) $ mdo
        SemUi.divider def
        divClass "modal-loading" loadingW
        pb <- getPostBuild
        token <- getAuthToken
        opE <- requestingIdentity $ ApiRequest_Private token (PrivateRequest_AddPendingOperations $ multisigCall :| []) <$ pb
        let (_failureOpIdE, successOpIdE) = fanEither opE
        return (never, uncurry nextWorkflow . NonEmpty.head <$> successOpIdE)

reserveChunkedOperationW
  :: AppModalWidget t m 
  => UnreservedChunkedOperation -> m (Event t ReservedChunkedOperation)
reserveChunkedOperationW chunkedOperation = mdo
  token <- getAuthToken
  pb <- getPostBuild
  opE <- requestingIdentity $ ApiRequest_Private token (PrivateRequest_AddPendingOperations chunkedOperation) <$ pb
  let (_failureOpIdE, successOpIdE) = fanEither opE
  return successOpIdE

signatureResultWorkflow 
  :: AppModalWidget t m 
  => SigningInfo -> OperationText -> SignatureCount -> [(Id PendingOperation, Signature)] -> (SignatureCount -> Workflow t m (Event t ())) -> Workflow t m (Event t ())
signatureResultWorkflow signingInfo opText sc@(SignatureCount sigCount) opSignatures retryWorkflow = Workflow $
  modalBoxFormW (_operationText_short opText) $ do
    addOpResult <- addOperationSignatures signingInfo opSignatures sc
    let (failedOpSig, successOpSigE) = fanEither addOpResult
    SemUi.divider def
    signaturePositionDE <- divClass "sign-content" $ do
      -- handle success
      widgetHold_ blank $ ffor (catMaybes . NonEmpty.toList <$> successOpSigE) $ \case
        [] -> do
          el "h3" $ text "Signing successful. Your signature has been saved."
          let remainingSigs = numOfRequiredSignatures - sigCount
          el "p" $ text $ "After "
            <> (T.pack $ show $ remainingSigs)
            <> " signature(s) is gathered the "
            <> (T.toLower $ _operationText_short opText)
            <> " operation will be sent to the blockchain."
        opHash:[] -> do
          el "h3" $ text "Signing successful. This operation has been sent to the blockchain."
          el "p" $ text $ toBase58Text opHash
        opHashes -> do
          el "h3" $ text "Signing successful. These operations have been sent to the blockchain."
          el "p" $ text $ T.intercalate ", " $ toBase58Text <$> opHashes
        
      -- handle errors
      widgetHold (return never) $ ffor failedOpSig $ \err -> case err of
        BTGError_OperationSignaturePositionChange newPos -> divClass "operation-state-error" $ do
          divClass "orange-box" $ text "!"
          elClass "p" "operation-state-error-title" $ text "Your signing position has been changed."
          divClass "modal-error-message" $ do
            elClass "p" "operation-state-error-desc" $ text "Other admins have signed this operation while you were signing. There are now enough signatures to send this operation to the blockchain."
            saveBtn <- modalSubmitButtonW "Save signature as third signer and send operation to the blockchain" $ constDyn False
            elClass "p" "" $ text "or"
            cancelBtn <- modalCancelButtonW "Cancel signing. Operation will not be sent until a third admin signs."
            return $ leftmost [Right <$> (newPos <$ saveBtn), Left <$> cancelBtn]
        BTGError_OperationDismissed errMsg -> divClass "operation-state-error" $ do
          divClass "red-box" $ text "x"
          elClass "p" "operation-state-error-title" $ text $ errMsg
          elClass "p" "operation-state-error-desc" $ text "This operation was cancelled by another admin while you were signing and has been deleted."
          return never
        BTGError_OperationSignatureSatisfied errMsg -> divClass "operation-state-error" $ do
          divClass "red-box" $ text "x"
          elClass "p" "operation-state-error-title" $ text $ errMsg
          elClass "p" "operation-state-error-desc" $ text "This operation was signed by a third admin and was sent to the blockchain before your signature was completed."
          return never
        BTGError_OperationSignatureInvalid -> divClass "operation-state-error" $ do
          divClass "red-box" $ text "x"
          elClass "p" "operation-state-error-title" $ text $ T.pack $ show err
          elClass "p" "operation-state-error-desc" $ text "The Ledger device used to sign did not have the PKH needed to sign the operation. Make sure to use the Ledger device with the PKH shown on the signing screens. You may go back to restart the signing process with a different Ledger device."
          return never
        _ -> do
          errorMessageW $ T.pack $ show err
          return never
    positionChangeE <- dynWithEvent $ ffor signaturePositionDE $ \positionEv -> return positionEv
    let (cancelBtn, signaturePositionE) = fanEither positionChangeE
    SemUi.divider def
    doneE <- divClass "controls" $ do
      greenButtonW "Done" $ constDyn False
    pure (leftmost [doneE, cancelBtn], retryWorkflow <$> fmap SignatureCount signaturePositionE)


buildMultisigCall :: TokenInfo -> TokenOperation -> Maybe WrappedCall
buildMultisigCall tokenInfo tokenOp =
  let multisig = tokenInfo ^. tokenInfo_multiSignatureContractAddress
      counter = 0
      token = tokenInfo ^. tokenInfo_contractAddress
      flatOp = do
        script <- tokenInfo ^. tokenInfo_contractScript
        wrapEndpointCall (getEndpoint tokenOp) script $ toMicheline tokenOp
  in WrappedCall multisig counter <$> WrappedPayload_Call token tokenOp <$> flatOp

buildMultisigReconfig :: TokenInfo -> Int -> [(PublicKey, PublicKeyHash)] -> WrappedCall
buildMultisigReconfig tokenInfo signingThreshold authorizedSigningKeys =
  let multisig = tokenInfo ^. tokenInfo_multiSignatureContractAddress
      counter = 0
  in WrappedCall multisig counter (WrappedPayload_Reconfig signingThreshold authorizedSigningKeys)

buildChunkedOperation :: TokenInfo -> ([a] -> TokenOperation) -> [a] -> Maybe UnreservedChunkedOperation
buildChunkedOperation tokenInfo tokenOpConstructor inputs =
    case catMaybes $ (\chunk -> buildMultisigCall tokenInfo (tokenOpConstructor chunk)) <$> chunksOf (getOperationLimit (tokenOpConstructor [])) inputs of
      [] -> Nothing
      x:xs -> Just (x :| xs)

extractOperationUnitCount :: WrappedCall -> Int
extractOperationUnitCount multisigCall =
  case _wrappedCall_payload multisigCall of
    WrappedPayload_Call _ (Disburse addresses) _ ->
      length addresses
    _ ->
      1