{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecursiveDo #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Frontend.Token.Whitelist where

import Control.Lens hiding ((:<))
import Control.Monad (when)
import Data.Either
import qualified Data.List as List
import qualified Data.Map as M
import qualified Data.Map.Merge.Lazy as M
import qualified Data.Text as T
import Data.Traversable (for)
import Frontend.Widgets
import Obelisk.Route.Frontend
import Reflex.Dom hiding (count)
import qualified Reflex.Dom.SemanticUI as SemUi
import Rhyolite.Api
import Rhyolite.App
import Rhyolite.Frontend.Modal.Class

import Common.App
import Common.Route
import Common.Schema
import Frontend.App
import Frontend.OperationText
import Frontend.Token.Signing
import Tezos.Wrapped.Schema
import Tezos.Token.Schema
import Tezos.V005.Contract

data WhitelistAction
  = LookUpAddress
  | BatchAdd
  | BatchRemove
  deriving (Eq, Ord)

instance Show WhitelistAction where
  show = \case
    LookUpAddress -> "Look Up Single Address"
    BatchAdd -> "Batch Add to Whitelist"
    BatchRemove -> "Batch Remove from Whitelist"

whitelistDropdown
  :: AppWidget t m => m (Dynamic t WhitelistAction)
whitelistDropdown = divClass "whitelist-dropdown" $ do
  let options = [ LookUpAddress, BatchAdd, BatchRemove ]
  let ddConfig = def
          { SemUi._dropdownConfig_selection = pure False
          , SemUi._dropdownConfig_fluid = pure True
          , SemUi._dropdownConfig_compact = pure True
          , SemUi._dropdownConfig_unselectable = True
          }
  divClass "whitelist-dropdown" $ do
    dd <- dropdownMenu ddConfig (head options) never $ SemUi.TaggedStatic options
    _ <- operationButton "smile" "Whitelist"
    return dd

whitelistWorkflows :: (AppWidget t m, SetRoute t (R FrontendRoute) (ModalM m)) => TokenInfo -> SignedInUser -> Maybe SigningInfo -> m ()
whitelistWorkflows tokenInfo signedInUser maybeSigningInfo = do
  whitelistD <- whitelistDropdown
  tellModal $ ffor (updated whitelistD) $ \case
    LookUpAddress -> \closeE -> do
      workflowDyn <- workflow $ Workflow $
        modalBoxFormW "Holder Whitelist" $ divClass "holder-whitelist" $ do
          SemUi.divider def
          SemUi.header (def
            & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
            & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text "Use the PKH Search to add or remove an address from the whitelist."
          enterE <- getGlobalKeydownEventFor Enter
          pkhSearchD <- searchInputFieldW "PKH Search" (Just "e.g. tz1xuENLmiQQZTWdVKWmiNZCybekXA28i") Nothing
          SemUi.divider def

          signingActionDE <- widgetHold (return never) $ ffor (tag (current pkhSearchD) enterE) $ \pkh -> do
            case tryReadContractIdText pkh of
              Left _ -> elClass "div" "ui shape modal-error-message" $ do
                SemUi.header (def & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $ text pkh
                elClass "p" "modal-message-text" $ text "Is not a valid PKH."
                return never
              Right contractId -> do
                pb <- getPostBuild
                let authToken = _signedInUser_authToken signedInUser

                let checkWhitelistRequest = ApiRequest_Private authToken (PrivateRequest_CheckWhitelist contractId) <$ pb
                checkWhitelistResponse <- requestingIdentity checkWhitelistRequest
                let (checkWhitelistFailureE, checkWhitelistSuccessE) = fanEither checkWhitelistResponse

                let getBalanceRequest = ApiRequest_Private authToken (PrivateRequest_GetTokenHolderBalance contractId) <$ checkWhitelistSuccessE
                getBalanceResponse <- requestingIdentity getBalanceRequest
                let (getBalanceFailureE, getBalanceSuccessE) = fanEither getBalanceResponse

                checkWhitelistResultD <- holdDyn Nothing $ Just <$> checkWhitelistSuccessE
                getBalanceResultD <- holdDyn Nothing $ Just <$> getBalanceSuccessE

                widgetHold_ blank $ errorMessageW . T.pack . show <$> leftmost
                  [ checkWhitelistFailureE, getBalanceFailureE ]

                actionEE <- dyn $ ffor (zipDyn checkWhitelistResultD getBalanceResultD) $ \case
                  (Just checkWhitelistResult, Just balance) ->
                    divClass "ui shape modal-message" $ do
                      SemUi.header def $ text $ toContractIdText contractId

                      case checkWhitelistResult of
                        WhitelistCheck False Nothing -> do
                          whitelistResultW
                           "This address is not on the whitelist."
                            balance
                          addE <- modalSubmitButtonW "Add to Whitelist" $ constDyn False
                          return $ Right (AddToWhitelist contractId) <$ addE

                        WhitelistCheck True Nothing -> do
                          whitelistResultW
                            "This address is on the whitelist."
                            balance
                          removeE <- modalCancelButtonW "Remove from Whitelist"
                          return $ Right (RemoveFromWhitelist contractId) <$ removeE

                        WhitelistCheck False (Just pendingOp) -> do
                          whitelistResultW
                            "This address is not on the whitelist.\nThere is a pending operation to whitelist this address."
                            balance
                          signAddE <- modalSubmitButtonW "Add Signature to Whitelist this Address" $ constDyn False
                          return $ Left pendingOp <$ signAddE

                        WhitelistCheck True (Just pendingOp) -> do
                          whitelistResultW
                            "This address is on the whitelist.\nThere is a pending operation to remove this address from the whitelist."
                            balance
                          signRemoveE <- modalCancelButtonW "Add Signature to Remove Address from Whitelist"
                          return $ Left pendingOp <$ signRemoveE
                  _ ->
                    return never
                switchHold never actionEE


          return $ (never, ffor (switchDyn signingActionDE) $ \case
            Right createOperation ->
              let operationText = lookupTokenOperationText createOperation
                  multisigCall =  buildMultisigCall tokenInfo createOperation
              in connectLedgerWorkflow (_operationText_short operationText) Nothing (\_ -> 
                  signingWorkflow maybeSigningInfo (\signingInfo ->
                    signOperationWorkflow signingInfo multisigCall Nothing operationText))
            Left (pendingOpId, pendingOp) ->
              let operationText = lookupOperationText $ _wrappedCall_payload $ _pendingOperation_operation pendingOp
              in connectLedgerWorkflow (_operationText_short operationText) Nothing (\_ -> 
                  signingWorkflow maybeSigningInfo (\signingInfo ->
                    signOperationWorkflow signingInfo (Just $ _pendingOperation_operation pendingOp) (Just pendingOpId) operationText)))
      return $ leftmost [closeE, switchDyn workflowDyn]
      where
        whitelistResultW messageText balance = do
          elClass "p" "balance-text" $ text $ "Address Balance: " <> T.pack (show balance) <> " RBZ"
          elClass "p" "modal-message-text" $ text messageText


    BatchAdd -> \closeE -> do
      workflowDyn <- workflow $ inputAddressesWorkflow Nothing
      return $ leftmost [closeE, switchDyn workflowDyn]
      where
        inputAddressesWorkflow initialValue = Workflow $
          modalBoxFormW "Add to Whitelist" $ divClass "batch-whitelist" $ mdo
            SemUi.divider def
            SemUi.header (def
              & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
              & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text "Add addresses to the token contract Whitelist."
            elClass "p" "modal-message-text" $ text "Paste the list of addresses you’d like to add into the textbox below.\nOne address per line."
            addressInputE <- textAreaFieldW "Addresses" (Just "e.g.\ntz1xuENLmiQQZTWdVKWmiNZCybekXA28i\ntz1Dw5RNLiuS58PrGoS49nNbAQV7vWtMy") initialValue continueE
            SemUi.divider def
            (cancelE, continueE) <- workflowNavigationW
            return (cancelE, validatingAddressesWorkflow <$> addressInputE)

        validatingAddressesWorkflow rawAddresses = Workflow $
          modalBoxFormW "Add to Whitelist" $ divClass "batch-whitelist" $ mdo
            SemUi.divider def
            SemUi.header (def
              & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
              & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text "Address Validation"
            elClass "p" "modal-message-text" $ text "Please wait while addresses are checked to ensure they are valid."
            loadingW
            validateAddressesE <- validateAddresses (_signedInUser_authToken signedInUser) WhitelistOperation_Add $ filter (not . T.null . T.strip) $ T.lines rawAddresses
            SemUi.divider def
            backE <- divClass "controls" $ modalBackButtonW "Back"

            return (never, leftmost
              [ inputAddressesWorkflow (Just rawAddresses) <$ backE
              , reviewValidatedAddressesWorkflow rawAddresses <$> validateAddressesE
              ])

        reviewValidatedAddressesWorkflow rawAddresses validatedAddresses = Workflow $
          modalBoxW "Add to Whitelist" $ divClass "batch-whitelist" $ mdo
            SemUi.divider def
            SemUi.header (def
              & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
              & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text "Address Validation"
            case partitionEithers validatedAddresses of
              ([], validAddresses) -> do
                elClass "p" "modal-message-text" $
                  text $ (T.pack $ show $ length validAddresses) <> " reviewed."
                positiveValidationMessage (length validAddresses) " valid addresses"
                SemUi.divider def
                (backE, continueE) <- divClass "controls" $ do
                  backE <- modalBackButtonW "Back"
                  continueE <- greenButtonW "Continue" $ constDyn False
                  return (backE, continueE)

                let operation = AddToWhitelistBatch validAddresses
                    operationText = lookupTokenOperationText operation
                    multisigCall =  buildMultisigCall tokenInfo operation

                return (never, leftmost
                  [ inputAddressesWorkflow (Just rawAddresses) <$ backE
                  , connectLedgerWorkflow (_operationText_short operationText) Nothing (\_ -> 
                      signingWorkflow maybeSigningInfo (\signingInfo -> 
                        signOperationWorkflow signingInfo multisigCall Nothing operationText)) <$ continueE
                  ])
              (invalidAddresses, validAddresses) -> do
                elClass "p" "modal-message-text" $ text $ (T.pack $ show $ length validatedAddresses) <> " reviewed."
                divClass "validation-results" $ do
                  positiveValidationMessage
                    (length validAddresses) " valid addresses"
                  negativeValidationMessage
                    (length $ filter (List.any (== InvalidHash) . _invalidAddress_errors) invalidAddresses) " invalid addresses"
                  negativeValidationMessage
                    (length $ filter (List.any (== Whitelisted True) . _invalidAddress_errors) invalidAddresses) " already whitelisted"
                  negativeValidationMessage
                    (length $ filter (List.any (\case
                      DuplicateEntries _ -> True
                      _ -> False) . _invalidAddress_errors) invalidAddresses)
                    " duplicated addresses"
                divClass "ui modal-error-message" $ do
                  el "p" $ el "strong" $ text "All addresses must be valid to continue."
                  el "p" $ text "Please verify that invalid and already whitelisted addresses are not caused by typos or incorrect addresses in your list. You may go back to edit the list of addresses."

                _ <- divClass "listed-addresses" $
                  for invalidAddresses $ \invalidAddress -> do
                    divClass "listed-address" $ do
                      el "div" $ text $ _invalidAddress_address invalidAddress
                      el "div" $ text $ T.intercalate ". " $ T.pack . show <$> _invalidAddress_errors invalidAddress


                SemUi.divider def
                backE <- divClass "controls" $ modalBackButtonW "Back"
                return (never, inputAddressesWorkflow (Just rawAddresses) <$ backE)

    BatchRemove ->  \closeE -> do
      workflowDyn <- workflow $ inputAddressesWorkflow Nothing
      return $ leftmost [closeE, switchDyn workflowDyn]
      where
        inputAddressesWorkflow initialValue = Workflow $
          modalBoxFormW "Remove from Whitelist" $ divClass "batch-whitelist" $ mdo
            SemUi.divider def
            SemUi.header (def
              & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
              & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text "Remove addresses from the token contract Whitelist."
            elClass "p" "modal-message-text" $ text "Paste the list of addresses you’d like to remove into the textbox below.\nOne address per line."
            addressInputE <- textAreaFieldW "Addresses" (Just "e.g.\ntz1xuENLmiQQZTWdVKWmiNZCybekXA28i\ntz1Dw5RNLiuS58PrGoS49nNbAQV7vWtMy") initialValue continueE
            SemUi.divider def
            (cancelE, continueE) <- workflowNavigationW
            return (cancelE, validatingAddressesWorkflow <$> addressInputE)

        validatingAddressesWorkflow rawAddresses = Workflow $
          modalBoxFormW "Remove from Whitelist" $ divClass "batch-whitelist" $ mdo
            SemUi.divider def
            SemUi.header (def
              & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
              & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text "Address Validation"
            elClass "p" "modal-message-text" $ text "Please wait while addresses are checked to ensure they are valid."
            loadingW
            validateAddressesE <- validateAddresses (_signedInUser_authToken signedInUser) WhitelistOperation_Remove $ filter (not . T.null . T.strip) $ T.lines rawAddresses
            SemUi.divider def
            backE <- divClass "controls" $ modalBackButtonW "Back"

            return (never, leftmost
              [ inputAddressesWorkflow (Just rawAddresses) <$ backE
              , reviewValidatedAddressesWorkflow rawAddresses <$> validateAddressesE
              ])

        reviewValidatedAddressesWorkflow rawAddresses validatedAddresses = Workflow $
          modalBoxW "Remove from Whitelist" $ divClass "batch-whitelist" $ mdo
            SemUi.divider def
            SemUi.header (def
              & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
              & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text "Address Validation"
            case partitionEithers validatedAddresses of
              ([], validAddresses) -> do
                elClass "p" "modal-message-text" $
                  text $ (T.pack $ show $ length validAddresses) <> " reviewed."
                positiveValidationMessage (length validAddresses) " valid addresses"
                SemUi.divider def
                (backE, continueE) <- divClass "controls" $ do
                  backE <- modalBackButtonW "Back"
                  continueE <- greenButtonW "Continue" $ constDyn False
                  return (backE, continueE)

                let operation = RemoveFromWhitelistBatch validAddresses
                    operationText = lookupTokenOperationText operation
                    multisigCall =  buildMultisigCall tokenInfo operation

                return (never, leftmost
                  [ inputAddressesWorkflow (Just rawAddresses) <$ backE
                  , connectLedgerWorkflow (_operationText_short operationText) Nothing (\_ -> 
                      signingWorkflow maybeSigningInfo (\signingInfo -> 
                        signOperationWorkflow signingInfo multisigCall Nothing operationText)) <$ continueE
                  ])
              (invalidAddresses, validAddresses) -> do
                elClass "p" "modal-message-text" $ text $ (T.pack $ show $ length validatedAddresses) <> " reviewed."
                divClass "validation-results" $ do
                  positiveValidationMessage
                    (length validAddresses) " valid addresses"
                  negativeValidationMessage
                    (length $ filter (List.any (== InvalidHash) . _invalidAddress_errors) invalidAddresses) " invalid addresses"
                  negativeValidationMessage
                    (length $ filter (List.any (== Whitelisted False) . _invalidAddress_errors) invalidAddresses) " not whitelisted"
                  negativeValidationMessage
                    (length $ filter (List.any (\case
                      DuplicateEntries _ -> True
                      _ -> False) . _invalidAddress_errors) invalidAddresses)
                    " duplicated addresses"
                divClass "ui modal-error-message" $ do
                  el "p" $ el "strong" $ text "All addresses must be valid to continue."
                  el "p" $ text "Please verify that invalid addresses and addresses not whitelisted are not caused by typos or incorrect addresses in your list. You may go back to edit the list of addresses."

                _ <- divClass "listed-addresses" $
                  for invalidAddresses $ \invalidAddress -> do
                    divClass "listed-address" $ do
                      el "div" $ text $ _invalidAddress_address invalidAddress
                      el "div" $ text $ T.intercalate ". " $ T.pack . show <$> _invalidAddress_errors invalidAddress


                SemUi.divider def
                backE <- divClass "controls" $ modalBackButtonW "Back"
                return (never, inputAddressesWorkflow (Just rawAddresses) <$ backE)
  where
    positiveValidationMessage count description =
      SemUi.message (def & SemUi.messageConfig_color SemUi.|?~ SemUi.Green) $
        elClass "p" "modal-validation-text" $ text $ T.pack (show count) <> description
    negativeValidationMessage count description =
      when (count > 0) $
        SemUi.message (def & SemUi.messageConfig_color SemUi.|?~ SemUi.Red) $
          elClass "p" "modal-validation-text" $ text $ T.pack (show count) <> description


data InvalidAddress = InvalidAddress
  { _invalidAddress_address :: T.Text
  , _invalidAddress_errors :: [ValidationError]
  }

data ValidationError
  = InvalidHash
  | Whitelisted Bool
  | DuplicateEntries Int
  deriving Eq

instance Show ValidationError where
  show = \case
    InvalidHash -> "Not a valid address"
    Whitelisted True -> "Already whitelisted"
    Whitelisted False -> "Not whitelisted"
    DuplicateEntries count -> "Duplicated, found " <> show count <> " times"

data WhitelistOperation
  = WhitelistOperation_Add
  | WhitelistOperation_Remove
  deriving (Eq)

validateAddresses
  :: AppModalWidget t m => AppCredential BTG -> WhitelistOperation -> [T.Text] -> m (Event t [Either InvalidAddress ContractId])
validateAddresses token whitelistOperation rawAddresses = do
  pb <- getPostBuild
  let (invalidAddresses, validAddresses) = partitionEithers $ ffor rawAddresses $ \rawAddress ->
        case tryReadContractIdText rawAddress of
          Right contractId -> Right contractId
          Left _ -> Left rawAddress
      countedValidHashes = countElems validAddresses
      countedInvalidHashes = countElems invalidAddresses

  checkWhitelistBatchResponseE <- requestingIdentity $ ApiRequest_Private token (PrivateRequest_CheckWhitelistBatch (M.keys countedValidHashes)) <$ pb

  let (failureE, successE) = fanEither checkWhitelistBatchResponseE
      validationsE =
        ffor successE $ \isWhitelistedResults ->
          let mergedResults = M.merge M.dropMissing M.dropMissing (M.zipWithMatched (\_ a b -> (a,b))) countedValidHashes (M.fromList isWhitelistedResults)
              validHashes = ffor (M.assocs mergedResults ) $ \(address, (count, isWhitelisted)) ->
                case (count, whitelistOperation, isWhitelisted) of
                  (1, WhitelistOperation_Add, False) ->
                    Right address
                  (1, WhitelistOperation_Remove, True) ->
                    Right address

                  (1, WhitelistOperation_Add, True) ->
                    Left $ InvalidAddress (toContractIdText address) [ Whitelisted True ]
                  (_, WhitelistOperation_Add, True) ->
                    Left $ InvalidAddress (toContractIdText address)  [ Whitelisted True, DuplicateEntries count ]

                  (1, WhitelistOperation_Remove, False) ->
                    Left $ InvalidAddress (toContractIdText address) [ Whitelisted False ]
                  (_, WhitelistOperation_Remove, False) ->
                    Left $ InvalidAddress (toContractIdText address)  [ Whitelisted False, DuplicateEntries count ]

                  (_, WhitelistOperation_Add, False) ->
                    Left $ InvalidAddress (toContractIdText address) [ DuplicateEntries count ]
                  (_, WhitelistOperation_Remove, True) ->
                    Left $ InvalidAddress (toContractIdText address) [ DuplicateEntries count ]
              invalidHashes = ffor (M.assocs countedInvalidHashes) $ \(rawAddress, count) ->
                case count of
                  1 ->
                    Left $ InvalidAddress rawAddress  [ InvalidHash ]
                  _ ->
                    Left $ InvalidAddress rawAddress [ InvalidHash, DuplicateEntries count ]
          in validHashes <> invalidHashes

  widgetHold_ blank $ errorMessageW "Error validating addresses. Please try again." <$ failureE

  return validationsE

  where
    countElems :: (Ord a) => [a] -> M.Map a Int
    countElems = M.fromListWith (+) . flip zip (repeat 1)
