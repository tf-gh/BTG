{-# LANGUAGE ConstraintKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE OverloadedStrings #-}

module Frontend.App where

import Control.Monad.IO.Class
import Control.Monad.Reader
import Data.Constraint.Extras
import Data.Functor.Identity
import Data.GADT.Compare
import Language.Javascript.JSaddle.Types
import Obelisk.Route.Frontend
import Reflex.Dom
import Rhyolite.App
import Rhyolite.Frontend.App hiding (FrontendConfig)
import Rhyolite.Frontend.Modal.Class

import Common.App
import Common.Schema

type BaseAppWidget t m =
  ( MonadRhyoliteFrontendWidget BTG t m
  , MonadJSM (Performable m)
  , MonadIO (Performable m)
  , HasJSContext (Performable m)
  , MonadJSM m
  , HasDocument m
  )

type AppWidget t m =
  ( BaseAppWidget t m
  , MonadReader (FrontendConfig t) m
  , MonadReader (FrontendConfig t) (ModalM m)
  , ModalConstraints t m
  )

type AppModalWidget t m =
  ( BaseAppWidget t m
  , MonadReader (FrontendConfig t) m
  )

type ModalConstraints t m =
  ( MonadRhyoliteFrontendWidget BTG t (ModalM m)
  , HasModal t m
  , MonadJSM (Performable (ModalM m))
  , MonadJSM (ModalM m)
  , HasJSContext (Performable (ModalM m))
  , HasDocument (ModalM m)
  )

type RouteConstraints t r m =
  ( Routed t (R r) m
  , RouteToUrl (R r) m
  , SetRoute t (R r) m
  , GEq r
  , Has' Eq r Identity
  )

data SignedInUser = SignedInUser
  { _signedInUser_authToken :: AppCredential BTG
  , _signedInUser_userInfo :: UserInfo
  }

data FrontendConfig t = FrontendConfig
  { _frontendConfig_signedInUser :: Maybe SignedInUser
  , _frontendConfig_globalKeydownEvent :: Event t Key
  }

getAuthToken
  :: MonadReader (FrontendConfig t) m
  => m (AppCredential BTG)
getAuthToken = do
  -- TODO: DONT PATTERN MATCH LIKE THIS IN FRONTEND MODULES
  Just signedInUser <- asks _frontendConfig_signedInUser
  pure $ _signedInUser_authToken signedInUser

getGlobalKeydownEventFor
  :: (Reflex t, MonadReader (FrontendConfig t) m)
  => Key -> m (Event t ())
getGlobalKeydownEventFor key = do
  globalKeydownE <- asks _frontendConfig_globalKeydownEvent
  return $ () <$ ffilter (== key) globalKeydownE
