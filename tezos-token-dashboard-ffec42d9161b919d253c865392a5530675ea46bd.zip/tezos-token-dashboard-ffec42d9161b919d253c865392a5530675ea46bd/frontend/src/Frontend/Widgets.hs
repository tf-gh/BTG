{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecursiveDo #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeApplications #-}

module Frontend.Widgets where

import Common.App
import Control.Lens
import Control.Monad.Fix
import Control.Monad.Reader
import Data.Align
import Data.SecureMem
import Data.Bifunctor
import Data.Bool
import Data.Either.Combinators
import qualified Data.Map.Lazy as Map
import qualified Data.Map.Monoidal as MMap
import Data.Maybe
import Data.Text (Text)
import qualified Data.Text as T
import Data.These
import Data.Time.Clock
import Data.Witherable as W
import Database.Id.Class
import qualified GHCJS.DOM as DOM
import qualified GHCJS.DOM.Document as Document
import qualified GHCJS.DOM.HTMLTextAreaElement as TextArea
import qualified GHCJS.DOM.Node as Node
import qualified GHCJS.DOM.Types as DOM
import qualified JSDOM.Types as Types
import Language.Javascript.JSaddle.Types
import Obelisk.Generated.Static
import Reflex.Dom
import Reflex.Dom.SemanticUI (UI)
import qualified Reflex.Dom.SemanticUI as SemUi
import Rhyolite.Account
import Rhyolite.Api
import Rhyolite.Sign
import Tezos.Wrapped.Schema
import Tezos.V005.PublicKeyHash

import Common.Schema
import Frontend.App
import Frontend.Ledger
import Frontend.OperationText

modalBoxFormW :: UI t m => Text -> m (Event t (), a) -> m (Event t (), a)
modalBoxFormW = modalBoxBaseW True

modalBoxW :: UI t m => Text -> m (Event t (), a) -> m (Event t (), a)
modalBoxW = modalBoxBaseW False

modalBoxBaseW :: UI t m => Bool -> Text -> m (Event t (), a) -> m (Event t (), a)
modalBoxBaseW asForm title contentW  = do
  elClass "div" "modal-box ui center aligned" $ do
    closeE <- SemUi.header (def
        & SemUi.headerConfig_aligned SemUi.|~ Just SemUi.LeftAligned
        & SemUi.headerConfig_size SemUi.|~ Just SemUi.H3) $ do
          text title
          closeButtonW
    (cancelE, result) <- elClass "div" ("ui content" <> bool "" " form" asForm) $ contentW
    pure (leftmost [ closeE, cancelE], result)

modalSubmitButtonW :: UI t m => Text -> Dynamic t Bool -> m (Event t ())
modalSubmitButtonW name loadingD =
  SemUi.button (def
  & SemUi.buttonConfig_type .~ SemUi.SubmitButton
  & SemUi.buttonConfig_loading .~ SemUi.Dyn loadingD
  & SemUi.buttonConfig_color SemUi.|~ Just SemUi.Green) (text name)

modalCancelButtonW :: UI t m => Text -> m (Event t ())
modalCancelButtonW name =
  SemUi.button (def
  & SemUi.buttonConfig_type .~ SemUi.SubmitButton) (text name)

modalBackButtonW :: UI t m => Text -> m (Event t ())
modalBackButtonW name =
  SemUi.button (def
  & SemUi.buttonConfig_type .~ SemUi.SubmitButton
  & SemUi.buttonConfig_color SemUi.|~ Just SemUi.Black) (text name)

formContainerW :: UI t m => Text -> m a -> m a
formContainerW title formW = do
  elClass "div" "form-container ui center aligned" $
    elClass "div" ("column twelve wide") $ do
      formHeaderW title
      elClass "div" "ui form" $ formW

cardContainerW :: UI t m => Text -> m a -> m a
cardContainerW title cardW = do
  elClass "div" "card-container ui center aligned" $
    elClass "div" "ui" $ do
      formHeaderW title
      elClass "div" "ui form" $ cardW

formHeaderW :: UI t m => Text -> m ()
formHeaderW title =
  elClass "div" "form-header" $
    SemUi.header (def
      & SemUi.headerConfig_aligned SemUi.|~ Just SemUi.CenterAligned
      & SemUi.headerConfig_size SemUi.|~ Just SemUi.H1) (text title)

errorContainerW :: UI t m => Text -> m a -> m a
errorContainerW title errorW = do
  elClass "div" "error-container ui center aligned" $ do
    formHeaderW title
    elClass "div" "ui shape error-message" $ errorW

inputWidget
  :: (UI t m, DomBuilderSpace m ~ GhcjsDomSpace, MonadJSM (Performable m))
  => Maybe Text -> Maybe Text -> m (Dynamic t Text, Event t ())
inputWidget placeholder initialValue = do
  input <- SemUi.textInput (def
    & SemUi.textInputConfig_placeholder SemUi.|~ fromMaybe "" placeholder
    & SemUi.textInputConfig_value .~ SemUi.SetValue (fromMaybe "" initialValue) Nothing)
  pure (fmap T.strip (_textInput_value input), never)

textInputFieldW'
  :: forall t m. (UI t m, DomBuilderSpace m ~ GhcjsDomSpace, MonadJSM (Performable m))
  => Text -> Maybe Text -> Maybe Text -> [Event t Text -> Event t (Maybe Text)] -> Event t () -> m (Event t Text)
textInputFieldW' name placeholder initialValue validations submitE = mdo
  (inputValueE, _) <- inputFieldW' name submitE validations False $ inputWidget placeholder initialValue
  pure inputValueE

textInputFieldW
  :: forall t m. (UI t m, DomBuilderSpace m ~ GhcjsDomSpace, MonadJSM (Performable m))
  => Text -> Maybe Text -> Maybe Text -> [Text -> Maybe Text] -> Event t () -> m (Event t Text)
textInputFieldW name placeholder initialValue validations submitE = mdo
  (inputValueE, _) <- inputFieldW name submitE validations False $ inputWidget placeholder initialValue
  pure inputValueE

searchInputFieldW
  :: forall t m. (UI t m, DomBuilderSpace m ~ GhcjsDomSpace, MonadJSM (Performable m))
  => Text -> Maybe Text -> Maybe Text -> m (Dynamic t Text)
searchInputFieldW name placeholder initialValue =
  elClass "div" "search-input-field" $ mdo
    elClass "div" "field-name" $ do
      elClass "span" "name" $ text name
      SemUi.input (def & SemUi.inputConfig_icon SemUi.|?~ SemUi.LeftIcon) $ do
        SemUi.icon "search" def
        input <- SemUi.textInput (def
          & SemUi.textInputConfig_placeholder SemUi.|~ fromMaybe "" placeholder
          & SemUi.textInputConfig_value .~ SemUi.SetValue (fromMaybe "" initialValue) Nothing)
        pure $ fmap T.strip (_textInput_value input)

disabledTextInputFieldW
  :: forall t m. (UI t m, DomBuilderSpace m ~ GhcjsDomSpace, MonadJSM (Performable m))
  => Text -> Text -> m ()
disabledTextInputFieldW name lockedValue = mdo
  _ <- inputFieldW name never [] False $ do
    _ <- SemUi.input' (def & SemUi.inputConfig_disabled SemUi.|~ True) $
      SemUi.textInput (def
        & SemUi.textInputConfig_value .~ SemUi.SetValue lockedValue Nothing)
    pure (constDyn "", ())
  return ()

textAreaFieldW
  :: forall t m. (UI t m, DomBuilderSpace m ~ GhcjsDomSpace)
  => Text -> Maybe Text -> Maybe Text -> Event t () -> m (Event t Text)
textAreaFieldW name placeholder initialValue submitE = mdo
  (inputValueE, _) <- inputFieldW name submitE [] False $ do
    input <- textArea $ def
      { _textAreaConfig_attributes = constDyn $ "placeholder" =: fromMaybe "" placeholder
      , _textAreaConfig_initialValue = fromMaybe "" initialValue
      }
    pure (fmap T.strip (_textArea_value input), never :: Event t ())
  pure inputValueE

passwordInputFieldW :: UI t m => Event t () -> m a -> m (Event t SecureMem, a)
passwordInputFieldW submitE extraW = (first (fmap textToSecureMem)) <$> passwordInputFieldW' "Password" [] False submitE extraW

passwordInputFieldW' :: UI t m => Text -> [Text -> Maybe Text] -> Bool -> Event t () -> m a -> m (Event t Text, a)
passwordInputFieldW' name validations passthroughOnError submitE extraW =
  inputFieldW name submitE validations passthroughOnError $ do
    input <- inputElement $ def
      & (inputElementConfig_elementConfig . elementConfig_initialAttributes) .~ ("type" =: "password")
    extra <- extraW
    pure (_inputElement_value input, extra)

updatePasswordW :: forall t m. UI t m => Bool -> Event t () -> m (Event t SecureMem)
updatePasswordW isNewAccount submitE = mdo
  (passwordInputOne, _) <- passwordInputFieldW' (bool "New Password" "Password" isNewAccount)
    [(\val -> if T.length val < 8 then Just "Password must be at least 8 characters long" else Nothing)] True submitE $ pure (never :: Event t ())
  passwordInputTwo <- elClass "div" "input-field" $ mdo
    elClass "div" "field-name" $ do
      elClass "span" "name" $ text "Repeat Password"
      widgetHold_ blank $ ffor (updated passwordsD) $ \case
        That "" -> errorLabelW "Repeat Password required"
        These "" "" -> errorLabelW "Repeat Password required"
        These a b | a /= b -> errorLabelW "Passwords do not match"
        _ -> blank
    classD <- holdDyn "" $ (\theseThings -> if theseToBool theseThings then "" else "error") <$> updated passwordsD
    input <- elDynClass "div" (fmap ("ui field " <>) classD) $ inputElement $ def
      & (inputElementConfig_elementConfig . elementConfig_initialAttributes) .~ ("type" =: "password")
    pure $ tag (current (_inputElement_value input)) submitE
  passwordsD <- holdDyn (These "" "") $ align passwordInputOne passwordInputTwo
  pure $ attachPromptlyDynWithMaybe (\passwordsMatch password ->
    if passwordsMatch then Just (textToSecureMem password) else Nothing
    ) (theseToBool <$> passwordsD) $ passwordInputOne
  where
    theseToBool ths = these (const False) (const False) (\a b -> T.length a >= 8 && not (T.null a) && a == b) ths

inputFieldW' :: UI t m => Text -> Event t () -> [Event t Text -> Event t (Maybe Text)] -> Bool -> m (Dynamic t Text, a) -> m (Event t Text, a)
inputFieldW' name submitE validations passthroughOnError inputW =
  elClass "div" "input-field" $ mdo
    inputErrorD <- elClass "div" "field-name" $ do
      elClass "span" "name" $ text name
      let emptyValueE = (name <> " is required") <$ ffilter T.null submitValueE
          failedValidationE = mconcat $ fmap ($ submitValueE) validations
          errorE = leftmost [Just <$> emptyValueE, failedValidationE, Nothing <$ submitValueE]
      inputErrorD' <- holdDyn Nothing errorE
      dyn_ $ ffor inputErrorD' $ \case
        Just message -> errorLabelW message
        Nothing -> blank
      pure inputErrorD'
    classD <- holdDyn "" $ maybe "" (const "error") <$> updated inputErrorD
    (inputValueD, result) <- elDynClass "div" (fmap ("ui field " <>) classD) inputW
    let submitValueE = tag (current inputValueD) submitE
    pure (attachPromptlyDynWithMaybe (\inputError submitValue ->
        if isNothing inputError || passthroughOnError then Just submitValue else Nothing
      ) inputErrorD submitValueE, result)

-- | Same as inputFieldW' but takes validators that act on pure values instead of the submit event
inputFieldW :: UI t m => Text -> Event t () -> [Text -> Maybe Text] -> Bool -> m (Dynamic t Text, a) -> m (Event t Text, a)
inputFieldW name submitE validations passthroughOnError inputW = inputFieldW' name submitE validations' passthroughOnError inputW
  where validations' = fmap fmap validations

submitButtonW :: (UI t m, MonadReader (FrontendConfig t) m) => Bool -> Text -> Dynamic t Bool -> m (Event t ())
submitButtonW enterEnabled name loadingD = do
  enterE <- bool (pure never) (getGlobalKeydownEventFor Enter) enterEnabled
  submitButtonE <- buttonW name SemUi.Blue loadingD
  return $ leftmost [enterE, submitButtonE]

closeButtonW :: UI t m => m (Event t ())
closeButtonW = el "span" $ do
  closeEl <- SemUi.icon' "close" $ def
    & SemUi.iconConfig_size SemUi.|?~ SemUi.Medium
    & (SemUi.iconConfig_elConfig . SemUi.classes) SemUi.|~ SemUi.Classes ["close-button"]
  pure $ domEvent Click closeEl

buttonW :: UI t m => Text -> SemUi.Color -> Dynamic t Bool -> m (Event t ())
buttonW name color loadingD = do
  SemUi.button (def
    & SemUi.buttonConfig_type .~ SemUi.SubmitButton
    & SemUi.buttonConfig_loading .~ SemUi.Dyn loadingD
    & SemUi.buttonConfig_color SemUi.|~ Just color
    & SemUi.buttonConfig_fluid SemUi.|~ True) (text name)

-- Why do we have both blue and green buttons?
greenButtonW :: UI t m => Text -> Dynamic t Bool -> m (Event t ())
greenButtonW name loadingD = do
  SemUi.button (def
    & SemUi.buttonConfig_type .~ SemUi.SubmitButton
    & SemUi.buttonConfig_loading .~ SemUi.Dyn loadingD
    & SemUi.buttonConfig_color SemUi.|~ Just (SemUi.Green)
    & SemUi.buttonConfig_fluid SemUi.|~ False) (text name)

greenButtonDisabledW :: UI t m => Text -> Dynamic t Bool -> m (Event t ())
greenButtonDisabledW name disabledD = do
  SemUi.button (def
    & SemUi.buttonConfig_type .~ SemUi.SubmitButton
    & SemUi.buttonConfig_disabled .~ SemUi.Dyn disabledD
    & SemUi.buttonConfig_color SemUi.|~ Just (SemUi.Green)
    & SemUi.buttonConfig_fluid SemUi.|~ False) (text name)

errorMessageW :: UI t m => Text -> m ()
errorMessageW contents =
  SemUi.message (def
    & SemUi.messageConfig_type SemUi.|?~ SemUi.MessageType SemUi.Error
    & (SemUi.messageConfig_elConfig . SemUi.classes) SemUi.|~ SemUi.Classes ["visible"]) $ text contents

responseMessageW :: UI t m => Text -> BTGResponse r -> m ()
responseMessageW successMsg response =
  case response of
    Left err -> errorMessageW $ T.pack $ show err
    Right _ ->
      SemUi.message (def
        & (SemUi.messageConfig_elConfig . SemUi.classes) SemUi.|~ SemUi.Classes ["visible"]) $
        text $ successMsg

errorLabelW :: UI t m => Text -> m ()
errorLabelW contents =
  elClass "div" "field-error-label" $ SemUi.label (def
    & SemUi.labelConfig_pointing SemUi.|~ Just SemUi.BelowPointing
    & SemUi.labelConfig_color SemUi.|~ Just SemUi.Red
    & SemUi.labelConfig_basic SemUi.|~ True) $ text contents

messageLabelW :: UI t m => Text -> m ()
messageLabelW contents =
  elClass "div" "message-label" $ SemUi.label (def
    & SemUi.labelConfig_pointing SemUi.|~ Just SemUi.BelowPointing
    & SemUi.labelConfig_color SemUi.|~ Just SemUi.Black
    & SemUi.labelConfig_basic SemUi.|~ True) $ text contents

hoveringToolTipLabelW :: UI t m => Dynamic t Bool -> Text -> Text -> m ()
hoveringToolTipLabelW hiddenD classname contents =
  elClass "div" ("tooltip-label" <> classname) $ SemUi.label (def
    & SemUi.labelConfig_hidden .~ SemUi.Dyn hiddenD
    & SemUi.labelConfig_pointing SemUi.|~ Just SemUi.BelowPointing
    & SemUi.labelConfig_color SemUi.|~ Just SemUi.Black
    & SemUi.labelConfig_basic SemUi.|~ True) $ text contents

dropdownMenuClosingModalDiv :: forall m t a. (DomBuilder t m, MonadHold t m, MonadFix m) => Text -> Event t (m (Event t a)) -> m (Event t a)
dropdownMenuClosingModalDiv cls openClosingModalWithDropdownMenu = mdo
  modalEv <- widgetHold (return never) $ ffor (leftmost [open, close]) $ \case
    Nothing -> return never
    Just childW -> do
      (backgroundEl, _) <- elClass' "div" cls blank
      childWResult <- childW
      let backgroundEvent = domEvent Click backgroundEl
      return $ leftmost [Left <$> backgroundEvent, Right <$> childWResult]
  let open = Just <$> openClosingModalWithDropdownMenu
      close = Nothing <$ (switch . current $ modalEv)
  return $ fmapMaybe rightToMaybe $ switch . current $ modalEv

copyToClipboardW :: (UI t m, MonadJSM (Performable m)) => Text -> m ()
copyToClipboardW copyText =
  divClass "flex" $ mdo
    textValueD <- holdDyn "Click to copy text to clipboard" $ leftmost
      [ bool "Copy failed." "Copied!" <$> resultEv
      , "Click to copy text to clipboard" <$ domEvent Mouseleave cIcon
      ]
    cIcon <- dynTooltipW textValueD copyIcon
    el "p" $ text copyText
    resultEv <- performCopyToClipboard $ copyText <$ domEvent Click cIcon
    return ()
  where
    copyIcon =
      SemUi.icon' "copy" $ def
        & SemUi.iconConfig_color SemUi.|?~ SemUi.Blue
        & SemUi.iconConfig_disabled SemUi.|~ False

-- | Copy the given text to the clipboard
performCopyToClipboard
  :: (MonadJSM (Performable m), PerformEvent t m)
  => Event t Text
  -- ^ Text to copy to clipboard. Event must come directly from user
  -- interaction (e.g. domEvent Click), or the copy will not take place.
  -> m (Event t Bool)
  -- ^ Did the copy take place successfully?
performCopyToClipboard copyEvent = performEvent $
  ffor copyEvent $ \copyText -> do
    doc <- DOM.currentDocumentUnchecked
    ta <- DOM.uncheckedCastTo TextArea.HTMLTextAreaElement <$> Document.createElement doc ("textarea" :: Text)
    TextArea.setValue ta copyText
    body <- Document.getBodyUnchecked doc
    _ <- Node.appendChild body ta
    TextArea.select ta
    result <- Document.execCommand doc ("copy" :: Text) False (Nothing :: Maybe Text)
    _ <- Node.removeChild body ta
    return result

dropdownMenu
  :: forall active t m a. ( SemUi.SingActive active, SemUi.UI t m, Show a, Ord a, Types.MonadJSM (Performable m), Types.MonadJSM m, DomBuilderSpace m ~ GhcjsDomSpace )
  => SemUi.DropdownConfig t a -> a -> Event t a -> SemUi.TaggedActive active t [a] -> m (Dynamic t a)
dropdownMenu conf ini evt items = do
  dropdownResult <- SemUi.dropdown conf (Identity ini) (fmapCheap Identity evt) $ ffor items $ \item ->
    Map.fromList $ fmap (\t -> (t, text $ T.pack $ show t)) item
  return $ runIdentity <$> SemUi._dropdown_value dropdownResult

connectLedgerWorkflow
  :: AppModalWidget t m
  => Text -> Maybe PublicKeyHash -> (Version -> Workflow t m (Event t ())) -> Workflow t m (Event t ())
connectLedgerWorkflow title maybePublicKeyHash nextWorkflow = Workflow $
  modalBoxFormW title $ mdo
    SemUi.divider def
    ledgerStatusW maybePublicKeyHash False
    elClass "div" "description" $ do
      loadingW
      SemUi.header (def
        & SemUi.headerConfig_size SemUi.|?~ SemUi.H2
        & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text "Looking for Tezos Wallet app on Ledger device..."
      elClass "div" "instruction" $
        el "p" $ text "Connect your Ledger device, enter the PIN and open the Tezos Wallet app (version 2.0.0 or higher)."
    SemUi.message def $ do
      SemUi.header def $ text "To install the Tezos Wallet app:"
      el "ol" $ do
        el "li" $ text "Install and open Ledger Live: https://www.ledger.com/pages/ledger-live"
        el "li" $ text "Go to Manager and search for “Tezos”"
        el "li" $ text "Install the “Tezos Wallet” app"
        el "li" $ text "Open the Tezos Wallet app on your Ledger device"
    SemUi.divider def
    cancelE <- elClass "div" "controls" $ modalCancelButtonW "Cancel"
    pb <- getPostBuild
    ledgerConnectedE <- callJavascriptAsync $ getVersion <$ leftmost [ pb, () <$ ffilter isNothing delayedLedgerConnectedE ]
    delayedLedgerConnectedE <- delay 1.0 ledgerConnectedE

    pure (cancelE, nextWorkflow <$> fmapMaybe id delayedLedgerConnectedE)

cancelOperationPromptWorkflow
  :: forall t m. AppModalWidget t m
  => Signed (AuthToken Identity, UTCTime)
  -> Id PendingOperation
  -> PendingOperation
  -> Text
  -> Dynamic t (MMap.MonoidalMap (Id PendingOperation) PendingOperation)
  -> Workflow t m (Event t ())
cancelOperationPromptWorkflow token pendingId pendingOp title dynPendingOps = Workflow $ do
  modalBoxFormW title $ mdo
    SemUi.divider def
    divClass "cancel-op-modal-body" $ do
      divClass "cancel-op-content" $ do
        el "h2" $ text $ "Are you sure you want to cancel this " <> opType <> " Operation?"
        el "p" $ text "All signatures gathered will be deleted and the operation will be removed from the pending operations list."
      dyn_ $ ffor (MMap.toList <$> dmLaterOperations) $ alsoCancellingCallout
    SemUi.divider def
    loadingD <- holdDyn False $ leftmost [ True <$ cancelOpRequestE, False <$ cancelOpResponseE ]
    (backBtn, yesBtn) <- divClass "cancel-workflow-button-footer" $ do
      backBtn' <- buttonW "Back" SemUi.Grey (constDyn False)
      let yesBtnW msg = greenButtonW msg loadingD
      yesBtnUpdated' <- dyn $ yesBtnW . cancelButtonMsg . MMap.null <$> dmLaterOperations
      yesBtn' <- switchDyn <$> holdDyn never yesBtnUpdated'
      return (backBtn', yesBtn')
    let cancelOpRequestE = (ApiRequest_Private token $ PrivateRequest_CancelOperation pendingId) <$ yesBtn
    cancelOpResponseE <- requestingIdentity cancelOpRequestE
    return (backBtn, cancelResultConfirmationW <$> cancelOpResponseE)
  where
    thisMSCall = _pendingOperation_operation pendingOp
    thisCounter = _wrappedCall_counter thisMSCall
    opType = T.pack $ showOperationType $ _wrappedCall_payload thisMSCall
    testOpIsLater = (> thisCounter) . _wrappedCall_counter . _pendingOperation_operation
    dmLaterOperations :: Dynamic t (MMap.MonoidalMap (Id PendingOperation) PendingOperation)
    dmLaterOperations = W.filter testOpIsLater <$> dynPendingOps
    cancelButtonMsg = \case
      True -> "Yes, Cancel the Operation"
      False -> "Yes, Cancel all these Operations"
    alsoCancellingCallout :: [(Id PendingOperation, PendingOperation)] -> m ()
    alsoCancellingCallout = \case
      [] -> return ()
      listOfLaterOps -> elClass "div" "ui modal-message modal-error-message" $ do
        el "h3" $ text "This action will also cancel other pending operations"
        el "p" $ text "All pending operations listed below have a sequence number higher than the sequence number of the operation you are cancelling will also be cancelled:"
        elClass "table" "operations-table" $ do
          elClass "tr" "table-header" $ do
            el "th" $ text "Sequence"
            el "th" $ text "Type"
          forM_ listOfLaterOps $ \(_, laterOp) -> elClass "tr" "table-row" $ do
            el "td" $ text $ T.pack $ show $ _wrappedCall_counter $ _pendingOperation_operation laterOp
            el "td" $ text $ T.pack $ showOperationType $ _wrappedCall_payload $ _pendingOperation_operation laterOp
    cancelResultConfirmationW :: BTGResponse () -> Workflow t m (Event t ())
    cancelResultConfirmationW cancelResult = Workflow $ do
      modalBoxFormW title $ mdo
        SemUi.divider def
        divClass "cancel-op-modal-body" $ case cancelResult of
          Right _ -> do
            divClass "success-check-container" $ SemUi.icon "checkmark" def
            el "h3" $ text "The operation has been cancelled."
          Left err -> do
            divClass "fail-x-container" $ elClass "i" "fa fa-times" blank
            el "h3" $ text "The operation could not be cancelled."
            el "p" $ text $ T.pack $ show err
        SemUi.divider def
        doneE <- divClass "cancel-workflow-button-footer" $ do
          greenButtonW "Done" $ constDyn False
        return (doneE, never)

ledgerStatusW :: UI t m => Maybe PublicKeyHash -> Bool -> m ()
ledgerStatusW maybePublicKeyHash isConnected =
  elClass "div" "ui ledger-status" $ do
    el "div" $ elAttr "img" ("src" =: static @"images/ledger.svg") blank
    maybe blank (el "div" . text . toPublicKeyHashText) maybePublicKeyHash
    if isConnected
      then
        SemUi.label (def & SemUi.labelConfig_color SemUi.|?~ SemUi.Teal) $ do
          SemUi.icon "checkmark" def
          text $ "Connected"
      else
        SemUi.label def $ text $ "Not Connected"

loadingW :: DomBuilder t m => m ()
loadingW =
  elClass "div" "ui active small centered inline loader" blank

operationButton :: SemUi.UI t m => Text -> Text -> m (Event t ())
operationButton iconName label = do
  (p, _) <- elClass' "div" "operation-button" $ do
    divClass "operation-button-icon" $ SemUi.icon (SemUi.Static iconName) def
    divClass "operation-button-caption" $ text label
  return $ domEvent Click p

operationButtonFA :: SemUi.UI t m => Text -> Text -> m (Event t ())
operationButtonFA iconName label = do
  (p, _) <- elClass' "div" "operation-button" $ do
    elClass "i" iconName blank
    divClass "operation-button-caption" $ text label
  return $ domEvent Click p

workflowNavigationW :: SemUi.UI t m => m (Event t (), Event t ())
workflowNavigationW =
  divClass "controls" $ do
    cancelE <- modalCancelButtonW "Cancel"
    continueE <- greenButtonW "Continue" $ constDyn False
    return (cancelE, continueE)

tooltipW
  :: SemUi.UI t m => Text -> Dynamic t Bool -> m a -> m a
tooltipW textValue enableD widget  =
  let dynAttr = bool mempty ("data-tooltip" =: textValue <> "data-position" =: "top center") <$> enableD
  in elDynAttr "div" dynAttr widget

dynTooltipW
  :: SemUi.UI t m => Dynamic t Text -> m a -> m a
dynTooltipW textValueD widget  =
  let dynAttr = (\textValue -> "data-tooltip" =: textValue <> "data-position" =: "top center") <$> textValueD
  in elDynAttr "div" dynAttr widget

dynWithEvent :: (MonadHold t m, DomBuilder t m, PostBuild t m) => Dynamic t (m (Event t a)) -> m (Event t a)
dynWithEvent dynWidget = mdo
  nestedEvent <- dyn dynWidget
  switchHold never nestedEvent

loadingText :: Text
loadingText = "-"