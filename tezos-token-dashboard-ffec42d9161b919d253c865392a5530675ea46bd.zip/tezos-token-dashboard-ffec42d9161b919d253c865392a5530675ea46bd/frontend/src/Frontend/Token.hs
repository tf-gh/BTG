{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE MultiWayIf #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecursiveDo #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeApplications #-}

module Frontend.Token where

import Control.Lens hiding ((:<))
import Control.Monad.Reader
import Control.Arrow
import Data.Bool
import Data.Either.Combinators
import Data.Functor
import qualified Data.List as List
import Data.List.NonEmpty (NonEmpty (..))
import qualified Data.Map.Monoidal as MMap
import Data.Maybe (fromMaybe)
import Data.Semigroup hiding (option)
import Data.Traversable (for)
import qualified Data.Text as T
import qualified Data.Text.Encoding as T
import Data.These
import Data.Time
import Database.Id.Class
import Formatting (sformat, fixed, commas)
import Formatting.Buildable
import Obelisk.Route.Frontend
import Reflex.Dom
import qualified Reflex.Dom.SemanticUI as SemUi
import Rhyolite.Api
import Rhyolite.App
import Rhyolite.Frontend.Modal.Class
import Text.Read (readMaybe)

import Common.App
import Common.Route
import Common.Schema
import Frontend.App
import Frontend.OperationText
import Frontend.Token.Signing
import Frontend.Token.Whitelist
import Frontend.Watch
import Frontend.Widgets
import Tezos.Common.Base58Check
import Tezos.Wrapped.Schema
import Tezos.Token.Schema
import Tezos.Common.Json
import Tezos.V005.Contract

instance Buildable TezosWord64 where
  build = build . unTezosWord64

instance Read TezosWord64 where
  readsPrec = ((fmap . first) TezosWord64 . ) . readsPrec

tokenPage :: forall t m. (AppWidget t m, SetRoute t (R FrontendRoute) (ModalM m)) => Maybe TokenInfo -> m ()
tokenPage maybeTokenInfo = divClass "token-operations-container" $ elClass "div" "token" $ do
  maybeSignedInUser <- asks _frontendConfig_signedInUser
  case maybeTokenInfo of
    Nothing -> do
      {- NOTE: This header should not be visible once we support multiple tokens. -}
      SemUi.header (def & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $ do
        text tokenName
        SemUi.label def $ text tokenTickerSymbol
      case maybeSignedInUser of
        Just signedInUser | checkUserPermissions AppAction_SetupToken (_signedInUser_userInfo signedInUser) -> do
          _ <- workflow $ setupTokenWorkflow $ _signedInUser_authToken signedInUser
          pure ()
        _ ->
          elClass "div" "ui shape error-message" $ SemUi.header def $ text "The token has not been setup yet."
      pure ()
    Just tokenInfo ->
      case maybeSignedInUser of
        Nothing -> tokenInfoDashboardW tokenInfo Nothing
        Just signedInUser -> do
          let authToken = _signedInUser_authToken signedInUser
          let contractId = tokenInfo ^. tokenInfo_contractAddress
          let mintCapReq = ApiRequest_Private authToken (PrivateRequest_GetMintCap contractId)
          pb <- getPostBuild
          mintCapRes :: Event t (Either BTGError TezosWord64) <- requestingIdentity $ mintCapReq <$ pb
          dMintCap <- holdDyn Nothing $ either (const Nothing) Just <$> mintCapRes
          -- Token info
          tokenInfoDashboardW tokenInfo $ Just $ do
            divClass "mint" $ mdo
              SemUi.paragraph $ el "strong" $ text "Mint Cap"
              dMintCapDisplay <- holdDyn loadingText $ either (const "Error retrieving mint-cap") ((<> " RBZ") . (sformat commas)) <$> mintCapRes
              elClass "p" "mint-cap" $
                dynText dMintCapDisplay

          -- Rest of dashboard
          dynSigningInfo <- watchSigningInfo $ constDyn $ SigningInfoQuery_OfUser $ _userInfo_account $ _signedInUser_userInfo signedInUser
          maybeDynSigningInfo <- holdDyn Nothing $ Just <$> updated dynSigningInfo
          dyn_ $ ffor maybeDynSigningInfo $ \case
            Nothing ->
              blank
            Just (First maybeSigningInfo) -> mdo
              dyn_ $ ffor dynPendingOps $ \pendingOps ->
                bool
                  (pure ())
                  (operationsRow tokenInfo signedInUser maybeSigningInfo pendingOps dMintCap)
                  (checkUserPermissions AppAction_OperationRow $ _signedInUser_userInfo signedInUser)
              dynPendingOps <- pendingOperationsW signedInUser maybeSigningInfo
              dynTableSelection <- tableMenu
              dyn_ $ ffor dynTableSelection $ \case
                TableView_PastOperations ->
                  pastOperationsTable
                TableView_TokenHolders ->
                  tokenHoldersTable
              return ()

tokenInfoDashboardW :: forall t m. (AppWidget t m) => TokenInfo -> Maybe (m ()) -> m ()
tokenInfoDashboardW tokenInfo mintDisplayW = do
  SemUi.header (def & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $ do
    text $ tokenInfo ^. tokenInfo_name
    SemUi.label def $ text $ tokenInfo ^. tokenInfo_tickerSymbol
  divClass "token-info" $ do
    divClass "ui card" $ do
      divClass "addresses" $ do
        divClass "address" $ mdo
          SemUi.paragraph $ el "strong" $ text "Token Contract Address"
          copyToClipboardW $ toContractIdText $ tokenInfo ^. tokenInfo_contractAddress
        divClass "address" $ mdo
          SemUi.paragraph $ el "strong" $ text "Multi-signature Address"
          copyToClipboardW $ toContractIdText $ tokenInfo ^. tokenInfo_multiSignatureContractAddress
      divClass "token-stats" $ do
        divClass "amount" $ do
          pb <- getPostBuild
          SemUi.paragraph $ el "strong" $ text "Total Token Supply"
          let getTotalSupplyRequest = ApiRequest_Public (PublicRequest_GetTotalTokenSupply) <$ pb
          gotTotalSupplyResponse <- requestingIdentity getTotalSupplyRequest
          let (_failureE, successE) = fanEither gotTotalSupplyResponse
          elClass "p" "total-supply" $
            widgetHold_ (text loadingText) $ ffor successE $ \tokenSupply ->
              text $ sformat commas tokenSupply <> " RBZ"
        fromMaybe blank mintDisplayW

setupTokenWorkflow :: AppWidget t m => AppCredential BTG -> Workflow t m (Event t ())
setupTokenWorkflow authToken = Workflow $
  cardContainerW "Setup Token" $ mdo
    contractAddressInput <- textInputFieldW
      "Token Contract Address"
      (Just "e.g. KT1JFduD9v5BLfA28F2U1NZu13zo2rYz42is")
      Nothing
      [\val -> bool (Just "Enter a valid address starting with \"KT1\"") Nothing ("KT1" `T.isPrefixOf` val)]
      saveE
    widgetHold_ blank $ errorMessageW . (T.pack . show) <$> failureE
    el "br" $ blank
    el "br" $ blank
    loadingD <- holdDyn False $ leftmost
      [ True <$ createTokenRequestE
      , False <$ failureE
      ]
    saveE <- SemUi.button (def
      & SemUi.buttonConfig_type .~ SemUi.SubmitButton
      & SemUi.buttonConfig_color SemUi.|~ Just (SemUi.Green)
      & SemUi.buttonConfig_fluid SemUi.|~ True
      & SemUi.buttonConfig_loading .~ SemUi.Dyn loadingD) $ text "Save"
    let createTokenRequestE = (\contractAddress ->
          ApiRequest_Private authToken $ PrivateRequest_CreateTokenInfo tokenName tokenTickerSymbol contractAddress) <$> contractAddressInput
    createTokenResponseE <- requestingIdentity createTokenRequestE
    let (failureE, successE) = fanEither createTokenResponseE
    pure (() <$ successE, never)

operationsRow
  :: (AppWidget t m, SetRoute t (R FrontendRoute) (ModalM m))
  => TokenInfo -> SignedInUser -> Maybe SigningInfo -> MMap.MonoidalMap (Id PendingOperation) PendingOperation -> Dynamic t (Maybe TezosWord64) -> m ()
operationsRow tokenInfo signedInUser maybeSigningInfo pendingOpsMap dMintCap =
  elClass "div" "operations" $ do

    let tokenOperationWithStatus = fmap (\pendingOp -> ((viewTokenOperation $ _wrappedCall_payload $ _pendingOperation_operation pendingOp), _pendingOperation_status pendingOp)) $ MMap.elems pendingOpsMap
        existingPauseOperation = any (\(maybeTkOp, pOpStatus) -> (maybeTkOp == (Just $ SetPause True)) && (pOpStatus /= PendingOperationStatus_Sent && pOpStatus /= PendingOperationStatus_OperationFailed)) tokenOperationWithStatus
        existingResumeOperation = any (\(maybeTkOp, pOpStatus) -> (maybeTkOp == (Just $ SetPause False)) && (pOpStatus /= PendingOperationStatus_Sent && pOpStatus /= PendingOperationStatus_OperationFailed)) tokenOperationWithStatus
        tokenContract = _tokenInfo_contractAddress tokenInfo
    pauseE <- pauseButton (_signedInUser_authToken signedInUser) tokenContract $ existingPauseOperation || existingResumeOperation
    delayedPauseE <- delay 0.01 pauseE
    pausedD <- holdDyn Nothing $ Just <$> pauseE

    dyn_ $ ffor pausedD $ \case
      -- RESUME
      Just True -> tellModal $ delayedPauseE $> (\closeE -> do
        workflowDyn <- workflow $ signingWorkflow maybeSigningInfo $ \signingInfo ->
          createOperationWorkflow tokenInfo signingInfo resumeOperationText $ \submitE ->
            return $ SetPause False <$ submitE
        return $ leftmost [closeE, switchDyn workflowDyn])

      -- PAUSE
      Just False -> tellModal $ delayedPauseE $> (\closeE -> do
        workflowDyn <- workflow $ signingWorkflow maybeSigningInfo $ \signingInfo ->
          createOperationWorkflow tokenInfo signingInfo pauseOperationText $ \submitE -> do
            return $ SetPause True <$ submitE
        return $ leftmost [closeE, switchDyn workflowDyn])

      Nothing ->
        return ()

    -- WHITELIST
    whitelistWorkflows tokenInfo signedInUser maybeSigningInfo

    -- MINT
    mintE <- operationButton "money bill alternate" "Mint"
    tellModal $ mintE $> (\closeE -> do
      workflowDyn <- workflow $ signingWorkflow maybeSigningInfo $ \signingInfo ->
        createOperationWorkflow tokenInfo signingInfo mintOperationText $ \submitE -> do
          (amountE, destinationE) <- elClass "div" "ui mint-input" $ do
            amountE <- mintAmountInputFieldW submitE
            destinationInput <- elClass "div" "mint-destination-field" $
              textInputFieldW "Destination Address " (Just "e.g. tz1xuENLmiQQZTWdVKWmiNZCybekXA28i") Nothing
                [\input -> case rightToMaybe $ tryReadContractId $ T.encodeUtf8 input of
                    Just _ -> Nothing
                    Nothing -> Just "The Destination Address is not a valid address"
                ] submitE
            let maybeDestinationE = rightToMaybe . tryReadContractId . T.encodeUtf8 <$> destinationInput
            return (amountE, fmapMaybe id maybeDestinationE)
          whitelistedD <- whitelistCheckW destinationE
          return $ gate (current whitelistedD) $ alignEventWithMaybe (\case
            These amount destination -> Just (Mint amount destination)
            _ -> Nothing
            ) amountE destinationE

      return $ leftmost [closeE, switchDyn workflowDyn])

    -- TRANSFER
    transferE <- operationButtonFA "fas fa-comments-dollar" "Transfer"
    tellModal $ transferE $> (\closeE -> do
      workflowDyn <- workflow $ signingWorkflow maybeSigningInfo $ \signingInfo ->
        createOperationWorkflow tokenInfo signingInfo transferOperationText $ \submitE -> do
          (amountE, destinationE) <- elClass "div" "ui mint-input" $ do
            amountE <- amountInputFieldW submitE
            destinationInput <- elClass "div" "mint-destination-field" $
              textInputFieldW "Destination Address " (Just "e.g. tz1xuENLmiQQZTWdVKWmiNZCybekXA28i") Nothing
                [\input -> case rightToMaybe $ tryReadContractId $ T.encodeUtf8 input of
                    Just _ -> Nothing
                    Nothing -> Just "The Destination Address is not a valid address"
                ] submitE
            let maybeDestinationE = rightToMaybe . tryReadContractId . T.encodeUtf8 <$> destinationInput
            return (amountE, fmapMaybe id maybeDestinationE)
          let source = _tokenInfo_multiSignatureContractAddress tokenInfo
          whitelistedD <- whitelistCheckW destinationE
          return $ gate (current whitelistedD) $ alignEventWithMaybe (\case
            These amount destination -> Just (Transfer amount source destination)
            _ -> Nothing
            ) amountE destinationE

      return $ leftmost [closeE, switchDyn workflowDyn])

    -- BURN
    burnE <- operationButton "fire" "Burn"
    tellModal $ burnE $> (\closeE -> do
      workflowDyn <- workflow $ signingWorkflow maybeSigningInfo $ \signingInfo -> do
        createOperationWorkflow tokenInfo signingInfo burnOperationText $ \submitE -> do
          (amountE, destinationE) <- elClass "div" "ui mint-input" $ do
            amountE <- amountInputFieldW submitE
            destinationInput <- elClass "div" "mint-destination-field" $
              textInputFieldW "From Address " (Just "e.g. tz1xuENLmiQQZTWdVKWmiNZCybekXA28i") Nothing
                [\input -> case rightToMaybe $ tryReadContractId $ T.encodeUtf8 input of
                    Just _ -> Nothing
                    Nothing -> Just "The From Address is not a valid address"
                ] submitE
            let maybeDestinationE = rightToMaybe . tryReadContractId . T.encodeUtf8 <$> destinationInput
            return (amountE, fmapMaybe id maybeDestinationE)
          return $ alignEventWithMaybe (\case
            These amount destination -> Just (Burn amount destination)
            _ -> Nothing
            ) amountE destinationE

      return $ leftmost [closeE, switchDyn workflowDyn])

    -- DISBURSE
    disburseE <- operationButtonFA "fas fa-hand-holding-usd" "Disburse"
    tellModal $ disburseE $> (\closeE -> do
      workflowDyn <- workflow $ signingWorkflow maybeSigningInfo $ \signingInfo ->
        createChunkedOperationWorkflow signingInfo disburseOperationText $ do
          tokenHoldersD <- watchTokenHolders $ constDyn TokenHoldersQuery_All
          let maybeChunkedOperationD = buildChunkedOperation tokenInfo Disburse . MMap.keys <$> tokenHoldersD
          return $ fmapMaybe id (updated maybeChunkedOperationD)
      return $ leftmost [closeE, switchDyn workflowDyn])

  where
    mintAmountInputFieldW submitE =
      elClass "div" "operation-amount-field" $ do
        amountInput <- textInputFieldW' "Amount" (Just "e.g. 100") Nothing
          [ attachWith mintCapValidator (current dMintCap)
          , fmap amountFieldValidator
          ] submitE
        return $ fmapMaybe readMaybe $ T.unpack <$> amountInput

    mintCapValidator mintCap submitVal =
      case mintCap of
        Nothing -> Nothing
        Just mc -> case readMaybe (T.unpack submitVal) of
          Nothing -> Nothing
          Just (result :: TezosWord64) -> if result > mc then Just "Cannot mint more than the minting cap" else Nothing

    amountFieldValidator input = let errorMessage = "Only integer values greater than 0 are valid" in
      case readMaybe (T.unpack input) of
        Just (result :: Int) -> if result > 0 then Nothing else Just errorMessage
        Nothing -> Just errorMessage

    amountInputFieldW submitE =
      elClass "div" "operation-amount-field" $ do
        amountInput <- textInputFieldW "Amount" (Just "e.g. 100") Nothing
          [ amountFieldValidator ] submitE
        return $ fmapMaybe readMaybe $ T.unpack <$> amountInput

    whitelistCheckW
      :: AppModalWidget t m'
      => Event t ContractId -> m' (Dynamic t Bool)
    whitelistCheckW destinationE = mdo
      let authToken = _signedInUser_authToken signedInUser
      let checkWhitelistRequest = ApiRequest_Private authToken . PrivateRequest_CheckWhitelist <$> destinationE
      checkWhitelistResponse <- requestingIdentity checkWhitelistRequest
      let (failureE, successE) = fanEither checkWhitelistResponse
      widgetHold_ blank $ errorMessageW . T.pack . show <$> failureE
      widgetHold (return False) $ ffor successE $ \checkWhitelistResult ->
        divClass "ui shape modal-message" $
          case checkWhitelistResult of
            WhitelistCheck False Nothing -> do
              elClass "p" "modal-message-text" $ text "This address is not on the whitelist."
              return False

            WhitelistCheck True Nothing -> do
              elClass "p" "modal-message-text" $ text "This address is on the whitelist."
              return True

            WhitelistCheck False (Just _) -> do
              elClass "p" "modal-message-text" $ text "This address is not on the whitelist.\nThere is a pending operation to whitelist this address."
              return False

            WhitelistCheck True (Just _) -> do
              elClass "p" "modal-message-text" $ text "This address is on the whitelist.\nThere is a pending operation to remove this address from the whitelist."
              return False


pauseButton
  :: AppWidget t m
  => AppCredential BTG
  -> ContractId
  -> Bool
  -> m (Event t Bool)
pauseButton authToken tokenContract existPendingPauseOperation = mdo
  let isPausedReq = ApiRequest_Private authToken (PrivateRequest_GetPaused tokenContract)
  pb <- getPostBuild
  isPausedE <- requestingIdentity $ isPausedReq <$ pb
  isPausedD <- holdDyn Nothing $ rightToMaybe <$> isPausedE

  pauseE <- switchHold never <=< dyn $ ffor isPausedD $ \case
    Nothing ->
      mkLoader
    Just False ->
      mkButton "Pause" "pause"
    Just True ->
      mkButton "Resume" "play"

  return $
    if not existPendingPauseOperation
      then fmapMaybe id $ tag (current isPausedD) pauseE
      else never

  where
    disablePauseBtn False = "pause-contract"
    disablePauseBtn True = "pause-contract-disabled"

    mkButton opName iconName = mdo
      (p, _) <- tooltipW ("A " <> opName <> " operation is already pending") (constDyn existPendingPauseOperation) $ elClass' "div" (disablePauseBtn existPendingPauseOperation) $ do
        divClass "pause-button-container" $ SemUi.icon iconName def
        divClass "pause-button-caption" $ text $ opName <> " Contract"
      return $ domEvent Click p

    mkLoader = divClass "pause-contract" $ do
      elAttr "div" ("class" =: "ui active small centered inline loader" <> "style" =: "margin-top:6px") blank
      return never

pendingOperationsW :: (AppWidget t m, SetRoute t (R FrontendRoute) (ModalM m)) => SignedInUser -> Maybe SigningInfo -> m (Dynamic t (MMap.MonoidalMap (Id PendingOperation) PendingOperation))
pendingOperationsW signedInUser mSigningInfo = divClass "operations-container" $ do
  SemUi.header (def & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $ text "Pending Operations"
  el "p" $ text $ "Operations are submitted to the blockchain after " <> (T.pack $ show numOfRequiredSignatures) <> " signatures have been collected and all previous operations have been submitted."
  dynPendingOps <- watchPendingOperations $ constDyn PendingOperationsQuery_Pending
  elClass "table" "operations-table" $ do
    elClass "tr" "table-header" $ do
      el "th" $ text "Sequence"
      el "th" $ text "Type"
      el "th" $ text "Status"
      if (checkUserPermissions AppAction_PendingOperationAction $ _signedInUser_userInfo signedInUser)
        then el "th" $ text "Actions"
        else el "th" $ text ""
    dyn_ $ ffor dynPendingOps $ \mmapPendingOps -> do
      case MMap.toList mmapPendingOps of
        [] -> elClass "tr" "table-row" $ do
          el "td" $ blank
          elClass "td" "no-action-message" $ text "No actions are pending at this time"
          el "td" $ blank
          el "td" $ blank
        listOfPendingOps -> do
          let groupedPendingOps = List.groupBy (\(_, a) (_, b) ->
                let viewTokenOperation' = viewTokenOperation . _wrappedCall_payload . _pendingOperation_operation
                in case (viewTokenOperation' a, viewTokenOperation' b) of
                  (Just (Disburse _), Just (Disburse _)) -> True
                  _ -> False
                ) listOfPendingOps
          forM_ groupedPendingOps $ \groupedPendingOp -> elClass "tr" "table-row" $ do
            case groupedPendingOp of
              [(pendingOpId, pendingOp)] -> do
                let operationPayload = _wrappedCall_payload $ _pendingOperation_operation pendingOp
                    operationText = lookupOperationText operationPayload
                el "td" $ text $ T.pack $ show $ _wrappedCall_counter $ _pendingOperation_operation pendingOp
                el "td" $ text $ T.pack $ showOperationType operationPayload
                dmOperationSignatures <- watchOperationSignature $ constDyn $ OperationSignatureQuery_ByPendingOperation pendingOpId
                dyn_ $ ffor dmOperationSignatures $ \opSigMap -> do
                  let numOfOpSigs = MMap.size opSigMap
                  pendingOpStatusW (_pendingOperation_status pendingOp) numOfOpSigs
                  elClass "td" "actions-td" $ do
                    let hasEnoughSigs = numOfOpSigs == numOfRequiredSignatures
                    mToken <- asks _frontendConfig_signedInUser
                    case (mToken, mSigningInfo) of
                      (Nothing, _) -> blank
                      (Just authUser, maybeSigningInfo) -> do
                        let token = _signedInUser_authToken authUser
                        if (checkUserPermissions AppAction_PendingOperationAction $ _signedInUser_userInfo signedInUser)
                          then do
                            when (not hasEnoughSigs) $ mdo
                              -- SIGN
                              let userHasAlreadySigned = maybe False (\signingInfo -> List.elem (_signingInfo_publicKey signingInfo) $ _operationSignature_signingKey <$> MMap.elems opSigMap) maybeSigningInfo
                              signE <- tooltipW "You have already signed this operation." (constDyn userHasAlreadySigned)  $ do
                                greenButtonDisabledW "Sign" $ constDyn userHasAlreadySigned

                              tellModal $ signE $> (\closeE -> do
                                workflowDyn <- workflow $ connectLedgerWorkflow (_operationText_short operationText) Nothing (\_ ->
                                  signingWorkflow maybeSigningInfo (\signingInfo ->
                                    signOperationWorkflow signingInfo (Just $ _pendingOperation_operation pendingOp) (Just pendingOpId) operationText))

                                return $ leftmost [closeE, switchDyn workflowDyn])

                              -- CANCEL
                              cancelBtn <- divClass "cancel-operation-btn" $ buttonW "Cancel" SemUi.Black  (constDyn False)
                              tellModal $ cancelBtn $> (\closeE -> do
                                workflowDyn <- workflow $ cancelOperationPromptWorkflow token pendingOpId pendingOp "Cancel Operation" dynPendingOps
                                return $ leftmost [closeE, switchDyn workflowDyn])

                            when hasEnoughSigs $ do
                              -- DISMISS
                              dismissBtn <- divClass "dismiss-operation-btn" $ greenButtonW "Dismiss" (constDyn False)
                              let dismissOpRequest = ApiRequest_Private token (PrivateRequest_DismissOperations (pendingOpId :| [])) <$ dismissBtn
                              _ <- requestingIdentity dismissOpRequest
                              return ()
                          else return ()
                        return ()
                  return ()
              headPendingOp:tailPendingOp -> do
                let extractOperation = over _2 _pendingOperation_operation
                    chunkedOperation = fmap extractOperation (headPendingOp :| tailPendingOp)
                    operationPayload = _wrappedCall_payload . _pendingOperation_operation . snd $ headPendingOp
                    operationText = lookupOperationText operationPayload
                el "td" $ text $ T.pack $
                  show (_wrappedCall_counter (_pendingOperation_operation (snd headPendingOp))) <>
                  " - " <>
                  show (_wrappedCall_counter (_pendingOperation_operation (snd $ last tailPendingOp)))
                el "td" $ text $ T.pack $ showOperationType operationPayload
                dmOperationSignatures <- watchOperationSignature $ constDyn $ OperationSignatureQuery_ByPendingOperation (fst headPendingOp)
                dyn_ $ ffor dmOperationSignatures $ \opSigMap -> do
                  let numOfOpSigs = MMap.size opSigMap
                  pendingOpStatusW (_pendingOperation_status (snd headPendingOp)) numOfOpSigs
                  elClass "td" "actions-td" $ do
                    let hasEnoughSigs = numOfOpSigs == numOfRequiredSignatures
                    mToken <- asks _frontendConfig_signedInUser
                    case (mToken, mSigningInfo) of
                      (Nothing, _) -> blank
                      (Just authUser, maybeSigningInfo) -> do
                        let token = _signedInUser_authToken authUser
                        if (checkUserPermissions AppAction_PendingOperationAction $ _signedInUser_userInfo signedInUser)
                          then do
                            when (not hasEnoughSigs) $ mdo
                              -- SIGN
                              let userHasAlreadySigned = maybe False (\signingInfo -> List.elem (_signingInfo_publicKey signingInfo) $ _operationSignature_signingKey <$> MMap.elems opSigMap) maybeSigningInfo
                              signE <- tooltipW "You have already signed this operation." (constDyn userHasAlreadySigned)  $ do
                                greenButtonDisabledW "Sign" $ constDyn userHasAlreadySigned

                              tellModal $ signE $> (\closeE -> do
                                workflowDyn <- workflow $ connectLedgerWorkflow (_operationText_short operationText) Nothing (\_ ->
                                  signingWorkflow maybeSigningInfo (\signingInfo ->
                                    signChunkedOperationWorkflow signingInfo chunkedOperation operationText))

                                return $ leftmost [closeE, switchDyn workflowDyn])

                              -- CANCEL
                              cancelBtn <- divClass "cancel-operation-btn" $ buttonW "Cancel" SemUi.Black  (constDyn False)
                              tellModal $ cancelBtn $> (\closeE -> do
                                workflowDyn <- workflow $ cancelOperationPromptWorkflow token (fst headPendingOp) (snd headPendingOp) "Cancel Operation" dynPendingOps
                                return $ leftmost [closeE, switchDyn workflowDyn])

                            when hasEnoughSigs $ do
                              -- DISMISS
                              dismissBtn <- divClass "dismiss-operation-btn" $ greenButtonW "Dismiss" (constDyn False)
                              let dismissOpRequest = ApiRequest_Private token (PrivateRequest_DismissOperations ((fst headPendingOp) :| fmap fst tailPendingOp)) <$ dismissBtn
                              _ <- requestingIdentity dismissOpRequest
                              return ()
                          else return ()
                        return ()
                  return ()
              [] ->
                blank
      return ()
    return ()
  return dynPendingOps

  where
    pendingOpStatusW pendingOpStatus numOfOpSigs =
      el "td" $ case pendingOpStatus of
        PendingOperationStatus_NeedsSignatures ->
          text $ (T.pack $ show numOfOpSigs) <> " of " <> (T.pack $ show numOfRequiredSignatures) <> " Signatures"
        PendingOperationStatus_Waiting ->
          text $ (T.pack $ show numOfOpSigs) <> " of " <> (T.pack $ show numOfRequiredSignatures) <> " Signatures. Waiting on earlier operations."
        PendingOperationStatus_PreparingToSend ->
          text "Preparing to send to blockchain ..."
        PendingOperationStatus_Sent -> do
          SemUi.icon "checkmark" def
          text "Operation sent to blockchain."
        PendingOperationStatus_OperationFailed -> do
          SemUi.icon "close" def
          text "Operation failed. Retry with a new operation."

data TableView
  = TableView_PastOperations
  | TableView_TokenHolders
  deriving (Eq)

instance Show TableView where
  show = \case
    TableView_PastOperations -> "Past Operations"
    TableView_TokenHolders -> "Token Holders"

tableMenu :: AppWidget t m => m (Dynamic t TableView)
tableMenu = divClass "operations-menu" $ mdo
  selectionD <- holdDyn TableView_PastOperations selectOptionE
  selectOptionE <- elClass "div" "ui secondary pointing menu" $ do
    selectPastOperations <- mkOption TableView_PastOperations selectionD
    selectTokenHolders <- mkOption TableView_TokenHolders selectionD
    return $ leftmost
      [ selectPastOperations
      , selectTokenHolders
      ]
  return selectionD
  where
    mkOption option selectionD = do
      (optionEl, _) <- elDynAttr' "a" ((\selection -> "class" =: ("item" <> if option == selection then " active" else "")) <$> selectionD)  $ text (T.pack (show option))
      return $ option <$ domEvent Click optionEl


pastOperationsTable :: AppWidget t m => m ()
pastOperationsTable = divClass "operations-container" $ mdo
  SemUi.header (def & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $ text "Past Operations"
  el "p" $ text $ "Browse past token operations."
  dynPastOps <- watchPastOperations $ constDyn PastOperationsQuery_Conseil
  currentTime <- liftIO getCurrentTime
  dyn_ $ ffor (fmap snd . MMap.toList <$> dynPastOps) $ \pastOpsList -> mdo
    (opFilterD, opPageD) <- divClass "past-operation-table-controls" $ mdo
      opFilterD <- holdDyn OperationFilter_All opFilterE
      opFilterE <- pastOperationsFilterW opFilterD
      opPageD <- holdDyn 1 $ leftmost [ opPageE, 1 <$ opFilterE ]
      opPageE <- paginationW opPageD filteredOpsCountD
      return (opFilterD, opPageD)
    filteredOpsCountD <- holdDyn (length pastOpsList) filteredOpsCountE
    filteredOpsCountE <- elClass "table" "operations-table" $ do
      elClass "tr" "table-header" $ do
        el "th" $ text "Time"
        el "th" $ text "Type"
        el "th" $ text "Hash"
      dyn $ ffor (zipDyn opFilterD opPageD) $ \(opFilter, opPage) -> do
        let filteredOps = filterOps opFilter pastOpsList
        case extractPage opPage $ sortOps filteredOps of
          [] -> elClass "tr" "table-row" $ do
            el "td" $ blank
            elClass "td" "no-action-message" $ text "There are no past operations."
            el "td" $ blank
          pastOps -> forM_ pastOps $ \pastOp -> elClass "tr" "table-row" $ do
            el "td" $ text $ T.pack $ showOperationTime currentTime $ _pastOperation_timestamp pastOp
            el "td" $ text $ T.pack $ showOperationType $ _pastOperation_parameters pastOp
            el "td" $ copyToClipboardW $ toBase58Text $ _pastOperation_hash pastOp
        return $ length filteredOps
    return ()

  where
    sortOps =
      List.sortBy (\a b -> compare (_pastOperation_timestamp b) (_pastOperation_timestamp a))
    filterOps opFilter ops =
      filter (\pastOp ->
        opFilter == OperationFilter_All ||
          case _pastOperation_parameters pastOp of
            WrappedPayload_Call _ tokenOp _ ->
              opFilter == case tokenOp of
                SetPause _ ->
                  OperationFilter_ResumePause
                Transfer _ _ _ ->
                  OperationFilter_Transfers
                AddToWhitelist _ ->
                  OperationFilter_Whitelist
                AddToWhitelistBatch _ ->
                  OperationFilter_Whitelist
                RemoveFromWhitelist _ ->
                  OperationFilter_Whitelist
                RemoveFromWhitelistBatch _ ->
                  OperationFilter_Whitelist
                Mint _ _ ->
                  OperationFilter_MintBurn
                Burn _ _ ->
                  OperationFilter_MintBurn
                Disburse _ ->
                  OperationFilter_Dividends
            WrappedPayload_Reconfig _ _ ->
              False
      ) ops

tokenHoldersTable :: AppWidget t m => m ()
tokenHoldersTable =
  divClass "operations-container" $ do
    SemUi.header (def & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $ text "Holders"
    el "p" $ text $ "Browse all addresses that hold RBZ."
    dynTokenHolders <- watchTokenHolders $ constDyn $ TokenHoldersQuery_All
    dyn_ $ ffor dynTokenHolders $ \tokenHolders -> do
      let totalSupply = sum $ fmap _tokenHolderInfo_balance tokenHolders
      (searchTextD, pageD) <- divClass "token-holders-table-controls" $ mdo
        searchTextD <- searchInputFieldW "" (Just "Address Search") Nothing
        selectPageE <- paginationW pageD $ constDyn (MMap.size tokenHolders)
        pageD <- holdDyn 1 selectPageE
        return (searchTextD, pageD)
      elClass "table" "operations-table" $ do
        elClass "tr" "table-header" $ do
          elClass "th" "rank-column" $ text "Rank"
          el "th" $ text "Address"
          elClass "th" "numeric-column" $ text "Balance"
          elClass "th" "numeric-column" $ text "Percentage"
        dyn_ $ ffor (zipDyn searchTextD pageD) $ \(searchText, page) ->
          for (zip [1 .. ] $ extractPage page $ sortHolders $ filterHolders searchText $ MMap.assocs tokenHolders) $ \(rank, (address, info)) ->
            elClass "tr" "table-row" $ do
              el "td" $ text $ T.pack $ show (rank :: Int)
              el "td" $ divClass "holder-address-info" $ do
                copyToClipboardW $ toContractIdText address
                when (not (_tokenHolderInfo_isWhitelisted info)) $
                  tooltipW "This address is not on the whitelist" (constDyn True) $
                    SemUi.label (def & SemUi.labelConfig_color SemUi.|~ Just SemUi.Orange) $ text "!"
              elClass "td" "numeric-column" $ text $ sformat commas (_tokenHolderInfo_balance info)
              elClass "td" "numeric-column" $ text $ showPercentage (_tokenHolderInfo_balance info) totalSupply
  where
    filterHolders searchText holders =
      List.filter (\(address, _) -> T.strip searchText `T.isPrefixOf` toContractIdText address) holders
    sortHolders holders =
      List.sortBy (\(_, a) (_, b) -> compare (_tokenHolderInfo_balance b) (_tokenHolderInfo_balance a)) holders
    showPercentage a b =
      let (percentage :: Double) = (fromIntegral a / fromIntegral b) * 100
      in (case percentage of
        0 -> "0"
        _ -> sformat (fixed 2) percentage) <> "%"

extractPage :: Int -> [a] -> [a]
extractPage pageNumber ops =
  drop ((pageNumber - 1) * pageLimit) $ take (pageNumber * pageLimit) ops


showOperationTime :: UTCTime -> UTCTime -> String
showOperationTime currentTime operationTime = if
  | currentDay == operationDay ->
    "Today, " <> formattedOperationTime
  | currentDay == operationDay + 1 ->
    "Yesterday, " <> formattedOperationTime
  | otherwise ->
    formatTime defaultTimeLocale "%e %B" operationTime <> ", " <> formattedOperationTime
  where
    currentDay = toModifiedJulianDay $ utctDay currentTime
    operationDay = toModifiedJulianDay $ utctDay operationTime
    formattedOperationTime = formatTime defaultTimeLocale "%R" operationTime

data OperationFilter
  = OperationFilter_All
  | OperationFilter_Transfers
  | OperationFilter_ResumePause
  | OperationFilter_Whitelist
  | OperationFilter_MintBurn
  | OperationFilter_Dividends
  deriving (Ord, Eq)

instance Show OperationFilter where
  show = \case
    OperationFilter_All -> "All"
    OperationFilter_Transfers -> "Transfers"
    OperationFilter_ResumePause -> "Resume/Pause"
    OperationFilter_Whitelist -> "Whitelist"
    OperationFilter_MintBurn -> "Mint/Burn"
    OperationFilter_Dividends -> "Dividends"

pastOperationsFilterW
  :: AppWidget t m => Dynamic t OperationFilter -> m (Event t OperationFilter)
pastOperationsFilterW currentOptionD = divClass "pagination-menu" $
  switchHold never <=< dyn $ ffor currentOptionD $ \currentOption ->
    SemUi.menu (def & SemUi.menuConfig_compact SemUi.|~ True) $ do
      filterAllE <- filterMenuItem OperationFilter_All currentOption
      filterTransfersE <- filterMenuItem OperationFilter_Transfers currentOption
      filterResumePauseE <- filterMenuItem OperationFilter_ResumePause currentOption
      filterWhitelistE <- filterMenuItem OperationFilter_Whitelist currentOption
      filterMintBurnE <- filterMenuItem OperationFilter_MintBurn currentOption
      return $ leftmost
        [ filterAllE
        , filterTransfersE
        , filterResumePauseE
        , filterWhitelistE
        , filterMintBurnE
        ]
  where
    filterMenuItem filterOption currentOption = do
      (optionEl, _) <- SemUi.menuItem' (def
        & (SemUi.menuItemConfig_elConfig . SemUi.classes) SemUi.|~ SemUi.Classes (if filterOption == currentOption then ["active"] else [])) $
        text $ T.pack $ show filterOption
      return $ filterOption <$ domEvent Click optionEl

paginationW
  :: AppWidget t m => Dynamic t Int -> Dynamic t Int -> m (Event t Int)
paginationW currentPageD opsCountD = divClass "pagination-menu" $
  switchHold never <=< dyn $ ffor (zipDyn currentPageD opsCountD) $ \(currentPage, opsCount) -> do
    let pageCount = if opsCount `mod` pageLimit == 0
          then opsCount `div` pageLimit
          else succ (opsCount `div` pageLimit)
    divClass "ui pagination-controls" $ do
      firstPageE <- paginationMenuItem "1" 1 (currentPage == 1)
      divClass "pagination-ellipsis" $ text "..."
      prevPageE <- paginationMenuItem "<" (currentPage - 1) (currentPage == 1)
      divClass "pagination-current" $ text $ T.pack $ show currentPage
      nextPageE <- paginationMenuItem ">" (currentPage + 1) (pageCount == 0 || currentPage == pageCount)
      divClass "pagination-ellipsis" $ text "..."
      lastPageE <- paginationMenuItem (show $ if pageCount == 0 then 1 else pageCount) (if pageCount == 0 then 1 else pageCount) (pageCount == 0 || currentPage == pageCount)
      return $ leftmost
        [ firstPageE
        , prevPageE
        , nextPageE
        , lastPageE
        ]
  where
    paginationMenuItem displayValue targetPageNumber isDisabled =  do
      (optionEl, _) <- SemUi.button' (def
        & SemUi.buttonConfig_compact SemUi.|~ True
        & SemUi.buttonConfig_disabled SemUi.|~ isDisabled) $
        text $ T.pack displayValue
      return $ targetPageNumber <$ domEvent Click optionEl

pageLimit :: Int
pageLimit = 10
