{-# LANGUAGE DataKinds #-}
{-# LANGUAGE ExplicitForAll #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecursiveDo #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TupleSections #-}
{-# LANGUAGE TypeApplications #-}

module Frontend.Users where

import Control.Applicative
import Control.Lens
import Control.Monad (forM)
import Control.Monad.Reader
import Data.Bool
import Data.ByteString (ByteString)
import Data.Char
import Data.Foldable (for_)
import Data.Functor (($>))
import qualified Data.List as List
import Data.List.NonEmpty (NonEmpty (..))
import qualified Data.Map.Monoidal as MMap
import Data.Maybe
import Data.Semigroup (getFirst)
import Data.Text (Text)
import qualified Data.Text as T
import Data.Word
import Database.Id.Class
import Reflex.Dom
import qualified Reflex.Dom.SemanticUI as SemUi
import Rhyolite.Api
import Rhyolite.App
import Rhyolite.Frontend.Modal.Class
import Rhyolite.Schema
import Text.Read
import Tezos.Common.Base58Check
import Tezos.Common.ShortByteString
import Tezos.V005.Ledger
import Tezos.V005.PublicKey
import Tezos.V005.PublicKeyHash

import Common.App
import Common.Schema
import Frontend.App
import Frontend.Ledger
import Frontend.Token.Signing
import Frontend.Watch
import Frontend.Widgets

userManagementPage
  :: forall t m. AppWidget t m
  => Maybe TokenInfo -> m ()
userManagementPage maybeTokenInfo = do
  maybeSignedInUser <- asks $ _frontendConfig_signedInUser
  case maybeSignedInUser of
    Just signedInUser ->
      divClass "user-management" $ do
        inviteUserE <- divClass "user-management-bar" $ do
          SemUi.header def $ text "Manage Users"
          if checkUserPermissions AppAction_InviteUser $ _signedInUser_userInfo signedInUser
             then divClass "invite-user-button-container" $ submitButtonW False "Invite User" $ constDyn False
             else pure never
        _ <- userList maybeTokenInfo signedInUser
        tellModal $ inviteUserE $> (\closeE -> do
          workflowDyn <- workflow $ inviteUserWorkflow $ _signedInUser_authToken signedInUser
          pure $  leftmost [ closeE, switchDyn workflowDyn ])
        return ()
    Nothing ->
      blank

userList
  :: forall t m. AppWidget t m
  => Maybe TokenInfo -> SignedInUser -> m (Event t ())
userList maybeTokenInfo signedInUser = do
  dynUsersMap <- watchAllBtgUsers $ constDyn UserInfoQuery_AllUsers
  dynAuthorizedKeys <- watchAuthorizedKeys $ constDyn AuthorizedKeysQuery_ActiveKeys
  let dynUsers = MMap.toList <$> dynUsersMap
      currentUserInfo = _signedInUser_userInfo signedInUser
  changeViewEE <- SemUi.table def $ do
    el "tr" $ do
      el "th" $ text "Name"
      el "th" $ text "Email"
      el "th" $ text "Role"
      el "th" $ text "2FA"
      el "th" $ text "Public Key Hash"
      el "th" $ text ""
    dyn $ ffor (zipDyn dynUsers dynAuthorizedKeys) $ \(users, authorizedKeys) -> forM users $ \(uid, user') -> case user' of
      Nothing -> el "tr" (pure never)
      Just user -> el "tr" $ do
        let notTargetingSelf = _userInfo_account currentUserInfo /= _userInfoView_account user
        el "td" $ text $ _userInfoView_name user
        el "td" $ text $ _userInfoView_email user
        el "td" $ do
          userRoleE <- do
            if (notTargetingSelf && checkUserPermissions AppAction_ChangeUserType currentUserInfo)
              then do
                (changeRoleEl, _) <- elAttr' "a" ("style" =: "cursor: pointer") $ text $ showPretty $ _userInfoView_role user
                return $ domEvent Click changeRoleEl
              else do
                el "p" $ text $ showPretty $ _userInfoView_role user
                return never
          _ <- tellModal $ userRoleE $> (\closeE -> do
            workflowDyn <- workflow $ changeUserRoleWorkflow (_signedInUser_authToken signedInUser) (uid, user)
            pure $ leftmost [ closeE, switchDyn workflowDyn ])
          return ()
        el "td" $
          if _userInfoView_hasTwoFactorAuth user
            then text "Yes"
            else
              if notTargetingSelf
                then
                  text "No"
                else do
                  (update2FAEl, _) <- elAttr' "a" ("style" =: "cursor: pointer") $ text $ "Setup"
                  _ <- tellModal $ domEvent Click update2FAEl $> (\closeE -> do
                    workflowDyn <- workflow $ update2FAWorkflow (_signedInUser_authToken signedInUser) (uid, user)
                    pure $ leftmost [ closeE, switchDyn workflowDyn ])
                  return ()
        el "td" $ publicKeyHashW (uid, user) (catMaybes $ join . fmap _userInfoView_publicKeyHash . snd <$> users) notTargetingSelf (maybe [] _authorizedKeys_publicKeys $ getFirst authorizedKeys)
        elClass "td" "remove-user-btn" $ do
          removeE <-
            if (notTargetingSelf && checkUserPermissions AppAction_DeleteUser currentUserInfo)
              then do
                (rmEv, _) <- SemUi.button' def (text "Remove")
                return $ domEvent Click rmEv
              else return never
          _ <- tellModal $ removeE $> (\closeE -> do
            workflowDyn <- workflow $ removeUserWorkflow (_signedInUser_authToken signedInUser) (uid, user)
            pure $ leftmost [ closeE, switchDyn workflowDyn ])
          return ()
        return never
  switchHold never $ leftmost <$> changeViewEE

  where
    publicKeyHashW (uid, user) adminKeys notTargetingSelf authorizedKeys =
      if _userInfoView_role user == Role_Admin
        then do
          if maybe True (\userKey -> List.any (== userKey) (snd <$> authorizedKeys)) (_userInfoView_publicKeyHash user)
            then blank
            else elClass "div" "warning" $
              tooltipW "This address is not listed on the Multi-signature Contract and cannot be used to sign operations" (constDyn True) $
                SemUi.label (def & SemUi.labelConfig_color SemUi.|~ Just SemUi.Red) $ text "!"
          if notTargetingSelf
            then
              text $ fromMaybe "" $ toPublicKeyHashText <$> _userInfoView_publicKeyHash user
            else do
              (updatePKHEl, _) <- elAttr' "a" ("style" =: "cursor: pointer") $ text $ maybe "Set your PKH" toPublicKeyHashText (_userInfoView_publicKeyHash user)
              let updatePKHE = domEvent Click updatePKHEl
              _ <- tellModal $ updatePKHE $> (\closeE -> do
                workflowDyn <- workflow $ connectLedgerWorkflow "Edit Public Key Hash" Nothing $ \_ ->
                  updateSigningKeyWorkflow maybeTokenInfo uid Nothing (_userInfoView_publicKeyHash user) adminKeys authorizedKeys
                pure $ leftmost [ closeE, switchDyn workflowDyn ])
              return ()
      else
        return ()


inviteUserWorkflow :: AppModalWidget t m => AppCredential BTG -> Workflow t m (Event t ())
inviteUserWorkflow token = Workflow $ do
  modalBoxFormW "Invite a User" $ mdo
    SemUi.divider def
    elAttr "p" ("style" =: "text-align:left") $ text "This will send an invitation to this email address, allowing them to create an account as an Auditor. After their account is created you may grant them further permissions."
    emailInput <- textInputFieldW "Email Address" (Just "Enter the email address of the person you'd like to invite.") Nothing [] sendInviteE
    SemUi.divider def
    (cancelE, sendInviteE) <- elClass "div" "controls" $ do
      cancelE' <- modalCancelButtonW "Cancel"
      sendInviteAttemptE <- modalSubmitButtonW "Send Invite" (constDyn False)
      pure (cancelE', sendInviteAttemptE)
    pure (cancelE, (\email -> confirmEmailWorkflow token email) <$> emailInput)

confirmEmailWorkflow :: AppModalWidget t m => AppCredential BTG -> Text -> Workflow t m (Event t ())
confirmEmailWorkflow token email = Workflow $ do
  modalBoxFormW "Invite a User" $ mdo
    SemUi.divider def
    SemUi.header (def
      & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned
      & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $ text "Confirm Email Address"
    SemUi.paragraph $ text "Please confirm the email address is correct before sending."
    SemUi.header (def & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text email
    widgetHold_ blank $ ffor failureE $ \e -> SemUi.message def { SemUi._messageConfig_color = pure (Just SemUi.Red) } $ text $ T.pack $ show e
    SemUi.divider def
    (backE, sendInviteE) <- elClass "div" "controls" $ do
      backE' <- modalBackButtonW "Back"
      loadingD <- holdDyn False $ leftmost [ True <$ sendInviteRequestE, False <$ sendInviteResponseE ]
      sendInviteE' <- modalSubmitButtonW "Send Invite" loadingD
      pure (backE', sendInviteE')

    let sendInviteRequestE = ApiRequest_Private token (PrivateRequest_InviteUser $ EmailAddress email) <$ sendInviteE
    sendInviteResponseE <- requestingIdentity sendInviteRequestE
    let (failureE, successE) = fanEither sendInviteResponseE

    pure (never, leftmost
      [ inviteUserWorkflow token <$ backE
      , invitationSentWorkflow token email <$ successE
      ])

invitationSentWorkflow :: AppModalWidget t m => AppCredential BTG -> Text -> Workflow t m (Event t ())
invitationSentWorkflow token email = Workflow $ do
  modalBoxFormW "Invite a User" $ do
    SemUi.divider def
    SemUi.header (def
      & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned
      & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $ text "Invitation sent!"
    SemUi.paragraph $ text "An invitation has been sent to"
    SemUi.header (def & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text email
    SemUi.divider def
    (backE, doneE) <- elClass "div" "controls" $ do
      backE <- modalBackButtonW "Send Another"
      doneE <- modalSubmitButtonW "Done" (constDyn False)
      pure (backE, doneE)

    pure (doneE, inviteUserWorkflow token <$ backE)

changeUserRoleWorkflow :: AppModalWidget t m => AppCredential BTG -> (Id UserInfo, UserInfoView) -> Workflow t m (Event t ())
changeUserRoleWorkflow token (uid, user) = Workflow $ modalBoxFormW "Change User Role" $ divClass "change-user-role-body" $ mdo
  elAttr "div" ("style" =: "text-align: center") $
    text "Select a role to assign to user"
  SemUi.header (def & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text $ _userInfoView_name user

  newRoleD <- SemUi.menu def $ mdo
    let activated dest = ffor currentSelectionD $ bool "" "active" . (== dest)
    (toAuditorEl, _) <- SemUi.menuItem' (def & SemUi.classes <>~ SemUi.Dyn (activated Role_Auditor)) $ do
      SemUi.header def $ text "Auditor"
      SemUi.paragraph $ text "View-only access to token data."
    (toAdminEl, _) <- SemUi.menuItem' (def & SemUi.classes <>~ SemUi.Dyn (activated Role_Admin)) $ do
      SemUi.header def $ text "Admin"
      SemUi.paragraph $ text "Full access to token data and user management."
    currentSelectionD <- holdDyn (_userInfoView_role user) $ leftmost
      [ Role_Auditor <$ domEvent Click toAuditorEl
      , Role_Admin <$ domEvent Click toAdminEl
      ]
    pure currentSelectionD

  (changeRoleE, cancelEv) <- divClass "change-pw-form-footer" $ do
    cancelEv' <- el "div" $ modalCancelButtonW "Cancel"
    changeRoleE' <- el "div" $ do
      loadingD <- holdDyn False $ leftmost [ True <$ changeRoleRequestE, False <$ changeRoleResponseE ]
      greenButtonW "Change Role" loadingD
    return (changeRoleE', cancelEv')

  let changeRoleRequestE = ApiRequest_Private token . (flip $ PrivateRequest_ChangeUserRole uid) Nothing <$> tag (current newRoleD) changeRoleE
  changeRoleResponseE <- requestingIdentity changeRoleRequestE
  let (failureE, successE) = fanEither changeRoleResponseE
      requiresTwoFactorAuthFailureE = ffilter (== BTGError_RequiresTwoFactorAuth) failureE
      otherErrE = ffilter (/= BTGError_RequiresTwoFactorAuth) failureE

  pure (cancelEv, leftmost
    [ userRoleUpdatedWorkflow user <$> tag (current newRoleD) (leftmost [Right <$> successE, Left <$> otherErrE])
    , twoFactorAuthenticationWorkflow newRoleD <$ requiresTwoFactorAuthFailureE
    ])
  where
    twoFactorAuthenticationWorkflow newRoleD = Workflow $
      modalBoxFormW "Change User Role" $ mdo
        SemUi.divider def
        SemUi.message def $ text "To change this user’s role enter the 6 digit 2 factor authentication code from your authorization app."
        oneTimePasswordInputE <- textInputFieldW "6-digit 2FA code" Nothing Nothing [] verifyE
        let checkOneTimePasswordRequestE = ApiRequest_Private token . (uncurry $ PrivateRequest_ChangeUserRole uid) <$> attach (current newRoleD) (Just <$> fmapMaybe validateOneTimePasswordInput oneTimePasswordInputE)
        checkOneTimePasswordResponseE <- requestingIdentity checkOneTimePasswordRequestE
        let (otpCheckFailureE, otpCheckSuccessE) = fanEither checkOneTimePasswordResponseE
        widgetHold_ blank $ errorMessageW . T.pack . show <$> otpCheckFailureE
        loadingD <- holdDyn False $ leftmost
          [ True <$ checkOneTimePasswordRequestE
          , False <$ checkOneTimePasswordResponseE
          ]
        SemUi.divider def
        (goBackE, verifyE) <- divClass "two-factor-auth-controls-change-roles" $ do
          goBackE' <- modalBackButtonW "Go Back"
          verifyE' <- greenButtonW "Verify" loadingD
          return (goBackE', verifyE')
        return (never, leftmost
          [ changeUserRoleWorkflow token (uid, user) <$ goBackE
          , userRoleUpdatedWorkflow user <$> tag (current newRoleD) otpCheckSuccessE
          ])

update2FAWorkflow :: AppModalWidget t m => AppCredential BTG -> (Id UserInfo, UserInfoView) -> Workflow t m (Event t ())
update2FAWorkflow token (_uid, _uiv) = Workflow $ modalBoxFormW "2 Factor Authentication Setup" $ divClass "update-2fa-body left aligned" $ mdo
  pb <- getPostBuild
  let getNew2FASecretE = (ApiRequest_Private token $ PrivateRequest_New2FASecret) <$ pb
  new2FASecretE <- requestingIdentity getNew2FASecretE
  let (_failureE, successE) = fanEither new2FASecretE
  new2FASecretD <- holdDyn Nothing $ Just <$> successE
  elClass "div" "ui left aligned modal-inform-message" $ do
    el "h2" $ text "How 2FA Works"
    text howItWorksCopy
  elClass "h3" "ui short header" $ text "Step 1"
  elClass "div" "ui left aligned modal-message" $ step1Copy
  elClass "h3" "ui short header" $ text "Step 2"
  elClass "div" "ui left aligned modal-message" $ do
    text step2Copy
    elClass "div" "two-factor-key" $ do
      text $ "Secret Key: "
      dynText $ maybe "" (T.intercalate " " . T.chunksOf 4 . secureMemToText . _twoFactorSecret_Secret) <$> new2FASecretD
      el "div" $ elDynAttr "img" (maybe mempty (("src" =:) . _twoFactorSecret_QR) <$> new2FASecretD) $ blank
  elClass "h3" "ui left aligned header" $ text "Step 3"
  otp :: Dynamic t (Maybe Word32) <- elClass "div" "ui left aligned modal-message" $ do
    text step3Copy
    el "div" $ mdo
      SemUi.label (def
        & SemUi.labelConfig_hidden .~ SemUi.Dyn hide6DigitWarningD
        & SemUi.labelConfig_pointing SemUi.|~ Just SemUi.BelowPointing
        & SemUi.labelConfig_color SemUi.|~ Just SemUi.Red
        & SemUi.labelConfig_basic SemUi.|~ True) $ text "6-digit 2FA code is required"
      input <- SemUi.textInput def
      let show6DigitWarningE = isJust <$> tag (current otp) set2FAE
      hide6DigitWarningD <- holdDyn True $ show6DigitWarningE
      return $ validateOneTimePasswordInput <$> _textInput_value input

  dyn_ $ fromMaybe blank <$> fmap (SemUi.message def
    { SemUi._messageConfig_color = pure (Just SemUi.Red) } . text . T.pack . show) <$> errorD
  let curSetD = zipDynWith (liftA2 PrivateRequest_Set2FASecret) (fmap _twoFactorSecret_MAC <$> new2FASecretD) otp
      set2FARequestE = fmap (ApiRequest_Private token) $ fmapMaybe id $ tag (current curSetD) set2FAE
  set2FAResponseE <- requestingIdentity $ set2FARequestE
  (set2FAE, cancelEv) <- divClass "update-2fa-footer" $ do
    cancelEv' <- el "div" $ modalCancelButtonW "Cancel"
    set2FAE' <- el "div" $ do
      loadingD <- holdDyn False $ leftmost [ True <$ set2FARequestE, False <$ set2FAResponseE ]
      greenButtonW "Activate 2 Factor Authentication" loadingD
    return (set2FAE', cancelEv')
  let (failureResponseE, successResponseE) = fanEither set2FAResponseE
  errorD <- holdDyn Nothing $ Just <$> failureResponseE
  return (cancelEv <> successResponseE, never)
  where
    howItWorksCopy = "For actions like signing in, changing or recovering your password, you’ll need to provide a 6-digit code generated in an authorization app in addition to the standard authentication."
    step1Copy = do
      text "If you don’t already have an authenticator app on your phone, like "
      elAttr "a" ("target" =: "_blank" <> "href" =: "https://authy.com/") $ text "Authy"
      text " or "
      elAttr "a" ("target" =: "_blank" <> "href" =: "https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2") $ text "Google Authenticator"
      text ", download and install one now."
    step2Copy = "Using the authenticator app, scan the QR code below or enter the secret key. Keep your secret key backed up somewhere safe so you can easily restore your 2FA codes if you ever lose your phone or data."
    step3Copy = "Enter the 6 digit 2 factor authentication code from your authorization app."

validateOneTimePasswordInput :: Text -> Maybe Word32
validateOneTimePasswordInput input = do
  guard $ T.length (T.filter isDigit input) == 6
  readMaybe $ T.unpack input

userRoleUpdatedWorkflow :: AppModalWidget t m => UserInfoView -> Role -> Workflow t m (Event t ())
userRoleUpdatedWorkflow user newRole = Workflow $ modalBoxFormW "Change User Role" $ do
    divClass "user-role-update-body" $ do
      el "h2" $ text "User Role Updated!"
      SemUi.header (def & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text $ _userInfoView_name user <> " is now an " <> showPretty newRole
    doneE <- divClass "change-pw-form-footer" $ greenButtonW "Done" (constDyn False)
    pure (doneE, never)

removeUserWorkflow :: AppModalWidget t m => AppCredential BTG -> (Id UserInfo, UserInfoView) -> Workflow t m (Event t ())
removeUserWorkflow token (uid, user) = Workflow $ modalBoxFormW "Delete User" $ divClass "change-user-role-body" $ mdo
  SemUi.header (def & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text $ _userInfoView_name user
  elAttr "div" ("style" =: "text-align: center; margin-bottom: 3em;") $
    text "Are you sure you want to delete this user?"

  (deleteUserE, cancelE) <- divClass "change-pw-form-footer" $ do
    loadingD <- holdDyn False $ leftmost [ True <$ removeUserRequestE, False <$ removeUserResponseE ]
    cancelEv' <- el "div" $ modalCancelButtonW "Cancel"
    deleteUserE' <- el "div" $ greenButtonW "Delete User" loadingD
    return (deleteUserE', cancelEv')

  let removeUserRequestE = (ApiRequest_Private token (PrivateRequest_DeleteAccount uid)) <$ deleteUserE
  removeUserResponseE <- requesting removeUserRequestE

  pure (cancelE, removeUserUpdatedWorkflow user <$ removeUserResponseE)

removeUserUpdatedWorkflow :: AppModalWidget t m => UserInfoView -> Workflow t m (Event t ())
removeUserUpdatedWorkflow user = Workflow $ modalBoxFormW "Delete User" $ do
  divClass "user-role-update-body" $ do
    el "h2" $ text "User deleted."
    SemUi.header (def & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text $ _userInfoView_name user
    elAttr "div" ("style" =: "text-align: center; margin-top:1em;") $
      text "Has been removed from the system."
  doneE <- divClass "change-pw-form-footer" $ el "div" $ greenButtonW "Done" (constDyn False)
  pure (doneE, never)

data AddressImportError
  = AlreadyInUseError
  | WrongDeviceError
  | LedgerError
  deriving Eq

updateSigningKeyWorkflow
  :: forall t m. AppModalWidget t m
  => Maybe TokenInfo -> Id UserInfo -> Maybe AddressImportError -> Maybe PublicKeyHash -> [PublicKeyHash] -> [(PublicKey, PublicKeyHash)] -> Workflow t m (Event t ())
updateSigningKeyWorkflow maybeTokenInfo uid maybeError maybeCurrentKey adminKeys authorizedKeys = Workflow $
  modalBoxFormW "Edit Public Key Hash" $ mdo
    SemUi.divider def
    ledgerStatusW Nothing True

    SemUi.header (def
      & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned
      & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $
      text "Enter your Signing Curve and Derivation Path."

    case maybeError of
      Just LedgerError -> do
        SemUi.message def { SemUi._messageConfig_color = pure (Just SemUi.Red) } $
          text "The Ledger device prompt was rejected or timed out. Please try again."
      Just AlreadyInUseError -> do
        SemUi.message def { SemUi._messageConfig_color = pure (Just SemUi.Red) } $ do
          SemUi.header (def & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text "PKH already in use."
          text "The selected signing curve and derivation path result in a PKH that is identical to your current PKH. Please choose a different curve or path if you wish to change your PKH."
      Just WrongDeviceError -> do
        SemUi.message def { SemUi._messageConfig_color = pure (Just SemUi.Red) } $ do
          SemUi.header (def & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned) $ text "You may be using the wrong Ledger device."
          text "The selected signing curve and derivation path result in a PKH that is already in use by another admin, which means you are using their Ledger device or a paired Ledger device. Please make sure you are using the correct Ledger device."
      Nothing ->
        blank

    addressInputD <- elClass "div" "ui address-input" $ do
      (signingCurveInput, _) <- inputFieldW "Signing Curve" importPKHE [] True $ do
        let options = showPrettySigningCurve <$> [ SigningCurve_Ed25519 ]
        selection <- dropdownMenu def (head options) never $ SemUi.TaggedStatic options
        pure (selection, ())
      signingCurveD <- holdDyn SigningCurve_Ed25519 $ readPretty <$> signingCurveInput

      derivationPathInput <- elClass "div" "input-field" $ do
        elClass "div" "field-name" $ elClass "span" "name" $ text "Derivation Path"
        SemUi.input (def & SemUi.inputConfig_labeled SemUi.|~ Just SemUi.LeftLabeled) $ do
          let pathPrefix = "44'/1729'/"
          elClass "div" "ui label" $ text pathPrefix
          input <- SemUi.textInput (def
            & SemUi.textInputConfig_value .~ SemUi.SetValue "0'/0'" Nothing)
          pure $ tag (mappend pathPrefix <$> current (_textInput_value input)) importPKHE

      derivationPathD <- holdDyn "44'/1729'/0'/0'" derivationPathInput
      pure $ zipDyn signingCurveD $ DerivationPath <$> derivationPathD

    el "p" $ text "This address must be imported. Your private keys will remain securely stored on the Ledger."

    SemUi.divider def
    (cancelE, importPKHE) <- elClass "div" "controls" $ do
      cancelE' <- modalCancelButtonW "Cancel"
      importPKHE' <- modalSubmitButtonW "Import PKH" $ constDyn False
      pure (cancelE', importPKHE')
    delayedImportPKHE <- delay 0.01 importPKHE

    pure (cancelE, importSigningKeyWorkflow <$> tag (current addressInputD) delayedImportPKHE)

    where
      importSigningKeyWorkflow :: (SigningCurve, DerivationPath) -> Workflow t m (Event t ())
      importSigningKeyWorkflow (signingCurve, derivationPath) = Workflow $
        modalBoxFormW "Edit Public Key Hash" $ mdo
          SemUi.divider def
          ledgerStatusW Nothing True

          elClass "div" "operation-description" $
            SemUi.segment def $ do
              el "p" $ el "strong" $ text "Operation Description:"
              el "p" $ text "Import PKH."

          widgetHold_ loadingW $ ffor (ffilter isNothing getAddressResultE) $ \_ ->
            SemUi.message def { SemUi._messageConfig_color = pure (Just SemUi.Red) } $
              text "The Ledger device prompt was rejected or timed out. Please try again."

          SemUi.header (def
            & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned
            & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $ text "Respond to the prompt on your Ledger device."
          el "p" $ text "Your Ledger device should show the following prompt:"

          pb <- getPostBuild
          getAddressResultE <- callJavascriptAsync $ getAddress signingCurve derivationPath <$ pb
          maybeAddressD <- holdDyn Nothing getAddressResultE
          let runBlake2bHashRequest = ApiRequest_Public . PublicRequest_RunBlake2bHash Blake2bHashSize_20 . _address_publicKey <$> fmapMaybe id (updated maybeAddressD)
          runBlake2bHashResponse <- requestingIdentity runBlake2bHashRequest
          let (hashFailureE, rawHashSuccessE) = fanEither runBlake2bHashResponse
          let publicKeyHashSuccessE = fmap (toPublicKeyHash SigningCurve_Ed25519) rawHashSuccessE

          elClass "div" "ledger-prompt" $
            SemUi.message (def & SemUi.messageConfig_compact SemUi.|~ True) $ do
              el "strong" $ text "Provide Public Key" >> el "br" blank
              el "strong" $ text "Public Key Hash" >> el "br" blank
              el "strong" $ text "(public key hash)"
          SemUi.divider def
          elClass "div" "controls" blank
          pure (never, leftmost
            [ updateSigningKeyWorkflow maybeTokenInfo uid (Just LedgerError)  maybeCurrentKey adminKeys authorizedKeys <$ leftmost
                [ () <$ ffilter isNothing getAddressResultE
                , () <$ hashFailureE
                ]
            , updateSigningKeyWorkflow maybeTokenInfo uid (Just AlreadyInUseError) maybeCurrentKey adminKeys authorizedKeys <$
                ffilter (== maybeCurrentKey) (Just <$> publicKeyHashSuccessE)
            , updateSigningKeyWorkflow maybeTokenInfo uid (Just WrongDeviceError) maybeCurrentKey adminKeys authorizedKeys <$
                ffilter (\pkh -> List.any (== pkh) adminKeys) publicKeyHashSuccessE
            , confirmPublicKeyWorkflow signingCurve derivationPath <$> attach (current maybeAddressD) rawHashSuccessE
            ])

      confirmPublicKeyWorkflow :: SigningCurve -> DerivationPath -> (Maybe Address, ByteString) -> Workflow t m (Event t ())
      confirmPublicKeyWorkflow _ _ (Nothing, _) = Workflow $ pure (never, never) -- TODO: figure out a better way to handle this case, ideally making it irrelevant
      confirmPublicKeyWorkflow signingCurve derivationPath (Just address, rawPublicKeyHash) = Workflow $
        modalBoxFormW "Edit Public Key Hash" $ mdo
          let publicKey = PublicKey_Ed25519 $ HashedValue $ toShort $ _address_publicKey address
          let publicKeyHash = toPublicKeyHash (_address_signingCurve address) rawPublicKeyHash
          SemUi.divider def
          ledgerStatusW Nothing True
          SemUi.header (def
            & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned
            & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $
            text "Confirm PKH"
          elClass "p" "modal-message-text" $ text "Please confirm that the imported PKH matches the PKH you intend to use for signing:"
          elClass "div" "public-key-hash" $
            SemUi.header (def
              & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned
              & SemUi.headerConfig_size SemUi.|?~ SemUi.H3) $ el "strong" $ text $ toPublicKeyHashText publicKeyHash

          let alreadyListed = List.any (\authorizedKey -> publicKeyHash == snd authorizedKey) authorizedKeys
          if alreadyListed
            then
              elClass "div" "ui center aligned modal-inform-message" $ do
                el "h3" $ text "This PKH is already on the multi-signature list."
                text "This PKH is on the mulit-signature list, but not associated with any admins. You may choose to set this as your PKH without needing to update the multi-signature list."
            else do
              elClass "div" "ui center aligned modal-warning-message" $ do
                el "h3" $ text "This PKH needs to be added to the multi-signature list."
                text "This PKH is not on the multi-signature list and will need to be added via a multi-signature operation in order for you to sign operations with it."
              elClass "p" "modal-message-text" $ text "The multi-signature list can only be updated as a whole. This operation will use the current PKHs of other admins, with your new PKH added and your previous PKH removed:"
              divClass "listed-addresses" $ do
                divClass "listed-address" $ do
                  el "div" $ text $ toPublicKeyHashText publicKeyHash
                  el "div" $ text "Your new address"
                case join $ (\currentKey -> List.find (== currentKey ) (snd <$> authorizedKeys)) <$> maybeCurrentKey of
                  Just removedKey -> divClass "listed-address" $ do
                    el "div" $ el "s" $ text $ toPublicKeyHashText removedKey
                    el "div" $ text "Your old address"
                  Nothing ->
                    blank
                for_ (snd <$> authorizedKeys) $ \authorizedKey ->
                  when (not $ maybeCurrentKey == Just authorizedKey) $
                    divClass "listed-address" $ do
                      el "div" $ text $ toPublicKeyHashText authorizedKey
                      el "div" $ text "Existing address"

          SemUi.divider def

          (backE, confirmE) <- elClass "div" "controls" $ do
            backE' <- modalBackButtonW "Go back"
            confirmE' <- modalSubmitButtonW "Confirm and save PKH" $ constDyn False
            pure (backE', confirmE')

          authToken <- getAuthToken
          let editPublicKeyRequestE = ApiRequest_Private authToken (PrivateRequest_UpdateSigningInfo $ SigningInfo
                { _signingInfo_user = uid
                , _signingInfo_signingCurve = signingCurve
                , _signingInfo_derivationPath = unDerivationPath derivationPath
                , _signingInfo_publicKey = publicKey
                , _signingInfo_publicKeyHash = publicKeyHash
                }) <$ confirmE
          editPublicKeyResponseE <- requestingIdentity editPublicKeyRequestE
          let (_, editPKSuccessE) = fanEither editPublicKeyResponseE

          continueE <- case (maybeTokenInfo, alreadyListed) of
            (Just tokenInfo, False) -> do
              let newPublicKey = (publicKey, publicKeyHash)
                  filteredKeys = filter (\ak -> maybeCurrentKey /= Just (snd ak)) authorizedKeys
              let multisigReconfig = buildMultisigReconfig tokenInfo numOfRequiredSignatures $ List.nub (newPublicKey:filteredKeys)
              let addUpdateSigningListOperationRequest = ApiRequest_Private authToken (PrivateRequest_AddPendingOperations $ multisigReconfig :| []) <$ editPKSuccessE
              addUpdateSigningListOperationResponse <- requestingIdentity addUpdateSigningListOperationRequest
              let (_, successE) = fanEither addUpdateSigningListOperationResponse
              return successE
            _ ->
              return never

          pure (never, leftmost
            [ updateSigningKeyWorkflow maybeTokenInfo uid Nothing maybeCurrentKey adminKeys authorizedKeys <$ backE
            , if alreadyListed then signingKeySetWorkflow publicKeyHash <$ editPKSuccessE else updateOperationCreatedWorkflow <$ continueE
            ])

      signingKeySetWorkflow :: PublicKeyHash -> Workflow t m (Event t ())
      signingKeySetWorkflow publicKeyHash = Workflow $
        modalBoxFormW "Edit Public Key Hash" $ mdo
          SemUi.divider def
          elClass "div" "workflow-success" $
            SemUi.label (def
              & SemUi.labelConfig_color SemUi.|?~ SemUi.Teal) $
              SemUi.icon "checkmark" def
          SemUi.header (def
            & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned
            & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $
            text "Your PKH has been set!"

          elClass "div" "public-key-hash" $ do
            elClass "p" "modal-message-text" $ text "Your new PKH is:"
            SemUi.header (def
              & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned
              & SemUi.headerConfig_size SemUi.|?~ SemUi.H3) $ el "strong" $ text $ toPublicKeyHashText publicKeyHash
          SemUi.divider def

          doneE <- elClass "div" "controls" $ modalSubmitButtonW "Done" $ constDyn False

          pure (doneE, never)

      updateOperationCreatedWorkflow :: Workflow t m (Event t ())
      updateOperationCreatedWorkflow = Workflow $
        modalBoxFormW "Edit Public Key Hash" $ mdo
          SemUi.divider def
          elClass "div" "workflow-success" $
            SemUi.label (def
              & SemUi.labelConfig_color SemUi.|?~ SemUi.Teal) $
              SemUi.icon "checkmark" def
          SemUi.header (def
            & SemUi.headerConfig_aligned SemUi.|?~ SemUi.CenterAligned
            & SemUi.headerConfig_size SemUi.|?~ SemUi.H2) $
            text "Update operation created."

          elClass "p" "modal-message-text" $ text "After three signatures are gathered the operation will be sent to the blockchain."

          SemUi.divider def

          doneE <- elClass "div" "controls" $ modalSubmitButtonW "Done" $ constDyn False
          pure (doneE, never)

      showPrettySigningCurve = \case
        SigningCurve_Ed25519 -> "ed25519 (tz1 addresses)"
        SigningCurve_Secp256k1 -> "secp256k1 (tz2 addresses)"
        SigningCurve_P256 -> "p256 (tz3 addresses)"
        _ -> error "Unsupported signing curve"

      readPretty = \case
        "ed25519 (tz1 addresses)" -> SigningCurve_Ed25519
        "secp256k1 (tz2 addresses)" -> SigningCurve_Secp256k1
        "p256 (tz3 addresses)" -> SigningCurve_P256
        _ -> SigningCurve_Ed25519
