{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE TupleSections #-}
{-# LANGUAGE TypeFamilies #-}
{-# OPTIONS_GHC -fno-warn-orphans #-}

module Backend.NotifyHandler where

import Control.Lens.Combinators (iforM)
import Control.Monad.IO.Class (liftIO)
import Data.Aeson
import Data.Aeson.GADT.TH
import Data.Constraint.Extras.TH
import Data.Dependent.Map
import Data.Functor.Identity
import Data.GADT.Show.TH
import Data.Pool
import Database.Groundhog.Postgresql
import Database.Id.Class
import Rhyolite.Account
import Rhyolite.Backend.DB
import Rhyolite.Backend.Listen
import Rhyolite.Backend.Logging
import qualified Web.ClientSession as CS

import Backend.ViewSelectorHandler
import Common.App
import Common.Schema

data Notification :: * -> * where
  Notification_Account :: Notification (Id Account)
  Notification_UserInfo :: Notification (Id UserInfo)
  Notification_SigningInfo :: Notification (Id SigningInfo)
  Notification_TokenInfo :: Notification (Id TokenInfo)
  Notification_AuthorizedKeys :: Notification (Id AuthorizedKeys)
  Notification_LoginSession :: Notification (Id LoginSession)
  Notification_PendingOperation :: Notification (Id PendingOperation)
  Notification_OperationSignature :: Notification (Id OperationSignature)
  Notification_TwoFactorInfo :: Notification (Id TwoFactorInfo)

instance HasNotification Notification UserInfo where
  notification _ = Notification_UserInfo

instance HasNotification Notification TokenInfo where
  notification _ = Notification_TokenInfo

instance HasNotification Notification AuthorizedKeys where
  notification _ = Notification_AuthorizedKeys

instance HasNotification Notification LoginSession where
  notification _ = Notification_LoginSession

instance HasNotification Notification PendingOperation where
  notification _ = Notification_PendingOperation

instance HasNotification Notification OperationSignature where
  notification _ = Notification_OperationSignature

instance HasNotification Notification SigningInfo where
  notification _ = Notification_SigningInfo

instance HasNotification Notification TwoFactorInfo where
  notification _ = Notification_TwoFactorInfo

-- Notifies the frontend when some data in the database has changed so that it may update the current view
notifyHandler :: forall a. Semigroup a => LoggingEnv -> CS.Key -> Pool Postgresql -> DbNotification Notification -> BTGViewSelector a -> IO (BTGView a)
notifyHandler loggingEnv csk db _notifyMessage@(DbNotification _ _nt n) vs = runLoggingEnv loggingEnv $ runDb (Identity db) $ case n of
  Notification_UserInfo :=> Identity _ -> do
    let userInfoVS = _btgViewSelector_userInfo vs
    userInfoV <- iforM userInfoVS $ \_ q -> fmap (q,) $ queryUserInfoView
    return $ mempty
      { _btgView_userInfo = userInfoV
      }
  Notification_SigningInfo :=> Identity _ -> do
    let userInfoVS = _btgViewSelector_userInfo vs
    userInfoV <- iforM userInfoVS $ \_ q -> fmap (q,) $ queryUserInfoView
    return $ mempty
      { _btgView_userInfo = userInfoV
      }
  Notification_TokenInfo :=> Identity _ -> do
    let tokenInfoVS = _btgViewSelector_tokenInfo vs
    tokenInfoV <- iforM tokenInfoVS $ \_ q -> fmap (q,) $ queryTokenInfo
    return $ mempty
      { _btgView_tokenInfo = tokenInfoV
      }
  Notification_AuthorizedKeys :=> Identity _ -> do
    let authorizedKeyVS = _btgViewSelector_authorizedKeys vs
    authorizedKeyV <- iforM authorizedKeyVS $ \_ q -> fmap (q,) $ queryAuthorizedKeys
    return $ mempty
      { _btgView_authorizedKeys = authorizedKeyV
      }
  Notification_LoginSession :=> Identity _ -> do
    let loginSessionVS = _btgViewSelector_loginSession vs
    loginSessionV <- iforM loginSessionVS $ \(LoginSessionQuery_IsValidSession authToken) q -> fmap (q,) $ queryLoginSession csk authToken
    return $ mempty
      { _btgView_loginSession = loginSessionV
      }
  Notification_PendingOperation :=> Identity _ -> do
    let pendingOperationVS = _btgViewSelector_pendingOperations vs
    pendingOperationV <- iforM pendingOperationVS $ \pendOpQuery q -> fmap (q,) $ queryPendingOperations pendOpQuery
    return $ mempty
      { _btgView_pendingOperations = pendingOperationV
      }
  Notification_OperationSignature :=> Identity _ -> do
    let operationSignatureVS = _btgViewSelector_operationSignature vs
    operationSignatureV <- iforM operationSignatureVS $ \opSigQuery q -> fmap (q,) $ queryOperationSignatures opSigQuery
    return $ mempty
      { _btgView_operationSignature = operationSignatureV
      }
  Notification_TwoFactorInfo :=> Identity _ -> do
    let userInfoVS = _btgViewSelector_userInfo vs
    userInfoV <- iforM userInfoVS $ \_ q -> fmap (q,) $ queryUserInfoView
    return $ mempty
      { _btgView_userInfo = userInfoV
      }

  _ -> do
    liftIO $ print $ "Uncaught Notification Handled."
    return mempty

deriveJSONGADT ''Notification
deriveArgDict ''Notification
deriveGShow ''Notification
