{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE QuasiQuotes #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE TypeFamilies #-}
{-# OPTIONS_GHC -fno-warn-orphans #-}

module Backend.Schema where

import Common.Schema
import Data.Aeson
import Data.Bifunctor
import qualified Data.ByteString.Lazy as LBS
import Data.Text (Text)
import Data.Text.Encoding
import Database.Groundhog.Core
import Database.Groundhog.Generic
import Database.Groundhog.TH
import Database.Id.Groundhog.TH
import Rhyolite.Backend.Account ()
import Rhyolite.Backend.DB.PsqlSimple
import Rhyolite.Backend.Schema.TH
import Tezos.Common.Base58Check
import Tezos.Wrapped.Schema
import Tezos.Token.Schema
import Tezos.V005.Contract
import Tezos.V005.Ledger
import Tezos.V005.Micheline
import Tezos.V005.PublicKey
import Tezos.V005.PublicKeyHash
import Tezos.V005.Signature

instance PersistField ContractScript where
  persistName _ = "ContractScript"
  toPersistValues = toPersistValues . decodeUtf8 . LBS.toStrict . encode
  fromPersistValues a = do
    (bs, pv) <- fromPersistValues a
    case decode bs of
      Just c -> return (c, pv)
      Nothing -> fail "Can't read contract"
  dbType _ _ = DbTypePrimitive DbString False Nothing Nothing
instance NeverNull ContractScript

instance PersistField ContractId where
  persistName _ = "ContractId"
  toPersistValues = toPersistValues . toContractIdText
  fromPersistValues = (fmap . first) (either (error . show) id . tryReadContractIdText) . primFromPersistValue
  dbType p _ = dbType p ("" :: Text)

instance PrimitivePersistField ContractId where
  toPrimitivePersistValue db = toPrimitivePersistValue db . toContractIdText
  fromPrimitivePersistValue db = either (error . show) id . tryReadContractIdText . fromPrimitivePersistValue db

------------------------------------------
-- TODO: Create Tezos.Groundhog -- from Kiln
instance PersistField PublicKeyHash where
  persistName _ = "PublicKeyHash"
  toPersistValues = toPersistValues . toPublicKeyHashText
  fromPersistValues = (fmap.first) toPublicKeyHash . primFromPersistValue
    where
      toPublicKeyHash = either (error . show) id . tryFromBase58 publicKeyHashConstructorDecoders . encodeUtf8
  dbType p _ = dbType p ("" :: Text)


-- TODO: Create Tezos.Groundhog -- for Kiln
instance PersistField ContractHash where
  persistName _ = "ContractHash"
  toPersistValues x = primToPersistValue $ toBase58Text x
  fromPersistValues = (fmap.first) toContractHash . primFromPersistValue
    where
      toContractHash = either (error . show) id . tryFromBase58 [TryDecodeBase58 id ] . encodeUtf8
  dbType p _ = dbType p ("" :: Text)

instance PersistField OperationHash where
  persistName _ = "OperationHash"
  toPersistValues x = primToPersistValue $ toBase58Text x
  fromPersistValues = (fmap.first) toOperationHash . primFromPersistValue
    where
      toOperationHash = either (error . show) id . tryFromBase58 [TryDecodeBase58 id ] . encodeUtf8
  dbType p _ = dbType p ("" :: Text)
------------------------------------------

instance PersistField Expression where
  persistName _ = "Expression"
  toPersistValues = toPersistValues . decodeUtf8 . LBS.toStrict . encode
  fromPersistValues a = do
    (bs, pv) <- fromPersistValues a
    case decode bs of
      Just c -> return (c, pv)
      Nothing -> fail "Can't read expression"
  dbType _ _ = DbTypePrimitive DbString False Nothing Nothing
instance NeverNull Expression

instance PersistField Signature where
  persistName _ = "Signature"
  toPersistValues = toPersistValues . toSignatureText
  fromPersistValues a = do
    (bs, pv) <- fromPersistValues a
    case tryReadSignature bs of
      Right c -> return (c, pv)
      Left err -> fail $ show err
  dbType _ _ = DbTypePrimitive DbString False Nothing Nothing

instance PersistField PublicKey where
  persistName _ = "PublicKey"
  toPersistValues = toPersistValues . toPublicKeyText
  fromPersistValues a = do
    (bs, pv) <- fromPersistValues a
    case tryFromBase58 publicKeyConstructorDecoders bs of
      Right c -> return (c, pv)
      Left err -> fail $ show err
  dbType _ _ = DbTypePrimitive DbString False Nothing Nothing

instance PersistField [(PublicKey, PublicKeyHash)] where
  persistName _ = "PublicKeyList"
  toPersistValues = toPersistValues . decodeUtf8 . LBS.toStrict . encode
  fromPersistValues a = do
    (bs, pv) <- fromPersistValues a
    case eitherDecode' bs of
      Right pks -> return (pks, pv)
      Left err -> fail $ "Failed reading PublicKeyList: " <> show err
  dbType _ _ = DbTypePrimitive DbString False Nothing Nothing


instance PersistField TokenOperation where
  persistName _ = "TokenOperation"
  toPersistValues = toPersistValues . decodeUtf8 . LBS.toStrict . encode
  fromPersistValues a = do
    (bs, pv) <- fromPersistValues a
    case eitherDecode' bs of
      Right pks -> return (pks, pv)
      Left err -> fail $ "Failed reading TokenOperation: " <> show err
  dbType _ _ = DbTypePrimitive DbString False Nothing Nothing

instance FromField PublicKey where
  fromField f b = either (error . show) id . tryFromBase58 publicKeyConstructorDecoders . encodeUtf8 <$> fromField f b

instance FromField PendingOperationStatus where fromField f = fmap read . fromField f

mkRhyolitePersist (Just "migrateSchema") [groundhog|
  - entity: UserInfo
  - primitive: Role
  - entity: TokenInfo
  - entity: AuthorizedKeys
  - entity: LoginSession
  - primitive: SigningCurve
  - entity: SigningInfo
  - entity: PendingOperation
    constructors:
    - name: PendingOperation
      uniques:
      - name: Pending_Operation_live_counters_are_unique
        type: index
        fields:
        - {expr: "\"operation#counter\""}
        - {expr: "(NULLIF(status::text = 'PendingOperationStatus_OperationFailed'::text, true))"}
        - {expr: "(NULLIF(dismissed, true))"}
  - primitive: PendingOperationStatus
  - embedded: WrappedCall
  - entity: WrappedPayload
  - entity: OperationSignature
  - entity: TwoFactorInfo
    constructors:
      - name: TwoFactorInfo
        keys:
        - name: TwoFactorAccountConstraint
        uniques:
        - name: TwoFactorAccountConstraint
          fields: [ _twoFactorInfo_account ]
  - entity: SentOperation
|]


fmap concat $ mapM (uncurry makeDefaultKeyIdInt64)
  [ (''UserInfo, 'UserInfoKey)
  , (''TokenInfo, 'TokenInfoKey)
  , (''AuthorizedKeys, 'AuthorizedKeysKey)
  , (''LoginSession, 'LoginSessionKey)
  , (''SigningInfo, 'SigningInfoKey)
  , (''PendingOperation, 'PendingOperationKey)
  , (''OperationSignature, 'OperationSignatureKey)
  , (''TwoFactorInfo, 'TwoFactorInfoKey)
  ]
