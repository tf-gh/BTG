{-# LANGUAGE DataKinds #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TupleSections #-}
{-# LANGUAGE TypeApplications #-}

module Backend.ViewSelectorHandler where

import Control.Lens hiding (from, to)
import Control.Monad (join)
import Control.Monad.IO.Class
import Control.Monad.Logger
import Data.Aeson
import qualified Data.List as List
import qualified Data.Map as Map
import Data.Map.Monoidal (MonoidalMap (..))
import qualified Data.Map.Monoidal as MMap
import Data.Maybe
import Data.Semigroup (First (..))
import qualified Data.Text as T
import qualified Data.Text.Encoding as T
import Data.Time.Clock
import Data.Time.Clock.POSIX
import Data.Traversable (for)
import Database.Groundhog.Postgresql
import Database.Id.Class
import Database.Id.Groundhog
import Network.HTTP.Client
import Rhyolite.Account
import Rhyolite.App
import Rhyolite.Backend.App
import Rhyolite.Backend.DB
import Rhyolite.Backend.Logging
import Rhyolite.Backend.Sign
import Rhyolite.SemiMap
import Text.URI (URI)
import Tezos.Common.Base58Check
import Tezos.Wrapped.Schema
import Tezos.NodeRPC.Network
import Tezos.V005.Micheline (Expression(..))
import Tezos.V005.Operation (OpParameters)
import Tezos.V005.Contract (ContractId)
import Tezos.Token.Schema
import qualified Web.ClientSession as CS

import Backend.Config
import Backend.Conseil
import Backend.Schema
import Backend.Token
import Common.App
import Common.Schema

-- Queries database for requested data and returns it to the frontend
viewSelectorHandler
  :: Config
  -> QueryHandler (BTGViewSelector a) IO
viewSelectorHandler config = QueryHandler $ \vs -> runLoggingEnv (config ^. config_loggingEnv) $ runDb (Identity $ config ^. config_db) $ do

  let userInfoVS = _btgViewSelector_userInfo vs
  userInfoV <- iforM userInfoVS $ \_ q -> fmap (q,) queryUserInfoView

  let tokenInfoVS = _btgViewSelector_tokenInfo vs
  tokenInfoV <- iforM tokenInfoVS $ \_ q -> fmap (q,) queryTokenInfo

  let authorizedKeysVS = _btgViewSelector_authorizedKeys vs
  authorizedKeysV <- iforM authorizedKeysVS $ \_ q -> fmap (q,) queryAuthorizedKeys

  let loginSessionVS = _btgViewSelector_loginSession vs
  loginSessionV <- iforM loginSessionVS $ \(LoginSessionQuery_IsValidSession authToken) q -> fmap (q,) $ queryLoginSession (config ^. config_clientSessionKey) authToken

  let pendingOperationsVS = _btgViewSelector_pendingOperations vs
  pendingOperationsV <- iforM pendingOperationsVS $ \pendOpQuery q -> fmap (q,) $ queryPendingOperations pendOpQuery

  let operationSignatureVS = _btgViewSelector_operationSignature vs
  operationSignatureV <- iforM operationSignatureVS $ \opSigQuery q -> fmap (q,) $ queryOperationSignatures opSigQuery

  let signingInfoVS = _btgViewSelector_signingInfo vs
  signingInfoV <- iforM signingInfoVS $ \signingInfoQuery q -> fmap (q,) $ querySigningInfo signingInfoQuery

  let pastOperationsVS = _btgViewSelector_pastOperations vs
  pastOperationsV <- iforM pastOperationsVS $ \pastOpQuery q ->
    fmap (q,) $ queryPastOperations
      (_nodeRPCContext_httpManager $ _publicNodeContext_nodeCtx $ config ^. config_publicNodeContext)
      (config ^. config_conseilUri) (config ^. config_conseilApiKey)
      pastOpQuery

  let tokenHoldersVS = _btgViewSelector_tokenHolders vs
  tokenHoldersV <- iforM tokenHoldersVS $ \tokenHoldersQuery q ->
    fmap (q,) $ queryTokenHolders
      (_nodeRPCContext_httpManager $ _publicNodeContext_nodeCtx $ config ^. config_publicNodeContext)
      (config ^. config_conseilUri) (config ^. config_conseilApiKey)
      tokenHoldersQuery

  return BTGView
    { _btgView_echo = MMap.mapWithKey (\_ v -> (v, First (Just ""))) $ _btgViewSelector_echo vs
    , _btgView_userInfo = userInfoV
    , _btgView_tokenInfo = tokenInfoV
    , _btgView_authorizedKeys = authorizedKeysV
    , _btgView_loginSession = loginSessionV
    , _btgView_pendingOperations = pendingOperationsV
    , _btgView_operationSignature = operationSignatureV
    , _btgView_signingInfo = signingInfoV
    , _btgView_pastOperations = pastOperationsV
    , _btgView_tokenHolders = tokenHoldersV
    }

queryUserInfoView :: PersistBackend m => m (SemiMap (Id UserInfo) (Maybe UserInfoView))
queryUserInfoView = do
  allUsers :: [(Id UserInfo, UserInfo)] <- fmap (\(a,b) -> (toId a, b)) <$> project (AutoKeyField, UserInfoConstructor) (UserInfo_deletedField /=. (Just True))
  allUserViews <- for allUsers $ \(uid, user) -> do
    maybeSigningInfo <- getUserSigningInfo $ _userInfo_account user

    hasTwoFactorAuth <- listToMaybe <$> select (TwoFactorInfo_accountField ==. _userInfo_account user)
    pure $ (uid, UserInfoView
      { _userInfoView_name = _userInfo_name user
      , _userInfoView_email = _userInfo_email user
      , _userInfoView_role = _userInfo_role user
      , _userInfoView_account  = _userInfo_account user
      , _userInfoView_publicKeyHash = fmap _signingInfo_publicKeyHash maybeSigningInfo
      , _userInfoView_hasTwoFactorAuth = isJust hasTwoFactorAuth
      })
  let userMap = MMap.MonoidalMap $ Map.fromList $ fmap (\(k, info) -> (k, Just info)) allUserViews
  return $ SemiMap_Complete userMap

queryTokenInfo :: PersistBackend m => m (First (Maybe TokenInfo))
queryTokenInfo = do
  maybeTokenInfo <- listToMaybe <$> selectAll
  return $ case maybeTokenInfo of
    Just (_, tokenInfo :: TokenInfo) ->
      First (Just tokenInfo)
    Nothing ->
      First Nothing

queryAuthorizedKeys :: PersistBackend m => m (First (Maybe AuthorizedKeys))
queryAuthorizedKeys = do
  maybeAuthorizedKeys <- listToMaybe <$> select ((AuthorizedKeys_activeField ==. True) `orderBy` [Desc AuthorizedKeys_timestampField])
  return $ First maybeAuthorizedKeys


queryLoginSession :: PersistBackend m => CS.Key -> AppCredential BTG -> m (First Bool)
queryLoginSession csk authToken = do
  case readSignedWithKey csk authToken of
    Just (AuthToken (Identity accId), startTime) -> do
      loginSessions <- select $
        LoginSession_accountField ==. accId &&.
        LoginSession_startTimeField ==. startTime
      return $ First $ not $ null loginSessions
    _ ->
      return $ First False

queryPendingOperations :: PersistBackend m => PendingOperationsQuery -> m (SemiMap (Id PendingOperation) PendingOperation)
queryPendingOperations = \case
  PendingOperationsQuery_Pending -> do
    pending <- project
      (AutoKeyField, PendingOperationConstructor)
      ((PendingOperation_dismissedField /=. (Just True)))
    let pendOpMap = MMap.MonoidalMap $ Map.fromList $ fmap (\(k, info) -> (toId k, info)) pending
    return $ SemiMap_Complete pendOpMap

-- Probably wants to be grouped by PendingOperation and made into a map.
queryOperationSignatures :: PersistBackend m => OperationSignatureQuery -> m (SemiMap (Id OperationSignature) OperationSignature)
queryOperationSignatures (OperationSignatureQuery_ByPendingOperation pendingOpId) = do
  opSigs <- project (AutoKeyField, OperationSignatureConstructor) (OperationSignature_pendingOperationField ==. pendingOpId)
  let opSigMap = MMap.MonoidalMap $ Map.fromList $ fmap (\(k, info) -> (toId k, info)) opSigs
  return $ SemiMap_Complete opSigMap

querySigningInfo :: PersistBackend m => SigningInfoQuery -> m (First (Maybe SigningInfo))
querySigningInfo (SigningInfoQuery_OfUser aid) =
  First <$> getUserSigningInfo aid

getUserSigningInfo :: PersistBackend m => Id Account -> m (Maybe SigningInfo)
getUserSigningInfo accId = do
  maybeSigningInfoId :: Maybe (Id SigningInfo) <- join . listToMaybe <$> project UserInfo_signingInfoField (UserInfo_accountField ==. accId)
  maybeSigningInfo <- for maybeSigningInfoId $ \signingInfoId -> get $ fromId signingInfoId
  return $ join maybeSigningInfo

queryPastOperations
  :: forall m. (MonadIO m, MonadLogger m, PersistBackend m)
  => Manager -> URI -> ConseilAPIKey -> PastOperationsQuery -> m (SemiMap OperationHash PastOperation)
queryPastOperations httpManager conseilUri conseilApiKey = \case
  PastOperationsQuery_Conseil -> do
    result <- listToMaybe <$> project (TokenInfo_contractAddressField, TokenInfo_multiSignatureContractAddressField) (TokenInfo_nameField ==. tokenName)
    case result of
      Just (tokenContractAddress, multisigContractAddress) -> do
        maybePastTokenOps <- getOps httpManager conseilUri conseilApiKey tokenContractAddress
        maybePastMultisigOps <- getOps httpManager conseilUri conseilApiKey multisigContractAddress
        case (maybePastTokenOps, maybePastMultisigOps) of
          (Just pastTokenOps, Just pastMultisigOps) -> do
            let pastTokenOpMap = parseOps pastTokenOps $ \opParameters -> do
                  tokenOperation <- Tezos.Token.Schema.fromOpParameters opParameters
                  return $ WrappedPayload_Call tokenContractAddress tokenOperation (Expression_String "UNIMPLEMENTED")
                  -- FIXME -- this makes it impossible to actually use results of this query as wrapped signature operations.
                  --       -- we probably don't need that but it is still an unfortunate edge case.  HKD here would be neater?
            let pastMultisigOpMap = parseOps pastMultisigOps $ \opParameters -> do 
                  (threshold, publicKeys) <- Tezos.Wrapped.Schema.fromOpParameters opParameters
                  return $ WrappedPayload_Reconfig threshold ((\pk -> (pk, toPublicKeyHash pk)) <$> publicKeys)
            return $ SemiMap_Complete $ MonoidalMap $ Map.union (getMonoidalMap pastTokenOpMap) (getMonoidalMap pastMultisigOpMap)
          _ ->
            return $ SemiMap_Complete $ MonoidalMap mempty
      _ ->
        return $ SemiMap_Complete $ MonoidalMap mempty

queryTokenHolders
  :: forall m. (MonadIO m, MonadLogger m, PersistBackend m)
  => Manager -> URI -> ConseilAPIKey -> TokenHoldersQuery -> m (SemiMap ContractId TokenHolderInfo)
queryTokenHolders httpManager conseilUri conseilApiKey = \case
  TokenHoldersQuery_All -> do
    result <- listToMaybe <$> project TokenInfo_contractAddressField (TokenInfo_nameField ==. tokenName)
    case result of
      Just tokenContractAddress -> do
        maybePastTokenOps <- getOps httpManager conseilUri conseilApiKey tokenContractAddress
        case maybePastTokenOps of
          Just pastTokenOps -> do
            let pastTokenOpList = MMap.elems $ parseOps pastTokenOps $ \opParameters -> do
                  tokenOperation <- Tezos.Token.Schema.fromOpParameters opParameters
                  return $ WrappedPayload_Call tokenContractAddress tokenOperation (Expression_String "UNIMPLEMENTED")
                tokenHoldersMap = foldl (\holderMap cur -> 
                  case _pastOperation_parameters cur of
                    WrappedPayload_Call _ tokenOp _ ->
                      case tokenOp of 
                        Mint amount target ->
                          addToAddress target amount holderMap
                        Burn amount target -> 
                          subtractFromAddress target amount holderMap 
                        Transfer amount from to ->
                          holderMap 
                            & subtractFromAddress from amount
                            & addToAddress to amount  
                        AddToWhitelist address -> 
                          addToWhitelist holderMap address
                        AddToWhitelistBatch addresses -> 
                          foldl addToWhitelist holderMap addresses
                        RemoveFromWhitelist address -> 
                          removeFromWhitelist holderMap address
                        RemoveFromWhitelistBatch addresses -> 
                          foldl removeFromWhitelist holderMap addresses      
                        SetPause _ -> 
                          holderMap
                        Disburse _ -> 
                          holderMap
                    WrappedPayload_Reconfig _ _ ->
                      holderMap
                  ) mempty (List.sortBy (\a b -> compare (_pastOperation_timestamp a) (_pastOperation_timestamp b)) pastTokenOpList)
            return $ SemiMap_Complete $ MonoidalMap tokenHoldersMap
          _ ->
            return $ SemiMap_Complete $ MonoidalMap mempty
      _ ->
        return $ SemiMap_Complete $ MonoidalMap mempty
  where 
    addToAddress address amount holderMap = 
      Map.alter (\case 
        Just existingValue ->
          Just $ over tokenHolderInfo_balance (+ amount) existingValue
        Nothing -> Just $ TokenHolderInfo 
          { _tokenHolderInfo_balance = amount
          , _tokenHolderInfo_isWhitelisted = False
          }
      ) address holderMap
    subtractFromAddress address amount holderMap = 
      Map.alter (\case 
        Just existingValue ->
          Just $ over tokenHolderInfo_balance ((-) amount) existingValue
        Nothing -> Just $ TokenHolderInfo 
          { _tokenHolderInfo_balance = 0 - amount
          , _tokenHolderInfo_isWhitelisted = False
          }
      ) address holderMap   

    addToWhitelist holderMap address = 
      Map.alter (\case 
        Just existingValue ->
          Just $ set tokenHolderInfo_isWhitelisted True existingValue
        Nothing -> Just $ TokenHolderInfo 
          { _tokenHolderInfo_balance = 0
          , _tokenHolderInfo_isWhitelisted = True
          }
      ) address holderMap
    removeFromWhitelist holderMap address = 
      Map.alter (\case 
        Just existingValue ->
          Just $ set tokenHolderInfo_isWhitelisted False existingValue
        Nothing -> Just $ TokenHolderInfo 
          { _tokenHolderInfo_balance = 0
          , _tokenHolderInfo_isWhitelisted = False
          }
      ) address holderMap


getOps 
  :: (MonadIO m, MonadLogger m) 
  => Manager -> URI -> ConseilAPIKey -> ContractId -> m (Maybe [ConseilQueryResult])
getOps httpManager conseilUri conseilApiKey contractId = 
  queryConseil httpManager conseilUri conseilApiKey $ ConseilQuery
    { _conseilQuery_destinations = [ contractId ]
    , _conseilQuery_limit = 1000
    }

parseOps :: [ConseilQueryResult] -> (OpParameters -> Maybe WrappedPayload) -> MonoidalMap OperationHash PastOperation
parseOps pastOps parser = MonoidalMap $ Map.fromList $ catMaybes $ flip fmap pastOps $ \pastOp ->
  let opTimestamp = millisToUTC $ _conseilQueryResult_timestamp pastOp
      (Right opHash) = fromBase58 @'HashType_OperationHash $ T.encodeUtf8 $ _conseilQueryResult_operationGroupHash pastOp
      rawOpParameters = _conseilQueryResult_parameters pastOp
      {-
          The reason for `T.dropWhile` is that when Conseil can't parse an operation's parameters, an error message is prepended to the value, which
          needs to be truncated in order for JSON decoding to work.

          E.g., "Unparsable code: {\"entrypoint\":\"main\", ..."
      -}
      maybeOpParameters = decodeStrict $ T.encodeUtf8 (T.dropWhile (/= '{') rawOpParameters)
  in case join (fmap parser maybeOpParameters) of
      Just opParameters ->
        Just (opHash, PastOperation opTimestamp opParameters opHash)
      Nothing ->
        Nothing
  where
    millisToUTC :: Integer -> UTCTime
    millisToUTC t = posixSecondsToUTCTime $ (fromInteger t) / 1000
