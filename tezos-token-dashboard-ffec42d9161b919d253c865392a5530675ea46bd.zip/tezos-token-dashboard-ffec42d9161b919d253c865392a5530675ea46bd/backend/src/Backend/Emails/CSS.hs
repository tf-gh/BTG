{-# LANGUAGE TemplateHaskell #-}
module Backend.Emails.CSS where

import Backend.Emails.CSSPreprocess
import Backend.Emails
import Data.Text

emailCSS :: Text
emailCSS = $(preprocessCss "semantic.min.css" emailExamples)
