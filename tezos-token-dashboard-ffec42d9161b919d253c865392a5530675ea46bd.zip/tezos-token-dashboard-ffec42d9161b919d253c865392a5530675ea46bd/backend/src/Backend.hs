{-# LANGUAGE DataKinds #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE MultiWayIf #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PackageImports #-}
{-# LANGUAGE PatternGuards #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE QuasiQuotes #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeFamilies #-}

module Backend where

import Prelude hiding (id, span, (.))

import qualified Codec.QRCode as QR
import qualified Codec.QRCode.JuicyPixels as QR
import Control.Category
import Control.Exception (IOException)
import Control.Lens
import Control.Monad
import Control.Monad.Catch (MonadCatch, handle)
import Control.Monad.Except (MonadError, runExceptT, throwError)
import Control.Monad.IO.Class
import Control.Monad.Logger
import Control.Monad.Reader
import "cryptonite" Crypto.Hash (Blake2b, Digest, hash)
import qualified "cryptonite" Crypto.OTP as OTP
import "cryptonite" Crypto.Random (getSystemDRG, randomBytesGenerate)
import qualified Data.Base32String.Default as B32
import qualified Data.ByteArray as BA
import qualified Data.ByteString as BS
import Data.Dependent.Sum (DSum (..))
import Data.Byteable (toBytes)
import Data.Either
import Data.Foldable (for_)
import Data.Foldable (toList, traverse_)
import qualified Data.List as List
import qualified Data.Map as Map
import Data.Maybe
import Data.SecureMem
import qualified Data.Sequence as Seq
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.Lazy as T (toStrict)
import Data.Time
import Data.Time.Clock.POSIX
import Data.Traversable (for)
import Data.Word
import Database.Groundhog (runMigration)
import Database.Groundhog.Generic.Migration hiding (migrateSchema)
import Database.Groundhog.Postgresql
import Database.Id.Class
import Database.Id.Groundhog
import Gargoyle.PostgreSQL.Connect
import HaveIBeenPwned
import Network.HTTP.Client
import Obelisk.Backend
import Obelisk.ExecutableConfig.Lookup
import Rhyolite.Account
import Rhyolite.Api
import Rhyolite.App
import Rhyolite.Backend.Account
import Rhyolite.Backend.App
import Rhyolite.Backend.DB
import Rhyolite.Backend.Email
import Rhyolite.Backend.Listen
import Rhyolite.Backend.Logging
import Rhyolite.Backend.Sign
import Rhyolite.Email
import Rhyolite.Schema
import Rhyolite.Sign
import Safe
import qualified Text.URI as URI
import qualified Text.URI.QQ as URI
import Tezos.Common.Base58Check
import Tezos.Common.Chain
import Tezos.Common.Json
import Tezos.Common.NodeRPC.Sources
import Tezos.Common.NodeRPC.Types
import Tezos.NodeRPC.Network
import qualified Tezos.Signature.Verify as TZ
import Tezos.V005.Account (_account_script)
import Tezos.V005.Block hiding (hash)
import Tezos.V005.Contract
import Tezos.V005.NodeRPC.Class
import Tezos.V005.NodeRPC.CrossCompat
import Tezos.V005.PublicKey
import Tezos.V005.PublicKeyHash

import Backend.Config
import Backend.Emails
import Backend.Emails.CSS
import Backend.Migration
import Backend.NotifyHandler
import Backend.OperationInjection (testReadingInjectionMethod)
import Backend.Schema
import Backend.Token
import Backend.ViewSelectorHandler
import Common.App
import Common.Route
import Common.Schema
import Tezos.Wrapped.Schema
import Tezos.Token.Schema

backend :: Backend BackendRoute FrontendRoute
backend = Backend
  { _backend_run = \serve -> do
      configs <- getConfigs
      withLogging [LoggingConfig (RhyoliteLogAppender_Stderr $ RhyoliteLogAppenderStderr Nothing) $ Just (Map.singleton "TOKEN" RhyoliteLogLevel_Debug)] $ do
        logger <- fmap LoggingEnv askLoggerIO
        liftIO $ withDb "db" $ \db -> do
          testReadingInjectionMethod
          cfg <- mkConfig configs logger db

          _ <- runLoggingEnv logger $
            runDb (Identity db) $ do
              handleMigrations
              tableInfo <- getTableAnalysis
              runMigration $ do
                migrateAccount tableInfo
                migrateSchema tableInfo
              inviteFirstAdmin cfg
              addAuthorizedKeys cfg

          (listen, _) <- liftIO $ serveDbOverWebsockets db
            (handleRequests cfg)
            (notifyHandler logger (cfg ^. config_clientSessionKey) db)
            (viewSelectorHandler cfg)
            (queryMorphismPipeline $ transposeMonoidMap . monoidMapQueryMorphism)
          liftIO $ serve $ \case
            BackendRoute_Missing :=> _ -> return () -- TODO: create a 404 page not found route
            BackendRoute_Listen :=> Identity () -> listen

  , _backend_routeEncoder = backendRouteEncoder
  }

-- TODO: This will eventually need its own module
handleRequests
  :: ( MonadIO m
     , MonadBaseNoPureAborts IO m
     )
  => Config -> RequestHandler BTG m
handleRequests cfg = RequestHandler $ \req ->
  let db = cfg ^. config_db
      csk = cfg ^. config_clientSessionKey
      httpManager = _nodeRPCContext_httpManager $ _publicNodeContext_nodeCtx $ _config_publicNodeContext cfg
  in runLoggingEnv (cfg ^. config_loggingEnv) $ runDb (Identity db) $ case req of
    ApiRequest_Public r -> case r of
      PublicRequest_Login email pw maybeOtp ->
        flip runSignT csk $ loginHandler email pw maybeOtp
      PublicRequest_CreateAccount passwordResetToken name pw ->
        flip runSignT csk $ createAccountHandler passwordResetToken name pw httpManager $ cfg ^. config_firstAdminEmail
      PublicRequest_PasswordResetRequest email ->
        flip runSignT csk $ runEmailT (passwordResetEmailHandler (cfg ^. config_baseUrl) email) $ cfg ^. config_emailEnv
      PublicRequest_PasswordReset passwordResetToken password maybeOtp ->
        flip runSignT csk $ passwordResetHandler passwordResetToken password maybeOtp httpManager
      PublicRequest_RunBlake2bHash hashLength byteString ->
        return $ Right $ BS.pack $ case hashLength of
          Blake2bHashSize_20 -> BA.unpack $ (hash :: BS.ByteString -> Digest (Blake2b 160)) byteString
          Blake2bHashSize_32 -> BA.unpack $ (hash :: BS.ByteString -> Digest (Blake2b 256)) byteString
      PublicRequest_GetTotalTokenSupply -> do
        Just tokenContract <- listToMaybe <$> project TokenInfo_contractAddressField (TokenInfo_nameField ==. tokenName)
        result <- runRPCCall (cfg ^. config_publicNodeContext) $ getTotalTokenSupplyFromContract (_config_gasWallet cfg) tokenContract (_config_resultReceiverContractForNat cfg)
        case result of
          Left err  ->
            return $ Left $ BTGError_UserError $ T.pack $ show err
          Right (Left err)  ->
            return $ Left $ BTGError_UserError $ T.pack $ show err
          Right (Right tokenSupply) -> do
            return $ Right tokenSupply

    ApiRequest_Private rawAuthToken r -> do
        maybeAuthToken <- flip runSignT csk $ readSigned rawAuthToken
        case maybeAuthToken of
          Just (AuthToken (Identity accId), startTime) -> do
            loginSessions <- select $ LoginSession_accountField ==. accId &&. LoginSession_startTimeField ==. startTime
            case listToMaybe loginSessions of
              Just _ ->
                case r of
                  PrivateRequest_Logout -> do
                    clearLoginSessions accId
                    return $ Right ()
                  PrivateRequest_DeleteAccount uid ->
                    deleteAccountHandler accId uid
                  PrivateRequest_Validate -> do
                    userInfo:_ <- select $ UserInfo_accountField ==. accId
                    return $ Right $ LoginResponse rawAuthToken userInfo
                  PrivateRequest_InviteUser email ->
                    flip runSignT csk $ inviteUserHandler accId email (cfg ^. config_baseUrl) (cfg ^. config_emailEnv)
                  PrivateRequest_ChangeUserRole uid role mOpt ->
                    changeUserRoleHandler accId uid role mOpt
                  PrivateRequest_ChangePassword oldPw newPw maybeOtp ->
                    changePasswordHandler (accId, startTime) oldPw newPw maybeOtp httpManager
                  PrivateRequest_New2FASecret ->
                    flip runSignT csk $ new2FASecretHandler accId
                  PrivateRequest_Set2FASecret token otp ->
                    flip runSignT csk $ set2FASecretHandler accId token otp
                  PrivateRequest_CreateTokenInfo name tickerSymbol tokenAddress ->
                    createTokenInfoHandler name tickerSymbol tokenAddress (cfg ^. config_gasWallet) (cfg ^. config_resultReceiverContractForAddress) (cfg ^. config_publicNodeContext)
                  PrivateRequest_DeleteTokenInfo -> do
                    deleteAll $ TokenInfo
                      { _tokenInfo_name = ""
                      , _tokenInfo_tickerSymbol = ""
                      , _tokenInfo_contractAddress = ""
                      , _tokenInfo_multiSignatureContractAddress = ""
                      , _tokenInfo_contractScript = Nothing
                      }
                    return $ Right ()
                  PrivateRequest_UpdateSigningInfo signingInfo -> do
                    sid <- insertAndNotify signingInfo
                    updateAndNotify (_signingInfo_user signingInfo) [ UserInfo_signingInfoField =. Just sid ]
                    return $ Right ()
                  PrivateRequest_SeeGasWalletBalance -> do
                    tzAccount <- flip runReaderT (_config_publicNodeContext cfg) $ runExceptT $ do
                      chainId :: ChainId <- nodeRPC rChain
                      blockHash <- view (withProtocolHash_value . veryBlockLike_hash) <$> getCurrentHead chainId
                      let chainType = ChainTag_Hash chainId
                      nodeRPC $ rContract (Implicit $ _config_gasWallet cfg) chainType blockHash
                    case tzAccount of
                      Right (AccountV005 account) -> return $ Right account
                      Right (AccountV004 _) -> return $ Left $ BTGError_UserError $ "Requested an unsupported block type"
                      Left (e :: PublicNodeError) -> return $ Left $ BTGError_UserError $ T.pack $ show e
                  PrivateRequest_GetMintCap tokenContract -> do
                    mintResp <- runReaderT (runExceptT @RpcError $ getMintingCapFromContract (_config_gasWallet cfg) tokenContract) (cfg ^. config_publicNodeContext)
                    case mintResp of
                      Right (Right mintCap) -> return $ Right mintCap
                      Right (Left errString) -> return $ Left $ BTGError_UserError $ T.pack $ show errString
                      Left err -> return $ Left $ BTGError_UserError $ T.pack $ show err
                  PrivateRequest_AddPendingOperations multisigCalls -> do
                    mRequestingRole <- listToMaybe <$> project UserInfo_roleField (UserInfo_accountField ==. accId)
                    case mRequestingRole of
                      Just role | role == Role_Admin -> do 
                        results <- for multisigCalls $ \multisigCall -> do
                          let pendingOperation = PendingOperation
                                { _pendingOperation_operation = multisigCall
                                , _pendingOperation_status = PendingOperationStatus_NeedsSignatures
                                , _pendingOperation_dismissed = Just False
                                }
                          nextCounter <- fmap listToMaybe $ project
                            (PendingOperation_operationField ~> WrappedCall_counterSelector) $
                            (PendingOperation_operationField ~> WrappedCall_wrapperSelector ==. multisigCall ^. wrappedCall_wrapper &&.
                            (PendingOperation_statusField ==. PendingOperationStatus_Sent
                            ||. (PendingOperation_dismissedField /=. Just True
                                  &&. PendingOperation_statusField /=. PendingOperationStatus_OperationFailed)))
                            `orderBy` [Desc $ PendingOperation_operationField ~> WrappedCall_counterSelector]
                            `limitTo` 1
                          $(logDebugS) "TOKEN" $ "next counter query returned: " <> T.pack (show nextCounter)
                          onChainMultisigCounter <- getOnChainCounter (cfg ^. config_publicNodeContext) $ multisigCall ^. wrappedCall_wrapper
                          let finalOperation = pendingOperation & pendingOperation_operation . wrappedCall_counter .~ fromMaybe onChainMultisigCounter (succ <$> nextCounter)
                          pendingId <- insertAndNotify finalOperation
                          return (pendingId, _pendingOperation_operation finalOperation)
                        return $ Right results
                      _ -> return $ Left $ BTGError_UserError "User does not have permission to create a pending operation."

                  PrivateRequest_AddOperationSignatures opSignatures (SignatureCount initialSignaturePosition) -> do
                    mRequestingRole <- listToMaybe <$> project UserInfo_roleField (UserInfo_accountField ==. accId)
                    case mRequestingRole of
                      Just role | role == Role_Admin -> do 
                        signatureValidationResults <- runExceptT $ for opSignatures $ \opSignature -> do
                          -- Check if number of required signatures have already been met
                          let pendingOpId = _operationSignature_pendingOperation opSignature
                          existingSignatures <- select $ OperationSignature_pendingOperationField ==. pendingOpId
                          isDismissedWithOperationResult <- listToMaybe <$> project (PendingOperation_dismissedField, PendingOperation_operationField) (AutoKeyField ==. (fromId pendingOpId))
                          let isDismissedResult = fst <$> isDismissedWithOperationResult
                              isDismissed = case isDismissedResult of
                                Nothing -> True
                                Just Nothing -> False
                                Just (Just dismissed) -> dismissed
                              mMultiSigCall = snd <$> isDismissedWithOperationResult
                              currentPosition = length existingSignatures + 1
                          if | length existingSignatures >= numOfRequiredSignatures -> 
                                throwError $ BTGError_OperationSignatureSatisfied "Signing failed. This operation has already been sent to the blockchain."
                             | isDismissed ->
                                throwError $ BTGError_OperationDismissed "Signing failed. The operation was cancelled."
                             | currentPosition /= initialSignaturePosition ->
                                throwError $ BTGError_OperationSignaturePositionChange currentPosition
                             | otherwise -> do 
                                -- check to see if correct ledger device was used to sign
                                maybeSigningInfo <- getUserSigningInfo accId
                                case maybeSigningInfo of 
                                  Nothing -> 
                                    throwError BTGError_OperationSignatureInvalid
                                  Just signingInfo -> do  
                                    let verified = TZ.check (_signingInfo_publicKey signingInfo) (_operationSignature_signature opSignature) (maybe "" (BS.cons 5 . wrappedCallBytesToSign) mMultiSigCall)
                                    if not verified
                                      then throwError BTGError_OperationSignatureInvalid
                                      else do
                                        authorizedKeys <- getAuthorizedKeys
                                        let authorized = List.elem (_signingInfo_publicKey signingInfo) (fst <$> authorizedKeys)
                                        if not authorized 
                                          then throwError BTGError_OperationSignatureUnauthorized
                                          else return (existingSignatures, opSignature)
                        case signatureValidationResults of 
                          Right validatedOpSignatures -> do
                            insertSignatureResults <- runExceptT $ for validatedOpSignatures $ \(existingOpSignatures, newOpSignature) -> do
                              let pendingOpId = _operationSignature_pendingOperation newOpSignature
                              -- If latest signature met number of required signatures... sendMultisigCallWithSignatures
                              _ <- insertAndNotify newOpSignature 
                              case (length existingOpSignatures + 1) == numOfRequiredSignatures of
                                True -> do
                                  -- Set current pending operation status
                                  updateAndNotify pendingOpId [PendingOperation_statusField =. PendingOperationStatus_Waiting]
      
                                  -- Recursively process operation queue
                                  readyOperations <- queryReadyOperations
                                  recursiveResults <- recursivelyProcessReadyOperations cfg readyOperations
                                  case recursiveResults of
                                    x:_ -> return $ Just x
                                    [] -> return Nothing
                                False -> do
                                  return Nothing
                            case insertSignatureResults of 
                              Right maybeOpHashes -> 
                                return $ Right maybeOpHashes
                              Left err -> 
                                return $ Left err 
                          Left err ->
                            return $ Left err  
                      _ -> return $ Left $ BTGError_UserError "User does not have permission to sign an operation."

                  PrivateRequest_DismissOperations pendOpIds -> do
                    mRequestingRole <- listToMaybe <$> project UserInfo_roleField (UserInfo_accountField ==. accId)
                    case mRequestingRole of
                      Just role | role == Role_Admin -> do
                        traverse_ (\pendOpId -> updateAndNotify pendOpId [PendingOperation_dismissedField =. (Just True)]) pendOpIds
                        return $ Right ()
                      _ -> return $ Left $ BTGError_UserError "User does not have permission to dismiss an operation."

                  PrivateRequest_CancelOperation pendOpId -> do
                    mRequestingRole <- listToMaybe <$> project UserInfo_roleField (UserInfo_accountField ==. accId)
                    case mRequestingRole of
                      Just role | role == Role_Admin -> do
                        existingSignatures <- project OperationSignature_signatureField (OperationSignature_pendingOperationField ==. pendOpId)
                        if length existingSignatures >= numOfRequiredSignatures
                          then return $ Left $ BTGError_UserError "The operation receieved three signatures and was sent to the blockchain before it could be cancelled."
                          else do
                            updateAndNotify pendOpId [PendingOperation_dismissedField =. (Just True)]
                            dismissSubsequentOperations pendOpId
                      _ -> return $ Left $ BTGError_UserError "User does not have permission to cancel an operation."

                  PrivateRequest_GetPaused tokenContract -> do
                    pausedResp <- runReaderT (runExceptT @RpcError $ getPausedStateFromContract (_config_gasWallet cfg) tokenContract) (cfg ^. config_publicNodeContext)
                    case pausedResp of
                      Right (Right paused) -> return $ Right paused
                      Right (Left errString) -> return $ Left $ BTGError_UserError $ T.pack $ show errString
                      Left err -> return $ Left $ BTGError_UserError $ T.pack $ show err

                  PrivateRequest_CheckWhitelist address -> do
                    Just tokenContract <- listToMaybe <$> project TokenInfo_contractAddressField (TokenInfo_nameField ==. tokenName)
                    result <- runRPCCall (cfg ^. config_publicNodeContext) $ checkWhitelistedOnContract (_config_gasWallet cfg) tokenContract address
                    case result of
                      Left err  ->
                        return $ Left $ BTGError_UserError $ T.pack $ show err
                      Right (Left err)  ->
                        return $ Left $ BTGError_UserError $ T.pack $ show err
                      Right (Right isWhitelisted) -> do
                        existingPendingOp <- checkForExistingOperation $
                          if isWhitelisted
                            then RemoveFromWhitelist address
                            else AddToWhitelist address
                        return $ Right $ WhitelistCheck
                          { _whitelistCheck_alreadyWhitelisted = isWhitelisted
                          , _whitelistCheck_pendingOperation = existingPendingOp
                          }

                  PrivateRequest_CheckWhitelistBatch addresses -> do
                    Just tokenContract <- listToMaybe <$> project TokenInfo_contractAddressField (TokenInfo_nameField ==. tokenName)
                    results <- for addresses $ \address -> do
                      result <- runRPCCall (cfg ^. config_publicNodeContext) $ checkWhitelistedOnContract (_config_gasWallet cfg) tokenContract address
                      case result of
                        Left err ->
                          return $ Left $ BTGError_UserError $ T.pack $ show err
                        Right (Left err)  ->
                          return $ Left $ BTGError_UserError $ T.pack $ show err
                        Right (Right isWhitelisted) ->
                          return $ Right (address, isWhitelisted)
                    case partitionEithers results of
                      ([], successes) ->
                        return $ Right successes
                      (failures, _) ->
                        return $ Left $ BTGError_UserError $ T.pack $
                          "Error checking whitelist status for " <> show (length failures) <> " of " <> show (length addresses) <> " addresses."

                  PrivateRequest_GetTokenHolderBalance tokenHolderAddress -> do
                    Just tokenContract <- listToMaybe <$> project TokenInfo_contractAddressField (TokenInfo_nameField ==. tokenName)
                    result <- runRPCCall (cfg ^. config_publicNodeContext) $ getTokenHolderBalanceFromContract (_config_gasWallet cfg) tokenContract (_config_resultReceiverContractForNat cfg) tokenHolderAddress
                    case result of
                      Left err  ->
                        return $ Left $ BTGError_UserError $ T.pack $ show err
                      Right (Left err)  ->
                        return $ Left $ BTGError_UserError $ T.pack $ show err
                      Right (Right balance) -> do
                        return $ Right balance

              Nothing ->
                return $ catchAll r errorSessionAuthError
          Nothing ->
            return $ catchAll r genericAuthError
        where
          genericAuthError =
            BTGError_AuthError "Unable to authenticate private request"
          errorSessionAuthError =
            BTGError_AuthError "Login session is expired"
          catchAll :: PrivateRequest BTG a -> BTGError -> a
          catchAll privateReq err =
            case privateReq of
              PrivateRequest_Logout ->
                Left err
              PrivateRequest_Validate ->
                Left err
              PrivateRequest_DeleteAccount _ ->
                Left err
              PrivateRequest_InviteUser _ ->
                Left err
              PrivateRequest_ChangeUserRole _ _ _ ->
                Left err
              PrivateRequest_ChangePassword _ _ _ ->
                Left err
              PrivateRequest_New2FASecret ->
                Left err
              PrivateRequest_Set2FASecret _ _ ->
                Left err
              PrivateRequest_CreateTokenInfo _ _ _ ->
                Left err
              PrivateRequest_DeleteTokenInfo ->
                Left err
              PrivateRequest_UpdateSigningInfo _ ->
                Left err
              PrivateRequest_SeeGasWalletBalance ->
                Left err
              PrivateRequest_GetMintCap _ ->
                Left err
              PrivateRequest_AddPendingOperations _ ->
                Left err
              PrivateRequest_AddOperationSignatures _ _ ->
                Left err
              PrivateRequest_DismissOperations _ ->
                Left err
              PrivateRequest_CancelOperation _ ->
                Left err
              PrivateRequest_GetPaused _ ->
                Left err
              PrivateRequest_CheckWhitelist _ ->
                Left err
              PrivateRequest_CheckWhitelistBatch _ ->
                Left err
              PrivateRequest_GetTokenHolderBalance _ ->
                Left err

-- ACCOUNT
loginHandler
  :: (MonadIO m, MonadSign m, PersistBackend m, SqlDb (PhantomDb m))
  => Email -> SecureMem -> Maybe Word32 -> m (BTGResponse LoginResponse)
loginHandler email pw maybeOtp = do
  startTime <- getTime
  res <- loginSM (\aid -> sign (AuthToken (Identity aid), startTime)) email pw
  case res of
    Nothing -> return $ Left $ BTGError_AuthError "Login failed"
    Just authToken -> do
      Just (AuthToken (Identity accountId), _) <- readSigned authToken
      activeUser <- isActiveUser accountId
      if activeUser
        then do
          hasTwoFactorAuth <- not . null <$> select (TwoFactorInfo_accountField ==. accountId)
          case (hasTwoFactorAuth, maybeOtp) of
            (True, Just otp) -> do
              checkOTPResult <- check2FAOneTimePassword accountId otp
              case checkOTPResult of
                Right _ -> do
                  loginSession <- createLoginSession accountId authToken
                  return $ Right loginSession
                Left err ->
                  return $ Left err
            (True, Nothing) ->
              return $ Left BTGError_RequiresTwoFactorAuth

            (False, _) -> do
              loginSession <- createLoginSession accountId authToken
              return $ Right loginSession

        else
          return $ Left $ BTGError_AuthError "Login failed"


haveIBeenPwnedSM :: MonadPwned m => SecureMem -> m HaveIBeenPwnedResult
haveIBeenPwnedSM = haveIBeenPwned . secureMemToText

createAccountHandler
  :: (PersistBackend m, MonadIO m, MonadSign m, MonadLogger m)
  => Signed (PasswordResetToken Identity) -> Text -> SecureMem -> Manager -> EmailAddress -> m (Either BTGError LoginResponse)
createAccountHandler passwordResetToken name pw httpManager firstAdminEmail = do
  prt <- readSigned passwordResetToken
  case prt of
    Just (PasswordResetToken (Identity _, nonce)) -> do
      pwnedResult <- runPwnedT (haveIBeenPwnedSM pw) $ HaveIBeenPwnedConfig
        { _haveIBeenPwnedConfig_manager = httpManager
        , _haveIBeenPwnedConfig_apihost = haveIBeenPwnedApiHost
        }
      case pwnedResult of
        HaveIBeenPwnedResult_Disclosed 0 -> do
          res <- createAccount nonce
          case res of
            Just aid -> do
              startTime <- getTime
              authToken <- sign (AuthToken (Identity aid), startTime)
              loginResponse <- createLoginSession aid authToken
              return $ Right loginResponse
            Nothing ->
              return $ Left $ BTGError_AuthError "Invalid invite token."
        HaveIBeenPwnedResult_Disclosed _ -> return $ Left $ BTGError_AuthError "Your New Password has been found in a database of compromised passwords. Please use a different password."
        HaveIBeenPwnedResult_ApiError -> return $ Left $ BTGError_AuthError "HaveIBeenPwned password check failure. Please try again later."
    Nothing ->
      return $ Left $ BTGError_AuthError "Invalid account."
  where
    createAccount nonce = do
      result <- listToMaybe <$> project (AutoKeyField, AccountConstructor) (Account_passwordResetNonceField ==. Just nonce)
      case result of
        Just (accountKey, account) -> do
          let accountId = toId accountKey
          setAccountPassword accountId (secureMemToText pw)
          existingUser <- listToMaybe <$> project AutoKeyField (UserInfo_accountField ==. accountId)
          case existingUser of
            Just userKey ->
              void $ updateAndNotify (toId userKey :: Id UserInfo)
                [ UserInfo_nameField =. name
                , UserInfo_roleField =. Role_Auditor
                , UserInfo_signingInfoField =. (Nothing :: Maybe (Id SigningInfo))
                , UserInfo_deletedField =. Just False
                ]
            Nothing ->
              void $ insertAndNotify $ UserInfo
                { _userInfo_name = name
                , _userInfo_email = account_email account
                , _userInfo_account = accountId
                , _userInfo_role =
                    if account_email account == unEmailAddress firstAdminEmail
                      then Role_Admin
                      else Role_Auditor
                , _userInfo_signingInfo = Nothing
                , _userInfo_deleted = Just False
                }

          return $ Just accountId
        Nothing ->
          return Nothing

passwordResetHandler
  :: (PersistBackend m, MonadIO m, MonadSign m, MonadLogger m)
  => Signed (PasswordResetToken Identity) -> SecureMem -> Maybe Word32 -> Manager -> m (Either BTGError LoginResponse)
passwordResetHandler passwordResetToken password maybeOtp httpManager = do
  prt <- readSigned passwordResetToken
  case prt of
    Just (PasswordResetToken (Identity accountId, nonce)) -> do
      activeUser <- isActiveUser accountId
      case activeUser of
        True -> do
          pwnedResult <- runPwnedT (haveIBeenPwnedSM password) $ HaveIBeenPwnedConfig
            { _haveIBeenPwnedConfig_manager = httpManager
            , _haveIBeenPwnedConfig_apihost = haveIBeenPwnedApiHost
            }
          case pwnedResult of
            HaveIBeenPwnedResult_Disclosed 0 -> do
              hasTwoFactorAuth <- not . null <$> select (TwoFactorInfo_accountField ==. accountId)
              case (hasTwoFactorAuth, maybeOtp) of
                (True, Just otp) -> do
                  otpCheckResult <- check2FAOneTimePassword accountId otp
                  case otpCheckResult of
                    Right _ ->
                      attemptResetPassword accountId nonce
                    Left err ->
                      return $ Left err
                (True, Nothing) -> do
                  return $ Left BTGError_RequiresTwoFactorAuth
                (False, _) ->
                  attemptResetPassword accountId nonce
            HaveIBeenPwnedResult_Disclosed _ ->
              return $ Left $ BTGError_AuthError "Your New Password has been found in a database of compromised passwords. Please use a different password."
            HaveIBeenPwnedResult_ApiError ->
              return $ Left $ BTGError_AuthError "HaveIBeenPwned password check failure. Please try again later."
        _ -> pure $ Left $ BTGError_AuthError "Password Reset Failed"
    Nothing -> pure $ Left $ BTGError_AuthError "Could not read password reset token."
  where
    attemptResetPassword accountId nonce = do
      result <- resetPasswordSM accountId nonce password
      case result of
        Just _ -> do
          startTime <- getTime
          authToken <- sign (AuthToken (Identity accountId), startTime)
          clearLoginSessions accountId
          loginResponse <- createLoginSession accountId authToken
          return $ Right loginResponse
        Nothing ->
          return $ Left $ BTGError_AuthError $ "Nonce did not match when resetting password."

changePasswordHandler
  :: (PersistBackend m, MonadLogger m, MonadIO m)
  => (Id Account, UTCTime) -> SecureMem -> SecureMem -> Maybe Word32 -> Manager -> m (Either BTGError ())
changePasswordHandler (accId, loginSessionStartTime) oldPw newPw maybeOtp httpManager = do
  -- check if old password is correct
  check <- loginByAccountIdSM accId oldPw
  case check of
    Just _ -> do
      pwnedResult <- runPwnedT (haveIBeenPwnedSM newPw) $ HaveIBeenPwnedConfig
        { _haveIBeenPwnedConfig_manager = httpManager
        , _haveIBeenPwnedConfig_apihost = haveIBeenPwnedApiHost
        }
      case pwnedResult of
        HaveIBeenPwnedResult_Disclosed 0 -> do
          hasTwoFactorAuth <- not . null <$> select (TwoFactorInfo_accountField ==. accId)
          case (hasTwoFactorAuth, maybeOtp) of
            (True, Nothing) ->
              return $ Left BTGError_RequiresTwoFactorAuth
            (True, Just otp) -> do
              otpCheckResult <- check2FAOneTimePassword accId otp
              case otpCheckResult of
                Right _ -> do
                  setAccountPasswordSM accId newPw
                  clearLoginSessionsExcluding accId loginSessionStartTime
                  return $ Right ()
                Left err ->
                  return $ Left err
            (False, _) -> do
              setAccountPasswordSM accId newPw
              clearLoginSessionsExcluding accId loginSessionStartTime
              return $ Right ()
        HaveIBeenPwnedResult_Disclosed _ ->
          return $ Left $ BTGError_AuthError "Your New Password has been found in a database of compromised passwords. Please use a different password."
        HaveIBeenPwnedResult_ApiError ->
          return $ Left $ BTGError_AuthError "HaveIBeenPwned password check failure. Please try again later."
    Nothing ->
      return $ Left $ BTGError_AuthError "Current Password is not correct."

new2FASecretHandler
  :: (MonadIO m, MonadSign m, PersistBackend m)
  => Id Account
  -> m (Either BTGError TwoFactorSecret)
new2FASecretHandler accountId = do
  mAccount <- get $ fromId accountId
  case mAccount of
    Nothing -> error "Couldn't get account"
    Just account -> do
      rng <- liftIO $ getSystemDRG -- Might want to rate-limit this.
      let (secret', _) = randomBytesGenerate 10 rng
          secret = toSecureMem @BS.ByteString secret'
      secretMAC <- sign $ TwoFactorMAC secret accountId
      let secretB32 = (B32.toText . B32.fromBytes) secret'
          secretIssuerAndEmail = fromMaybe [URI.pathPiece|"btg-tdb:unknown-user"|] $ URI.mkPathPiece $ "btg-tdb:" <> account_email account
          secretB32QueryValue = fromMaybe (error "base32 data not valid for URI?") $ URI.mkQueryValue secretB32
      let secretURI = URI.render $ URI.URI
            { URI.uriScheme = Just [URI.scheme|otpauth|]
            , URI.uriAuthority = Right $ URI.Authority
                { URI.authUserInfo = Nothing
                , URI.authHost = [URI.host|totp|]
                , URI.authPort = Nothing
                }
            , URI.uriPath = Just (False, pure $ secretIssuerAndEmail)
            , URI.uriQuery =
                [ URI.QueryParam [URI.queryKey|secret|] secretB32QueryValue
                , URI.QueryParam [URI.queryKey|issuer|] [URI.queryValue|btg-tdb|]
                ]
            , URI.uriFragment = Nothing
            }
          secretQR = fromMaybe (error "QR code encoding failed?") $ QR.toPngDataUrlT 4 4 <$> QR.encodeText (QR.defaultQRCodeOptions QR.L) QR.Iso8859_1 secretURI
      return $ Right TwoFactorSecret
        { _twoFactorSecret_Secret = textToSecureMem secretB32
        , _twoFactorSecret_QR = T.toStrict secretQR
        , _twoFactorSecret_MAC = secretMAC
        }

set2FASecretHandler
  :: (MonadIO m, MonadSign m, PersistBackend m)
  => Id Account
  -> Signed TwoFactorMAC
  -> Word32
  -> m (Either BTGError ())
set2FASecretHandler accountId twoFactorToken currentOTP = do
  otpTime <- liftIO $ floor <$> getPOSIXTime
  mToken <- readSigned twoFactorToken
  case mToken of
    Nothing -> return $ Left $ BTGError_UserError "Bad token during 2FA setup"
    Just (TwoFactorMAC binSK uid) ->
      if uid == accountId
        then do
          -- Checking current and last so we don't have weird gaps where we couldn't send one and succeed.
          if OTP.totpVerify OTP.defaultTOTPParams (toBytes binSK) otpTime currentOTP
            then do
              delete $ TwoFactorInfo_accountField ==. accountId
              _ <- insertAndNotify $ TwoFactorInfo accountId $ toBytes binSK
              return $ Right ()
            else return $ Left $ BTGError_UserError "6-digit 2FA code is incorrect."
        else return $ Left $ BTGError_AuthError "Attempting to set a different user's 2FA key"

check2FAOneTimePassword
  :: (MonadIO m, PersistBackend m)
  => Id Account -> Word32 -> m (BTGResponse ())
check2FAOneTimePassword accountId otpInput = do
  maybeTwoFactorInfo <- listToMaybe <$> select (TwoFactorInfo_accountField ==. accountId)
  case maybeTwoFactorInfo of
    Just twoFactorInfo -> do
      otpTime <- liftIO $ floor <$> getPOSIXTime
      if OTP.totpVerify OTP.defaultTOTPParams (_twoFactorInfo_secret twoFactorInfo) otpTime otpInput
        then return $ Right ()
        else return $ Left $ BTGError_UserError "6-digit 2FA code is incorrect."
    Nothing ->
      return $ Left $ BTGError_UserError "User does not have 2FA setup"

passwordResetEmailHandler
  :: (MonadIO m, MonadSign m, PersistBackend m, MonadEmail m, SqlDb (PhantomDb m))
  => Text -> Email -> m (Either a ())
passwordResetEmailHandler baseUrl email = do
    maybeAid <- fmap (listToMaybe . fmap toId) $ project AutoKeyField (lower Account_emailField ==. email)
    case maybeAid of
      Nothing -> return $ Right () -- No error so we only leak that this isn't an account via timing attack.
      Just aid -> do
        nonce <- getTime
        token <- generatePasswordResetTokenFromNonce (Identity aid) nonce
        void $ update [Account_passwordResetNonceField =. Just nonce] $ AutoKeyField ==. fromId aid
        fmap Right $ sendWidgetEmailFrom emailCfg (pure email) "Password reset request" Nothing $ buildPasswordResetEmail emailCSS token
  where
    emailCfg = WidgetEmailCfg "" "" baseUrl checkedRouteEncoder

-- USER
inviteFirstAdmin :: (MonadIO m, MonadCatch m, PersistBackend m, SqlDb (PhantomDb m)) => Config -> m ()
inviteFirstAdmin cfg = do
  maybeFirstAdminUser <- listToMaybe <$> project AutoKeyField (UserInfo_emailField ==. unEmailAddress (cfg ^. config_firstAdminEmail))
  case maybeFirstAdminUser of
    Just _ ->
      return ()
    Nothing -> handle (\(ex :: IOException) -> liftIO $ putStrLn ("Invite email for first admin failed: " <> show ex)) $
      flip runSignT (cfg ^. config_clientSessionKey) $
        sendInviteEmail (cfg ^. config_firstAdminEmail) (cfg ^. config_baseUrl) (cfg ^. config_emailEnv)

sendInviteEmail
  :: (MonadIO m, MonadSign m, PersistBackend m, SqlDb (PhantomDb m))
  => EmailAddress -> Text -> EmailEnv -> m ()
sendInviteEmail email baseUrl emailEnv = do
  nonce <- getTime
  (_, account) <- createPendingAccount nonce
  inviteToken <- sign $ PasswordResetToken (Identity account, nonce)
  runEmailT (sendTokenDashboardEmail inviteToken) emailEnv
  where
    sendTokenDashboardEmail inviteToken =
      let emailCfg = WidgetEmailCfg "" "" baseUrl checkedRouteEncoder
      in sendWidgetEmailFrom emailCfg (pure $ unEmailAddress email) "You've been invited to the Tezos Token Dashboard" Nothing $ buildUserInviteEmail emailCSS inviteToken
    createPendingAccount nonce = do
      (_,acc) <- ensureAccountExists Notification_Account $ unEmailAddress email
      update
        [ Account_passwordResetNonceField =. Just nonce]
        (AutoKeyField ==. fromId acc)
      pure (True, acc)

inviteUserHandler
  :: (MonadIO m, MonadSign m, PersistBackend m, SqlDb (PhantomDb m))
  => Id Account -> EmailAddress -> Text -> EmailEnv -> m (BTGResponse ())
inviteUserHandler requesterId email baseUrl emailEnv = do
  mRequesterRole <- listToMaybe <$> project UserInfo_roleField (UserInfo_accountField ==. requesterId)
  case mRequesterRole of
    Nothing -> return $ Left $ BTGError_UserError $ "User attempting to invite another user does not exist."
    Just requesterRole -> case requesterRole of
      Role_Auditor -> return $ Left $ BTGError_UserError $ "User does not have permission to invite users."
      Role_Admin -> do
        existing <- select $ UserInfo_emailField ==. unEmailAddress email &&. UserInfo_deletedField ==. Just False
        case existing of
          [] ->
            Right <$> sendInviteEmail email baseUrl emailEnv
          _ ->
            return $ Left $ BTGError_UserError "An account with this email address already exists."



deleteAccountHandler
  :: (Monad m, PersistBackend m)
  => Id Account -> Id UserInfo -> m (BTGResponse ())
deleteAccountHandler accId uid = do
  mTargetAccId <- listToMaybe <$> project UserInfo_accountField (AutoKeyField ==. fromId uid)
  mRequesterRole <- listToMaybe <$> project UserInfo_roleField (UserInfo_accountField ==. accId)
  case (mTargetAccId, mRequesterRole) of
    (Nothing, _) -> return $ Left $ BTGError_AuthError $ "Targeted user for deletion does not exist"
    (_, Nothing)-> return $ Left $ BTGError_AuthError $ "Requesting user for deletion does not exist"
    (Just targetAccId, Just requestingRole) -> if (targetAccId == accId || requestingRole /= Role_Admin)
      then return $ Left $ BTGError_AuthError $ "User is not authorized to delete this user"
      else do
        updateAndNotify uid [ UserInfo_deletedField =. Just True, UserInfo_signingInfoField =. (Nothing :: Maybe (Id SigningInfo)) ]
        maybeTwoFactorInfoKey <- listToMaybe <$> project AutoKeyField (TwoFactorInfo_accountField ==. accId)
        for_ maybeTwoFactorInfoKey $ \twoFactorInfoKey -> deleteAndNotify (toId twoFactorInfoKey :: Id TwoFactorInfo)
        return $ Right ()

changeUserRoleHandler
  :: (Monad m, PersistBackend m, MonadIO m)
  => Id Account -> Id UserInfo -> Role -> Maybe Word32-> m (BTGResponse ())
changeUserRoleHandler accId uid role mOtp = do
  mTargetAccId <- listToMaybe <$> project UserInfo_accountField (AutoKeyField ==. fromId uid)
  mRequesterRole <- listToMaybe <$> project UserInfo_roleField (UserInfo_accountField ==. accId)
  hasTwoFactorAuth <- not . null <$> select (TwoFactorInfo_accountField ==. accId)
  case (hasTwoFactorAuth, mOtp) of
    (True, Just otp) -> do
      otpCheckResult <- check2FAOneTimePassword accId otp
      case otpCheckResult of
        Right _ -> changeUserRole mTargetAccId mRequesterRole
        Left err -> return $ Left err
    (True, Nothing) ->
      return $ Left BTGError_RequiresTwoFactorAuth
    (False, _) -> changeUserRole mTargetAccId mRequesterRole
  where
    changeUserRole mTargetAccId mRequesterRole = case (mTargetAccId, mRequesterRole) of
      (Nothing, _)-> return $ Left $ BTGError_AuthError $ "Targeted user for role change does not exist"
      (_, Nothing)-> return $ Left $ BTGError_AuthError $ "Requesting user for role change does not exist"
      (Just targetAccId, Just requestingRole) ->
        if (targetAccId == accId || requestingRole /= Role_Admin)
          then return $ Left $ BTGError_AuthError $ "User is not authorized to change this role"
          else do
            updateAndNotify uid [UserInfo_roleField =. role]
            return $ Right ()

-- TOKEN
createTokenInfoHandler
  :: (PersistBackend m, HasPublicNodeContext s, MonadIO m, MonadLogger m)
  => Text -> Text -> Text -> PublicKeyHash -> ContractId -> s -> m (Either BTGError ())
createTokenInfoHandler name tickerSymbol tokenAddress gasWallet targetContract tezosPublicNodeContext = do
  case tryReadContractIdText $ T.strip tokenAddress of
    Right contractId -> do
      account <- runReaderT (runExceptT $ getContract contractId) tezosPublicNodeContext
      case account of
        Right contractAccount -> do
          adminContractId <- runReaderT (runExceptT $ getAdministratorFromContract gasWallet contractId targetContract) tezosPublicNodeContext
          case adminContractId of
            Right (Right multiSigAddress) -> do
              storageResult <- runReaderT (runExceptT $ getWrapperContractStorage $ WrapperContractId multiSigAddress) tezosPublicNodeContext
              case storageResult of
                Right (Just storage) -> do
                  updateAuthorizedKeys $ _wrapperContractStorage_allowedSigningKeys storage
                  _ <- insertAndNotify $ TokenInfo
                    { _tokenInfo_name = name
                    , _tokenInfo_tickerSymbol = tickerSymbol
                    , _tokenInfo_contractAddress = contractId
                    , _tokenInfo_multiSignatureContractAddress = multiSigAddress
                    , _tokenInfo_contractScript = _account_script contractAccount
                    }
                  return $ Right ()
                Right Nothing ->
                  return $ Left nonExistenceError
                Left (_ :: RpcError) ->
                  return $ Left $ BTGError_UserError "Error retrieving allowed signing keys from token administration contract."
            Left (err ::RpcError) -> do
              $(logErrorS) "TOKEN" $ T.pack $ show $ err
              return $ Left $ BTGError_UserError "RPC error getting token administration contract address."
            Right (Left _) ->
              return $ Left $ BTGError_UserError "Error reading token administration contract address."
        Left (_ :: RpcError) ->
          return $ Left nonExistenceError
    Left _ -> do
      return $ Left $ BTGError_UserError "Error reading contract address."
    where
      nonExistenceError = BTGError_UserError "No contract exists at the provided Token Contract Address."

getOnChainCounter
  :: (PersistBackend m, HasPublicNodeContext s, MonadIO m, MonadLogger m)
  => s -> ContractId -> m Int
getOnChainCounter tezosPublicNodeContext multiSigAddress = do
    multisigStorageResult <- runReaderT (runExceptT $ getWrapperContractStorage $ WrapperContractId multiSigAddress) tezosPublicNodeContext
    case multisigStorageResult of
      Right (Just storage) -> do
        return $ fromIntegral $ _wrapperContractStorage_storedCounter storage
      Right Nothing -> do
        $(logErrorS) "TOKEN" "Multisig contract storage not found."
        error "Multisig contract storage not found."
      Left (err :: RpcError) -> do
        $(logErrorS) "TOKEN" $ "Error retrieving multisig contract storage: " <> T.pack (show err)
        error "Multisig contract storage not found."

-- HELPERS
isActiveUser :: PersistBackend m  => Id Account -> m Bool
isActiveUser aid = do
  results <- select $ UserInfo_accountField ==. aid &&. UserInfo_deletedField /=. Just True
  return $ length results > 0

createLoginSession :: (MonadIO m, PersistBackend m, MonadSign m) => Id Account -> AppCredential BTG -> m LoginResponse
createLoginSession aid authToken = do
  Just (_, startTime) <- readSigned authToken
  _ <- insert $ LoginSession
    { _loginSession_account = aid
    , _loginSession_startTime = startTime
    }
  userInfo:_ <- select $ UserInfo_accountField ==. aid
  return $ LoginResponse authToken userInfo

clearLoginSessions :: PersistBackend m => Id Account -> m ()
clearLoginSessions accId = do
  loginSessions <- project AutoKeyField $ LoginSession_accountField ==. accId
  traverse_ deleteAndNotify $ toId <$> loginSessions

clearLoginSessionsExcluding :: PersistBackend m => Id Account -> UTCTime -> m ()
clearLoginSessionsExcluding accId startTime = do
  loginSessions <- project AutoKeyField $
    LoginSession_accountField ==. accId &&.
    LoginSession_startTimeField /=. startTime
  traverse_ deleteAndNotify $ toId <$> loginSessions

addAccount :: (PersistBackend m, SqlDb (PhantomDb m), MonadIO m) => Text -> Text -> m ()
addAccount email name = do
  (isNew,acc) <- ensureAccountExists Notification_Account email
  case isNew of
    True -> do
      let defUserInfo = UserInfo
            { _userInfo_name = name
            , _userInfo_email = email
            , _userInfo_account = acc
            , _userInfo_role = Role_Admin
            , _userInfo_signingInfo = Nothing
            , _userInfo_deleted = Just False
            }
      _ <- insert defUserInfo
      setAccountPassword acc "asdf"
    False -> do
      update [UserInfo_roleField =. Role_Admin] (UserInfo_accountField ==. acc)
      setAccountPassword acc "asdf"
      return ()

checkForExistingOperation
  :: PersistBackend m => TokenOperation -> m (Maybe (Id PendingOperation, PendingOperation))
checkForExistingOperation operation = do
  pendingOps <- project (AutoKeyField, PendingOperation_operationField) $ PendingOperation_dismissedField /=. Just True
  let existingPendingOp = List.find (\(_, pendingOp) -> (viewTokenOperation $ _wrappedCall_payload pendingOp) == Just operation) pendingOps
  case existingPendingOp of
    Just (pendingOpId, _) -> do
      Just pendingOp <- get pendingOpId
      return $ Just (toId pendingOpId, pendingOp)
    Nothing ->
      return Nothing

queryReadyOperations
  :: (MonadIO m, MonadLogger m, PersistBackend m)
  => m [(Id PendingOperation, [OperationSignature])]
queryReadyOperations = do
  (headWaitingOperation:subsequentWaitingOps) <- getWaitingOperations

  $(logDebugS) "TOKEN" $ "queryReadyOperations: headWaitingOperation is " <> T.pack (show headWaitingOperation)

  previousOperationStatus <- getPreviousOperationStatus $ snd headWaitingOperation
  case previousOperationStatus of
    Nothing ->
      getSignatures (toId $ fst headWaitingOperation) subsequentWaitingOps
    Just PendingOperationStatus_Sent ->
      getSignatures (toId $ fst headWaitingOperation) subsequentWaitingOps
    Just _status ->
      return []

  where
    getWaitingOperations =
      project (AutoKeyField, PendingOperation_operationField ~> WrappedCall_counterSelector)
        ((PendingOperation_statusField ==. PendingOperationStatus_Waiting
          &&. PendingOperation_dismissedField ==. Just False)
            `orderBy` [Asc (PendingOperation_operationField ~> WrappedCall_counterSelector)])

    getPreviousOperationStatus counter = listToMaybe <$>
      project (PendingOperation_statusField)
        ((PendingOperation_operationField ~> WrappedCall_counterSelector ==. counter - 1
          &&. PendingOperation_dismissedField ==. Just False))

    getSignatures headOpId subsequentWaitingOps = do
      headOperationSignatures <- getSignaturesForPendingOperation headOpId
      readyPendingOps <- getSignaturesForSubsequentOperations subsequentWaitingOps
      return $ headOperationSignatures:(takeJusts readyPendingOps)

    getSignaturesForSubsequentOperations ops =
      for ops $ \(pendingOpKey, counter) -> do
        previousOperationStatus <- getPreviousOperationStatus counter
        $(logDebugS) "TOKEN" $ "queryReadyOperations: previousOperationStatus is " <> T.pack (show previousOperationStatus)
        case previousOperationStatus of
          Nothing ->
            Just <$> getSignaturesForPendingOperation (toId pendingOpKey)
          Just PendingOperationStatus_Sent ->
            Just <$> getSignaturesForPendingOperation (toId pendingOpKey)
          Just PendingOperationStatus_Waiting ->
            Just <$> getSignaturesForPendingOperation (toId pendingOpKey)
          Just _status ->
            return Nothing

    getSignaturesForPendingOperation pendingOpId = do
      readyOpSignatures <- select $ OperationSignature_pendingOperationField ==. pendingOpId
      return (pendingOpId, readyOpSignatures)

    takeJusts ((Just x):xs) = x:(takeJusts xs)
    takeJusts (Nothing:_) = []
    takeJusts [] = []

getNextGasWalletCounter
  :: ( PersistBackend m
     , MonadIO m
     , MonadLogger m
     , MonadReader s m
     , HasPublicNodeContext s
     , MonadError e m
     , AsRpcError e)
  => PublicKeyHash
  -> m TezosWord64
getNextGasWalletCounter gasWallet = fmap succ $ max
  <$> getGasWalletCounterOnChain gasWallet
  <*> (fromIntegral . fromMaybe 0 . headMay <$> lastSentQuery)
  where
  lastSentQuery = project SentOperation_gasWalletCounterField $
    CondEmpty `orderBy` [Desc SentOperation_gasWalletCounterField] `limitTo` 1

-- recursively process and send ready operations
-- Needs a locking mechanism.

recursivelyProcessReadyOperations
  :: (MonadIO m, PersistBackend m, MonadLogger m, MonadError BTGError m)
  => Config
  -> [(Id PendingOperation, [OperationSignature])]
  -> m [OperationHash]
recursivelyProcessReadyOperations _ [] = return []
recursivelyProcessReadyOperations cfg readyOperations = do
  result <- listToMaybe <$> project TokenInfo_multiSignatureContractAddressField (TokenInfo_nameField ==. tokenName)
  case result of
    Just multiSignatureContractId -> do
      -- Set this batch to preparing to send.
      -- Need to also implement some kind of locking here so a second entry here won't fail. (Need to make sure this transaction happens before we stop, too). This might need to become a worker of some sort.
      sequence_ $ flip updateAndNotify [PendingOperation_statusField =. PendingOperationStatus_PreparingToSend] . fst <$> readyOperations
      pendingOperations <- sequence $ get . fromId . fst <$> readyOperations
      Right (Just wrapperContractStorage) <- runRPCCall (cfg ^. config_publicNodeContext) $ getWrapperContractStorage $ WrapperContractId multiSignatureContractId
      let operations =  _pendingOperation_operation . fromJust <$> pendingOperations
      let signatures sigs = alignSignaturesWithSigningKeys sigs (toList $ _wrapperContractStorage_allowedSigningKeys wrapperContractStorage)
      let msCalls = zipWith WrappedCallWithSignatures operations $ signatures . snd <$> readyOperations
      let octs = endpointCallToOpContentsTransaction multiSignatureContractId <$> msCalls
      Right (succeeds, fails) <- runRPCCall (cfg ^. config_publicNodeContext) $ sendTransactions (cfg ^. config_gasWallet) Seq.empty $ Seq.fromList octs

      sequence_ $ flip updateAndNotify [PendingOperation_statusField =. PendingOperationStatus_Sent] . fst <$> take (length succeeds) readyOperations

      sequence_ $ insert <$> zipWith (flip SentOperation $ -1) (toList succeeds) (fst <$> readyOperations)

      sequence_ $ flip updateAndNotify [PendingOperation_statusField =. PendingOperationStatus_OperationFailed] . fst <$> drop (length succeeds) readyOperations

      case headMay $ drop (length succeeds) readyOperations of
        Just firstFailed -> void $ dismissSubsequentOperations $ fst $ firstFailed
        Nothing -> return ()

      -- Update cached list of authorized signers if a reconfig operation was successfully injected
      for_ (_wrappedCall_payload <$> take (length succeeds) operations) $ \case
        WrappedPayload_Reconfig _ signers ->
          updateAuthorizedKeys $ fst <$> signers
        _ ->
          return ()

      case toList fails of 
        [] -> 
          return $ toList succeeds
        firstFailure:_ -> 
          throwError $ BTGError_UserError $ T.pack $ show firstFailure
    Nothing ->
      throwError $ BTGError_UserError "Invalid pending operation state."

dismissSubsequentOperations
  :: (PersistBackend m)
  => Id PendingOperation -> m (BTGResponse ())
dismissSubsequentOperations pendingOpId = do
  maybeOpCounter <- fmap (_wrappedCall_counter . _pendingOperation_operation) <$> get (fromId pendingOpId)
  case maybeOpCounter of
    Nothing -> return $ Left $ BTGError_UserError "Could not retrieve operation counter to cancel." -- Shouldn't happen?
    Just thisOpCounter -> do
      subsequentPendingOpIds <- project AutoKeyField (PendingOperation_dismissedField ==. Just False &&. PendingOperation_operationField ~> WrappedCall_counterSelector >. thisOpCounter)
      _ <- traverse (\subsequentPendingOpId -> updateAndNotify (toId subsequentPendingOpId :: Id PendingOperation) [PendingOperation_dismissedField =. (Just True)]) subsequentPendingOpIds
      return $ Right ()

getAuthorizedKeys :: (MonadIO m, PersistBackend m) => m [(PublicKey, PublicKeyHash)]
getAuthorizedKeys = do 
  maybeAuthorizedKeys <- listToMaybe <$> project AuthorizedKeys_publicKeysField (AuthorizedKeys_activeField ==. True)
  case maybeAuthorizedKeys of 
    Just authorizedKeys ->
      return authorizedKeys
    Nothing -> 
      return []

addAuthorizedKeys :: (MonadIO m, MonadLogger m, PersistBackend m) => Config -> m ()
addAuthorizedKeys cfg = do
  maybeAuthorizedKeys <- listToMaybe <$> project AutoKeyField (AuthorizedKeys_activeField ==. True)
  case maybeAuthorizedKeys of
    Nothing -> do
      maybeMultisigAddress <- listToMaybe <$> project TokenInfo_multiSignatureContractAddressField (TokenInfo_nameField ==. tokenName)
      case maybeMultisigAddress of
        Just multiSigAddress -> do
          storageResult <- runRPCCall (cfg ^. config_publicNodeContext) $ getWrapperContractStorage $ WrapperContractId multiSigAddress
          case storageResult of
            Right (Just storage) ->
              updateAuthorizedKeys $ _wrapperContractStorage_allowedSigningKeys storage
            _ ->
              return ()
        Nothing ->
          return ()
    Just _ ->
      return ()

updateAuthorizedKeys :: (Functor f, Foldable f, PersistBackend m) => f PublicKey -> m ()
updateAuthorizedKeys newKeys = do
  currentTime <- getTime
  update [AuthorizedKeys_activeField =. False] $ AuthorizedKeys_activeField ==. True
  void $ insertAndNotify $ AuthorizedKeys
    { _authorizedKeys_timestamp = currentTime
    , _authorizedKeys_publicKeys = toList $ fmap (\newKey -> (newKey, toPublicKeyHash newKey)) newKeys
    , _authorizedKeys_active = True
    }
