# BTG Pactual - ReitBZ Admin Dashboard

## Nix
Building the dashboard requires the [Nix](https://nixos.org/nix/) Package Manager, which you can install on any Linux distribution or MacOS.


## Setting up Nix caching (Recommended)

If you have not already, we recommend you setup Nix caching to significantly reduce your build times.

### NixOS

If you are running NixOS, add this to `/etc/nixos/configuration.nix`:

```
nix.binaryCaches = [
  "https://cache.nixos.org/"
  "https://nixcache.reflex-frp.org"
  "https://s3.eu-west-3.amazonaws.com/tezos-nix-cache"
];

nix.binaryCachePublicKeys = [ "ryantrinkle.com-1:JJiAKaRv9mWgpVAz8dwewnZe0AzzEAzPkagE9SP5NWI=" "obsidian-tezos-kiln:WlSLNxlnEAdYvrwzxmNMTMrheSniCg6O4EhqCHsMvvo=" ];
```

### Linux or MacOS

Include these lines in `/etc/nix/nix.conf`. If the nix directory or `nix.conf` file do not yet exist then you will need to create them.

```
substituters = https://cache.nixos.org https://nixcache.reflex-frp.org https://s3.eu-west-3.amazonaws.com/tezos-nix-cache

trusted-public-keys = cache.nixos.org-1:6NCHdD59X431o0gWypbMrAURkbJ16ZPMQFGspcDShjY= ryantrinkle.com-1:JJiAKaRv9mWgpVAz8dwewnZe0AzzEAzPkagE9SP5NWI= obsidian-tezos-kiln:WlSLNxlnEAdYvrwzxmNMTMrheSniCg6O4EhqCHsMvvo=
```

If you are using **Linux** then enable sandboxing by adding this line to the `nix.conf` file

```
sandbox = true
```

But if you are using **MacOS** then you will need to disable sandboxing and then restart the nix daemon. Add this line to the `nix.conf` file to disable sandboxing

```
sandbox = false
```

Use these commands to restart the nix daemon:

```
sudo launchctl stop org.nixos.nix-daemon
sudo launchctl start org.nixos.nix-daemon
```

## Obelisk
This project was built using [obelisk](https://github.com/obsidiansystems/obelisk). Command line programs prefixed with `ob` are part of the obelisk set of commands. See the [obelisk README.md](https://github.com/obsidiansystems/obelisk/blob/develop/README.md) for more information on installing obelisk.

## Running a local mail server

To access the application, you'll need to receive an email sent to the address configured at `config/backend/first-admin-email`, which you can use to set up the first admin account. You can run a local mailserver for receiving this email with:

```bash
nix-shell -p mailcatcher --run "mailcatcher -f"
```

The inbox should then be accessible at http://localhost:1080.

## Configuration
There are a number of configuration variables that can be set in the `config` directory.

#### gas-wallet-pkh
The public key hash of the account that the backend sends all Tezos operations with.

#### gas-wallet-sk
Can either be the actual secret key of the gas wallet in plaintext, or a proxy taking the form:
```
  {
    "url": "<url of the proxy endpoint>",
    "apiKey": "<api key>"
  }
```
#### tezos-node-uri
The uri of the Tezos node used for RPCs.

#### first-admin-email
The email address of the initial administrator.

#### email
A list of arguments that are used to configure the email server.

1. host name
1. SMTP protocol (options are "SMTPProtocol_Plain", "SMTPProtocol_SSL", or "SMTPProtocol_STARTTLS")
1. port number
1. user name
1. password


For example:
```
["127.0.0.1","SMTPProtocol_Plain",1025,"admin","password"]
```

#### conseil-uri
The uri of the Conseil instance used for retrieving past operations against the contract. Since a single Conseil instance support multiple networks, the network must also be specified in the path. Note that this means it needs to be kept in synch with the RPC node configured in `tezos-node-uri`.

For example:
```
https://conseil-dev.cryptonomic-infra.tech/v2/data/tezos/babylonnet
```

#### conseil-api-key
The authorization key used to access the Conseil API.

#### result-receiver-contract-for-address
To call view endpoints on the token contract, there needs to be a proxy contract deployed on the network whose storage type matches the return type of the endpoint. See [tzip](https://gitlab.com/tzip/tzip/blob/master/A/A1.md) for more information.

The address as shipped refers to a contract on babylonnet.  If you don't already have a contract set up for this purpose on the network you will be
running on, you can deploy one like this:

```bash
tezos-client -A obsidian.webhop.org -P 9142 originate contract address-target transferring 0 from btg-dev running '{ parameter address ; storage address; code { CAR ; NIL operation ; PAIR } }' --init '"tz1WRR3xUv752YyLJVhobMXQ86KkRuF1Uxw8"' --burn-cap 0.4
```

#### result-receiver-contract-for-nat
To call view endpoints on the token contract, there needs to be a proxy contract deployed on the network whose storage type matches the return type of the endpoint. See [tzip](https://gitlab.com/tzip/tzip/blob/master/A/A1.md) for more information.

The address as shipped refers to a contract on babylonnet.  If you don't already have a contract set up for this purpose on the network you will be
running on, you can deploy one like this:

```bash
tezos-client -A obsidian.webhop.org -P 9142 originate contract nat-target transferring 0 from btg-dev running '{ parameter nat ; storage nat; code { CAR ; NIL operation ; PAIR } }' --init 0 --burn-cap 0.3
```

## Building and running the docker image

### Building:

To build:

```bash
nix-build release.nix -A docker-image
```

To build and load directly into docker:

```bash
docker load < $(nix-build release.nix -A docker-image --no-out-link)
```

### Running:

After loading, you need a secrets directory containing certificate.pem, key.pem, conseil-api-key, and gas-wallet-sk, which will
also be provided to the backend as Obelisk configs:

```bash
# Directory
mkdir secrets

# If you already have a self-signed certificate for Obelisk development:
cp $HOME/.config/*.pem secrets

# If you don't already have a self-signed certificate:
openssl req -newkey rsa:2048 -new -nodes -x509 -days 365 -keyout secrets/key.pem -out secrets/certificate.pem

cp config/backend/{conseil-api-key,gas-wallet-sk} secrets

# Obelisk is strict when gathering configs, so key.pem needs to be readable by a different user even though it isn't actually
# used by the application
chmod 664 secrets/key.pem
```

Since the Docker image gets wiped whenever it is restarted and we can't do updates in place, an external Postgres instance needs
to be available instead of the standard Obelisk domain socket. On `NixOS`, this can be configured in `/etc/nixos/configuration.nix`
by adding:

```nix
services.postgresql = {
  enable = true;
  port = 5432;
  enableTCPIP = true;
  authentication = pkgs.lib.mkOverride 10 ''
    local all all trust
    host all all 0.0.0.0/0 trust
  '';
};
```

Then running `nixos-rebuild switch`. You can verify that the instance is running with `sudo su - postgres -c "psql"`.

The application can then be configured to use this instance by adding the connection string to `secrets/db`:

```bash
echo postgresql://postgres@127.0.0.1:5432 > secrets/db
```

And with that directory set up and the config-as-envs in this repo, you can run the docker image with:

```bash
docker run -p 4443:4443 --env-file=config-as-envs --net="host" --mount type=bind,source=$(pwd)/secrets,destination=/run/secrets,ro tezos-token-dashboard:latest
```

The dashboard should be available on https://localhost:4443.

If the browser does not accept the SSL certificate, go to chrome://flags/#allow-insecure-localhost and set the option to true, which will allow a self-signed certificate only on localhost.

Note: The secrets implementation should be compatible with docker secrets named certificate.pem and key.pem, but this has not been tested.

## Tezos Development

Note: The `tezos-client` executable is made available by running `ob shell`, which produces a nix-shell containing a tezos-client, in its path.

### Creating Tezos account

1. Go to the faucet to get an account/tez - https://faucet.tzalpha.net/
2. Activate that with: `tezos-client activate account <alias> with <file-path>.json`
3. Then you've got yourself an account!

### Multisig Contract Deployment

```bash
tezos-client originate contract multisig-wrapper transferring 0 from <account_alias> running <(btg multisig-wrapper) --init '(Pair 0 (Pair 3 <list_of_authorized_signing_keys>))' --burn-cap 10
```

**Example:**

```bash
tezos-client -A obsidian.webhop.org -P 9142 originate contract multisig-wrapper transferring 0 from btg-dev running <(btg multisig-wrapper) --init '(Pair 0 (Pair 3 { "edpkuWqQD7Pi57mFjw8QkMyFDRPXHvj6NM48LhiZR7u9LHdMb1M2V9"; "edpkvW78mHP3dt34VK2L7Wqv8QrCv6ggZ87WMoWDMZakXxVuMtUwLB"; "edpkuJUKcMkKhFLLz86i4vVxQ2qintHyHLkV3RiRLfJRw4thYxW8LG"; "sppk7ZL4yNx2KzYv8wxHXDJwuVwrwt6Q6agwbA5aFaCbM1yGHz5LzPz"; "p2pk66cd1R5VygNw8bzeGoysHh71CQyEmj8DDEdHuVN1xQDPWusPQN8" }))' --burn-cap 10
```

Record the contract address in the output as it will be needed when deploying the token contract.

### Token Contract Deployment

```
tezos-client originate contract <contract_alias> transferring 0 from <account_alias> running <(btg contract) --init "$(btg storage "$(tezos-client show known contract multisig-wrapper)")" --burn-cap <burn_cap>
```

**Example:**

```bash
tezos-client -A obsidian.webhop.org -P 9142 originate contract token transferring 0 from btg-dev running <(btg contract) --init "$(btg storage "$(tezos-client -A obsidian.webhop.org -P 9142 show known contract multisig-wrapper)")" --burn-cap 20
```

## Developers
For developers working on the project, you can run a local version of the app by running `ob run`. You should first setup up a local mail server as described above. You should also follow the instructions for creating secrets above, but place the `certificate.pem` and `key.pem` inside of `$HOME/.config/obelisk/`, so that the ob command can find them. You should then use the email sent to your mail server to begin the initial admin workflow.
