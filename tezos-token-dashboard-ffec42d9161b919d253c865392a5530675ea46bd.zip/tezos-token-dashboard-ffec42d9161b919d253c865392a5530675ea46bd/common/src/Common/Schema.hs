{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE TemplateHaskell #-}

module Common.Schema where

import Control.Lens
import Data.Aeson
import Data.ByteString
import Data.Text (Text)
import Data.Time
import Database.Id.Class
import GHC.Generics
import Rhyolite.Account
import Rhyolite.Schema
import Tezos.Common.Base58Check
import Tezos.Wrapped.Schema
import Tezos.V005.Contract
import Tezos.V005.Ledger
import Tezos.V005.PublicKey
import Tezos.V005.PublicKeyHash
import Tezos.V005.Signature

data Role = Role_Admin | Role_Auditor
  deriving (Eq, Ord, Show, Read, Generic)
instance ToJSON Role
instance FromJSON Role
instance ShowPretty Role where
  showPretty = \case
    Role_Admin -> "Admin"
    Role_Auditor -> "Auditor"

data UserInfo  = UserInfo
  { _userInfo_name :: Text
  , _userInfo_email :: Email
  , _userInfo_account :: Id Account
  , _userInfo_signingInfo :: Maybe (Id SigningInfo)
  , _userInfo_role :: Role
  , _userInfo_deleted :: Maybe Bool
  }
  deriving (Eq, Ord, Show, Generic)
instance HasId UserInfo
instance ToJSON UserInfo
instance FromJSON UserInfo

data UserInfoView  = UserInfoView
  { _userInfoView_name :: Text
  , _userInfoView_email :: Email
  , _userInfoView_account :: Id Account
  , _userInfoView_publicKeyHash :: Maybe PublicKeyHash
  , _userInfoView_role :: Role
  , _userInfoView_hasTwoFactorAuth :: Bool
  }
  deriving (Eq, Ord, Show, Generic)
instance ToJSON UserInfoView
instance FromJSON UserInfoView

data TwoFactorInfo = TwoFactorInfo
  { _twoFactorInfo_account :: Id Account
  , _twoFactorInfo_secret :: ByteString
  }
  deriving (Eq, Ord, Show, Generic)
instance HasId TwoFactorInfo

data SigningInfo = SigningInfo
  { _signingInfo_user :: Id UserInfo
  , _signingInfo_publicKeyHash :: PublicKeyHash
  , _signingInfo_publicKey :: PublicKey
  , _signingInfo_signingCurve :: SigningCurve
  , _signingInfo_derivationPath :: Text -- TODO: switch to Tezos.Ledger.DerivationPath
  }
  deriving (Eq, Ord, Show, Generic)
instance HasId SigningInfo
instance ToJSON SigningInfo
instance FromJSON SigningInfo

data TokenInfo = TokenInfo
  { _tokenInfo_name :: Text
  , _tokenInfo_tickerSymbol :: Text
  , _tokenInfo_contractAddress :: ContractId
  , _tokenInfo_multiSignatureContractAddress :: ContractId
  , _tokenInfo_contractScript :: Maybe ContractScript
  }
  deriving (Eq, Ord, Show, Generic)
instance HasId TokenInfo
instance ToJSON TokenInfo
instance FromJSON TokenInfo

makeLenses ''TokenInfo

data AuthorizedKeys = AuthorizedKeys
  { _authorizedKeys_timestamp :: UTCTime
  , _authorizedKeys_publicKeys :: [(PublicKey, PublicKeyHash)]
  , _authorizedKeys_active :: Bool
  }
  deriving (Eq, Ord, Show, Generic)
instance HasId AuthorizedKeys
instance ToJSON AuthorizedKeys
instance FromJSON AuthorizedKeys

data LoginSession = LoginSession
  { _loginSession_account :: Id Account
  , _loginSession_startTime :: UTCTime
  }
  deriving (Eq, Ord, Show, Generic)
instance HasId LoginSession

data PendingOperation = PendingOperation
  { _pendingOperation_operation :: WrappedCall
  , _pendingOperation_status :: PendingOperationStatus
  , _pendingOperation_dismissed :: Maybe Bool
  }
  deriving (Eq, Show, Ord, Generic)

instance HasId PendingOperation
instance ToJSON PendingOperation
instance FromJSON PendingOperation

data PendingOperationStatus
  = PendingOperationStatus_NeedsSignatures
  | PendingOperationStatus_Waiting
  | PendingOperationStatus_PreparingToSend
  | PendingOperationStatus_Sent
  | PendingOperationStatus_OperationFailed
  deriving (Eq, Ord, Show, Read, Generic)
instance ToJSON PendingOperationStatus
instance FromJSON PendingOperationStatus

makeLenses ''PendingOperation

data OperationSignature = OperationSignature
  { _operationSignature_pendingOperation :: Id PendingOperation
  , _operationSignature_signature :: Signature
  , _operationSignature_signingKey :: PublicKey
  } deriving (Eq, Ord, Show, Generic)

instance HasId OperationSignature
instance ToJSON OperationSignature
instance FromJSON OperationSignature

data PastOperation = PastOperation
  { _pastOperation_timestamp :: UTCTime
  , _pastOperation_parameters :: WrappedPayload
  , _pastOperation_hash :: OperationHash
  }
  deriving (Eq, Ord, Show, Generic)

instance HasId PastOperation
instance ToJSON PastOperation
instance FromJSON PastOperation

data SentOperation = SentOperation
  { _sentOperation_hash :: OperationHash
  , _sentOperation_gasWalletCounter :: Int
  , _sentOperation_pendingOp :: Id PendingOperation
  }
  deriving (Eq, Ord, Show, Generic)

instance HasId SentOperation
instance ToJSON SentOperation
instance FromJSON SentOperation
