{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE OverloadedStrings #-}

module Common.Route where

import Prelude hiding (id, (.))
import Control.Category

import Data.Text (Text)
import qualified Data.Text as T
import Data.Functor.Identity

import Obelisk.Route
import Obelisk.Route.TH
import Rhyolite.Account

data BackendRoute :: * -> * where
  -- | Used to handle unparseable routes.
  BackendRoute_Missing :: BackendRoute ()
  BackendRoute_Listen :: BackendRoute ()
  -- You can define any routes that will be handled specially by the backend here.
  -- i.e. These do not serve the frontend, but do something different, such as serving static files.

data FrontendRoute :: * -> * where
  FrontendRoute_Main :: FrontendRoute ()
  FrontendRoute_CreateAccount :: FrontendRoute (AccountRoute Identity)
  FrontendRoute_Token :: FrontendRoute ()
  FrontendRoute_UserManagement :: FrontendRoute ()
  FrontendRoute_ResetPassword :: FrontendRoute (AccountRoute Identity)
  FrontendRoute_Debug :: FrontendRoute ()

backendRouteEncoder
  :: Encoder (Either Text) Identity (R (FullRoute BackendRoute FrontendRoute)) PageName
backendRouteEncoder = handleEncoder (const (FullRoute_Backend BackendRoute_Missing :/ ())) $
  pathComponentEncoder $ \case
    FullRoute_Backend backendRoute -> case backendRoute of
      BackendRoute_Missing -> PathSegment "missing" $ unitEncoder mempty
      BackendRoute_Listen -> PathSegment "listen" $ unitEncoder mempty
    FullRoute_Frontend obeliskRoute -> obeliskRouteSegment obeliskRoute $ \case
      FrontendRoute_Main -> PathEnd $ unitEncoder mempty
      FrontendRoute_CreateAccount -> PathSegment "create-account" $ singlePathSegmentEncoder . accountRouteEncoder
      FrontendRoute_Token -> PathSegment "token" $ unitEncoder mempty
      FrontendRoute_UserManagement -> PathSegment "user-management" $ unitEncoder mempty
      FrontendRoute_ResetPassword -> PathSegment "reset-password" $ singlePathSegmentEncoder . accountRouteEncoder
      FrontendRoute_Debug -> PathSegment "debug" $ unitEncoder mempty

checkedRouteEncoder
  :: Encoder Identity Identity (R (FullRoute BackendRoute FrontendRoute)) PageName
checkedRouteEncoder = case checkEncoder backendRouteEncoder of
  Right good -> good
  Left e -> error $ T.unpack e

concat <$> mapM deriveRouteComponent
  [ ''BackendRoute
  , ''FrontendRoute
  ]
