{-# OPTIONS_GHC -Wall -Werror #-}
{-# OPTIONS_GHC -fno-warn-orphans #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DeriveTraversable #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedLists #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE TemplateHaskell #-}
module Tezos.Wrapped.Schema where

import Control.Lens.TH
import Data.Aeson (FromJSON, ToJSON)
import qualified Data.ByteString as BS
import Data.Either
import Data.Either.Combinators (mapLeft)
import Data.Foldable (toList)
import Data.Sequence
import GHC.Generics

import Tezos.BabylonShim
import Tezos.Common.Base16ByteString
import Tezos.Common.Binary
import Tezos.Common.Json
import Tezos.Token.Schema
import Tezos.V005.Contract (ContractId)
import Tezos.V005.Micheline (Expression (..))
import Tezos.V005.Michelson as Mc
import Tezos.V005.Operation
import Tezos.V005.PublicKey
import Tezos.V005.PublicKeyHash
import Tezos.V005.Signature

data WrappedCall
  = WrappedCall
    { _wrappedCall_wrapper :: ContractId
    , _wrappedCall_counter :: Int
    , _wrappedCall_payload :: WrappedPayload }
  deriving (Eq, Ord, Show, Generic)

data WrappedPayload
  = WrappedPayload_Call
    { _wrappedPayload_target :: ContractId
    , _wrappedPayload_targetParameter :: TokenOperation
    , _wrappedPayload_flatParameter :: Expression }
  | WrappedPayload_Reconfig
    { _wrappedPayload_threshold :: Int
    , _wrappedPayload_pubkeys :: [(PublicKey, PublicKeyHash)] }
  deriving (Eq, Ord, Show, Generic)

viewTokenOperation :: WrappedPayload -> Maybe TokenOperation
viewTokenOperation = \case
  WrappedPayload_Call _ tokenOperation _ -> Just tokenOperation
  WrappedPayload_Reconfig _ _ -> Nothing

instance ToJSON WrappedPayload
instance FromJSON WrappedPayload

instance ToJSON WrappedCall
instance FromJSON WrappedCall

instance ToMicheline WrappedCall where
  toMicheline (WrappedCall _ counter payload)
    = Pair (Expression_Int (fromIntegral counter)) $ toMicheline payload

instance ToMicheline WrappedPayload where
  toMicheline (WrappedPayload_Call target _ flatParam)
    = Mc.Left $ Pair flatParam (toMicheline target)
  toMicheline (WrappedPayload_Reconfig threshold keys)
    = Mc.Right $
        Pair (Expression_Int $ fromIntegral threshold) $ Expression_Seq $ AsBytes . fst <$> fromList keys

data WrappedCallWithSignatures = WrappedCallWithSignatures
  { _wrappedCallWithSignatures_call :: WrappedCall
  , _wrappedCallWithSignatures_sigs :: [Maybe Signature]
  }

instance ToMicheline WrappedCallWithSignatures where
  toMicheline (WrappedCallWithSignatures call sigs) = Pair (toMicheline call) $ Expression_Seq $
    maybe (Prim0 "None") (Prim1 "Some" . Expression_String . toSignatureText) <$> fromList sigs

instance IsEndpointCall WrappedCallWithSignatures where
  getEndpoint _ = "mainParameter"
  getEndpointType _ =
    (Prim2 "pair" -- main entrypoint (default exists too)
      (Prim2 "pair" -- Payload
        (Prim0 "nat")
        (Prim2 "or"
          (Prim2 "lambda" (Prim0 "unit") (Prim1 "list" $ Prim0 "operation"))
          (Prim2 "pair" (Prim0 "nat") (Prim1 "list" $ Prim0 "key"))))
      (Prim1 "list" $ Prim1 "option" $ Prim0 "signature")) -- Signatures

wrappedCallBytesToSign :: WrappedCall -> BS.ByteString
wrappedCallBytesToSign msCall = encode $ Pair (toMicheline $ _wrappedCall_wrapper msCall) (toMicheline msCall)

{-
instance FromMicheline a => FromMicheline (MultisigCall a) where
  fromMicheline (Pair (Expression_Int counter) $ Expression_Seq (fromList
        [ Prim0 "DROP"
        , Prim1 "NIL" (Prim0 "operation")
        , Prim2 "PUSH" (Prim0 "address") (Expression_String target)
        , Prim1 "CONTRACT" targetPT
        , Prim2
            "IF_NONE"
            (Expression_Seq (fromList [Prim0 "UNIT", Prim0 "FAILWITH"]))
            (Expression_Seq (fromList
              [ Prim2 "PUSH" (Prim0 "mutez") (Expression_Int 0)
              , Prim2 "PUSH" targetPT targetParam
              , Prim0 "TRANSFER_TOKENS"
              , Prim0 "CONS"]))])) = Right $ MultisigCall target targetPT targetParam counter
  fromMicheline _ -> Left "Error: Not a recognized multisig argument"
-}

instance FromMicheline PublicKey where
  fromMicheline (Expression_Bytes (Base16ByteString byteString)) =
    mapLeft show $ decodeEither byteString
  fromMicheline _ =
    Data.Either.Left "Error decoding PublicKey: invalid expression type"

fromOpParameters :: OpParameters -> Maybe (Int, [PublicKey])
fromOpParameters (OpParameters annotation expression) =
  case annotation of
    EntrypointOther (EntrypointName "mainParameter") ->
      case expression of
        Pair (Pair _ (Mc.Right (Pair (Expression_Int rawThreshold) (Expression_Seq rawAddresses)))) _ ->
          let threshold = fromIntegral (unTezosWord64 rawThreshold)
              addresses = rights (toList (fmap fromMicheline rawAddresses))
          in Just (threshold, addresses)
        _ ->
          Nothing
    _ ->
      Nothing

makeLenses 'WrappedCall
