{-# OPTIONS_GHC -Wall -Werror #-}
{-# OPTIONS_GHC -fno-warn-orphans #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DeriveTraversable #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedLists #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE TemplateHaskell #-}
module Tezos.Multisig.Schema where

import Control.Lens.TH
import Data.Aeson (FromJSON, ToJSON)
import qualified Data.ByteString as BS
import Data.Either
import Data.Either.Combinators (mapLeft)
import Data.Foldable (toList)
import Data.Sequence
import GHC.Generics

import Tezos.BabylonShim
import Tezos.Common.Base16ByteString
import Tezos.Common.Binary
import Tezos.Common.Json
import Tezos.Token.Schema
import Tezos.V005.Contract (ContractId)
import Tezos.V005.Micheline (Expression (..))
import Tezos.V005.Michelson
import Tezos.V005.Operation
import Tezos.V005.PublicKey
import Tezos.V005.PublicKeyHash
import Tezos.V005.Signature

data MultisigCall
  = MultisigCall
    { _multisigCall_multisig :: ContractId
    , _multisigCall_counter :: Int
    , _multisigCall_payload :: MultisigPayload }
  deriving (Eq, Ord, Show, Generic)

data MultisigPayload
  = MultisigPayload_Call
    { _multisigPayload_target :: ContractId
    , _multisigPayload_targetParameter :: TokenOperation }
  | MultisigPayload_Reconfig
    { _multisigPayload_threshold :: Int
    , _multisigPayload_pubkeys :: [(PublicKey, PublicKeyHash)] }
  deriving (Eq, Ord, Show, Generic)

viewTokenOperation :: MultisigPayload -> Maybe TokenOperation
viewTokenOperation = \case
  MultisigPayload_Call _ tokenOperation -> Just tokenOperation
  MultisigPayload_Reconfig _ _ -> Nothing

instance ToJSON MultisigPayload
instance FromJSON MultisigPayload

instance ToJSON MultisigCall
instance FromJSON MultisigCall

instance ToMicheline MultisigCall where
  toMicheline (MultisigCall _ counter (MultisigPayload_Call target targetParam))
    = Pair (Expression_Int (fromIntegral counter)) $ Tezos.V005.Michelson.Left $ Expression_Seq (fromList
        [ Prim0 "DROP"
        , Prim1 "NIL" (Prim0 "operation")
        , Prim2 "PUSH" (Prim0 "address") (toMicheline target)
        , getContractExpression targetParam
        , Prim2
            "IF_NONE"
            (Expression_Seq (fromList [Prim0 "UNIT", Prim0 "FAILWITH"]))
            (Expression_Seq (fromList
              [ Prim2 "PUSH" (Prim0 "mutez") (Expression_Int 0)
              , Prim2 "PUSH" (getEndpointType targetParam) $ toMicheline targetParam
              , Prim0 "TRANSFER_TOKENS"
              , Prim0 "CONS"]))])
  toMicheline (MultisigCall _ counter (MultisigPayload_Reconfig threshold keys))
    = Pair (Expression_Int (fromIntegral counter)) $ Tezos.V005.Michelson.Right $
        Pair (Expression_Int $ fromIntegral threshold) $ Expression_Seq $ AsBytes . fst <$> fromList keys

data MultisigCallWithSignatures = MultisigCallWithSignatures
  { _multisigCallWithSignatures_call :: MultisigCall
  , _multisigCallWithSignatures_sigs :: [Maybe Signature]
  }

instance ToMicheline MultisigCallWithSignatures where
  toMicheline (MultisigCallWithSignatures call sigs) = Pair (toMicheline call) $ Expression_Seq $
    maybe (Prim0 "None") (Prim1 "Some" . Expression_String . toSignatureText) <$> fromList sigs

instance IsEndpointCall MultisigCallWithSignatures where
  getEndpoint _ = "main"
  getEndpointType _ =
    (Prim2 "pair" -- main entrypoint (default exists too)
      (Prim2 "pair" -- Payload
        (Prim0 "nat")
        (Prim2 "or"
          (Prim2 "lambda" (Prim0 "unit") (Prim1 "list" $ Prim0 "operation"))
          (Prim2 "pair" (Prim0 "nat") (Prim1 "list" $ Prim0 "key"))))
      (Prim1 "list" $ Prim1 "option" $ Prim0 "signature")) -- Signatures

multisigCallBytesToSign :: MultisigCall -> BS.ByteString
multisigCallBytesToSign msCall = encode $ Pair (toMicheline $ _multisigCall_multisig msCall) (toMicheline msCall)

{-
instance FromMicheline a => FromMicheline (MultisigCall a) where
  fromMicheline (Pair (Expression_Int counter) $ Expression_Seq (fromList
        [ Prim0 "DROP"
        , Prim1 "NIL" (Prim0 "operation")
        , Prim2 "PUSH" (Prim0 "address") (Expression_String target)
        , Prim1 "CONTRACT" targetPT
        , Prim2
            "IF_NONE"
            (Expression_Seq (fromList [Prim0 "UNIT", Prim0 "FAILWITH"]))
            (Expression_Seq (fromList
              [ Prim2 "PUSH" (Prim0 "mutez") (Expression_Int 0)
              , Prim2 "PUSH" targetPT targetParam
              , Prim0 "TRANSFER_TOKENS"
              , Prim0 "CONS"]))])) = Right $ MultisigCall target targetPT targetParam counter
  fromMicheline _ -> Left "Error: Not a recognized multisig argument"
-}

instance FromMicheline PublicKey where
  fromMicheline (Expression_Bytes (Base16ByteString byteString)) =
    mapLeft show $ decodeEither byteString
  fromMicheline _ =
    Data.Either.Left "Error decoding PublicKey: invalid expression type"

fromOpParameters :: OpParameters -> Maybe (Int, [PublicKey])
fromOpParameters (OpParameters annotation expression) =
  case annotation of
    EntrypointOther (EntrypointName "main") ->
      case expression of
        Prim2 "Pair" (Prim2 "Pair"_ (Prim1 "Right" (Prim2 "Pair" (Expression_Int rawThreshold) (Expression_Seq rawAddresses)))) _ ->
          let threshold = fromIntegral (unTezosWord64 rawThreshold)
              addresses = rights (toList (fmap fromMicheline rawAddresses))
          in Just (threshold, addresses)
        _ ->
          Nothing
    _ ->
      Nothing

makeLenses 'MultisigCall
