{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE OverloadedStrings #-}
{-# OPTIONS_GHC -fno-warn-orphans #-}
module Tezos.Token.Schema where

import Data.Aeson
import Data.Either.Combinators
import Data.Foldable (toList)
import qualified Data.Sequence as Seq
import GHC.Generics
import Tezos.BabylonShim
import Tezos.Common.Base16ByteString
import Tezos.Common.Binary
import Tezos.V005.Contract
import Tezos.V005.Micheline
import Tezos.V005.Michelson hiding (Left, Right)
import Tezos.V005.Operation
import Tezos.Common.Json

data TokenOperation
  = SetPause Bool
  | Mint Int ContractId
  | Transfer Int ContractId ContractId
  | AddToWhitelist ContractId
  | AddToWhitelistBatch [ContractId]
  | RemoveFromWhitelist ContractId
  | RemoveFromWhitelistBatch [ContractId]
  | Burn Int ContractId
  | Disburse [ContractId]
 deriving (Eq, Ord, Show, Generic)

instance ToJSON TokenOperation
instance FromJSON TokenOperation

instance IsEndpointCall TokenOperation where
  getEndpoint = \case
    SetPause _ -> "setPause"
    Mint _ _ -> "mint"
    Transfer _ _ _ -> "transfer"
    AddToWhitelist _ -> "addToWhitelist"
    AddToWhitelistBatch _ -> "addToWhitelistBatch"
    RemoveFromWhitelist _ -> "removeFromWhitelist"
    RemoveFromWhitelistBatch _ -> "removeFromWhitelistBatch"
    Burn _ _ -> "burn"
    Disburse _ -> "disburse"
  getEndpointType = \case
    SetPause _ -> Prim0 "bool"
    Mint _ _ -> Prim2 "pair" (Prim0 "address") (Prim0 "nat")
    Transfer _ _ _ -> Prim2 "pair" (Prim0 "address") (Prim2 "pair" (Prim0 "address") (Prim0 "nat"))
    AddToWhitelist _ -> Prim0 "address"
    AddToWhitelistBatch _ -> Prim1 "list" $ Prim0 "address"
    RemoveFromWhitelist _ -> Prim0 "address"
    RemoveFromWhitelistBatch _ -> Prim1 "list" $ Prim0 "address"
    Burn _ _ -> Prim2 "pair" (Prim0 "address") (Prim0 "nat")
    Disburse _ -> Prim1 "list" $ Prim0 "address"

instance ToMicheline TokenOperation where
  toMicheline (SetPause paused) = case paused of
    True -> Prim0 "True"
    False -> Prim0 "False"
  toMicheline (Mint amount address) =
    Pair (AsBytes address) (Int amount)
  toMicheline (Transfer amount fromAddr toAddr) =
    Pair (AsBytes fromAddr) (Pair (AsBytes toAddr) (Int amount))
  toMicheline (AddToWhitelist address) =
    toMicheline address
  toMicheline (AddToWhitelistBatch addresses) =
    Expression_Seq $ Seq.fromList $ toMicheline <$> addresses
  toMicheline (RemoveFromWhitelist address) =
    toMicheline address
  toMicheline (RemoveFromWhitelistBatch addresses) =
    Expression_Seq $ Seq.fromList $ toMicheline <$> addresses
  toMicheline (Burn amount address) =
    Pair (toMicheline address) (Int amount)
  toMicheline (Disburse addresses) =
    Expression_Seq $ Seq.fromList $ toMicheline <$> addresses

instance FromMicheline Bool where
  fromMicheline (Expression_String a) = case a of
    "True" -> Right True
    "False" -> Right False
    _ -> Left "Unrecognized type when decoding Micheline Bool"
  fromMicheline (Expression_Bytes (Base16ByteString a)) = decodeEither a
  fromMicheline (Expression_Prim (MichelinePrimAp (MichelinePrimitive prim) _ _ )) = case prim of
    "True" -> Right True
    "False" -> Right False
    _ -> Left $ "Unrecognized type when decoding MichelinePrimitive Bool"
  fromMicheline _= Left $ "Unrecognized type when decoding Micheline Bool"

instance FromMicheline Int where
  fromMicheline (Expression_Int i) = Right $ fromInteger @Int $ toInteger i
  fromMicheline _ = Left $ "Unrecognized type when decoding Micheline Int"

instance FromMicheline TezosWord64 where
  fromMicheline (Expression_Int i) = Right $ fromIntegral i
  fromMicheline _ = Left $ "Unrecognized type when decoding Micheline Int"

fromOpParameters :: OpParameters -> Maybe TokenOperation
fromOpParameters (OpParameters annotation expression) =
  case annotation of
    EntrypointOther (EntrypointName "setPause") ->
      rightToMaybe $ SetPause <$> fromMicheline expression
    EntrypointOther (EntrypointName "mint") ->
      case expression of
        Pair (AsBytes address) (Int amount) ->
          Just $ Mint amount address
        _ ->
          Nothing
    EntrypointOther (EntrypointName "transfer") ->
      case expression of
        Pair (AsBytes fromAddress) (Pair (AsBytes toAddress) (Int amount)) ->
          Just $ Transfer amount fromAddress toAddress
        _ ->
          Nothing
    EntrypointOther (EntrypointName "addToWhitelist") ->
      rightToMaybe $ AddToWhitelist <$> fromMicheline expression
    EntrypointOther (EntrypointName "addToWhitelistBatch") ->
      case expression of
        Expression_Seq addresses ->
          rightToMaybe $ fmap AddToWhitelistBatch $ traverse fromMicheline (toList addresses)
        _ ->
          Nothing
    EntrypointOther (EntrypointName "removeFromWhitelist") ->
      rightToMaybe $ RemoveFromWhitelist <$> fromMicheline expression
    EntrypointOther (EntrypointName "removeFromWhitelistBatch") ->
      case expression of
        Expression_Seq addresses ->
          rightToMaybe $ fmap RemoveFromWhitelistBatch $ traverse fromMicheline (toList addresses)
        _ ->
          Nothing
    EntrypointOther (EntrypointName "burn") ->
      case expression of
        Pair (AsBytes address) (Int amount) ->
          Just $ Burn amount address
        _ ->
          Nothing
    _ ->
      Nothing

getOperationLimit :: TokenOperation -> Int
getOperationLimit = \case 
  Disburse _ -> 
    20
  _ -> 
    1
