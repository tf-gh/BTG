{-# LANGUAGE DataKinds #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}

module Tezos.ExtraLenses where

import Control.Lens hiding ((.=))
import Data.Dependent.Sum (DSum (..))
import Tezos.V005.Operation

-- Not quite sure how to convince lens's TH to generate these for OpContents.
_OpContents_Transaction
  :: Iso' (OpContents ('OpKind_Manager '[ 'OpKindManager_Transaction ])) (OpContentsManager OpContentsTransaction)
_OpContents_Transaction = flip iso OpContents_Transaction $
  \(OpContents_Transaction a) -> a

onlyTransactions
  :: Prism'
       (DSum OpsKindTag Op)
       (Op ('OpKind_Manager '[ 'OpKindManager_Transaction]))
onlyTransactions = prism (OpSingleTransactionTag :=>) $ \case
  (OpSingleTransactionTag :=> theOp) -> Right theOp
  a -> Left a

-- Didn't manage to figure out if this is signature can be simpler.
pattern OpSingleTransactionTag
  :: forall (opKinds :: OpKind).  ()
  => forall (opKindManager :: OpKindManager).
       (opKinds ~ 'OpKind_Manager '[opKindManager],
          opKindManager ~ 'OpKindManager_Transaction)
  => OpsKindTag opKinds
pattern OpSingleTransactionTag
  = (OpsKindTag_Single (OpKindTag_Manager OpKindManagerTag_Transaction))

