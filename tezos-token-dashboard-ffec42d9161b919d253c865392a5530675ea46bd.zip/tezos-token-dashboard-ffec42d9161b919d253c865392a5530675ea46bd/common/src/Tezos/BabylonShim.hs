{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}

module Tezos.BabylonShim where

import Prelude hiding (pattern Left, pattern Right)

import Data.Aeson (FromJSON, ToJSON)
import qualified Data.Text as T
import GHC.Generics (Generic)
import Tezos.V005.Contract (ContractScript)
import Tezos.V005.Micheline
import Tezos.V005.Michelson

class ToMicheline a => IsEndpointCall a where
  getEndpoint :: a -> T.Text
  getEndpointType :: a -> Expression

getContractExpression :: IsEndpointCall a => a -> Expression
getContractExpression call = 
  Expression_Prim $ MichelinePrimAp 
    (MichelinePrimitive "CONTRACT")
    (pure $ getEndpointType call)
    (pure $ Annotation_Field $ getEndpoint call)

data ResolvedEndpointCall a = ResolvedEndpointCall
  { _resolvedEndpointCall_contractScript :: ContractScript
  , _resolvedEndpointCall_endpointCall :: a }
  deriving (Show, Eq, Ord, Generic)

instance IsEndpointCall a => ToMicheline (ResolvedEndpointCall a) where
  toMicheline (ResolvedEndpointCall script parameter) =
    case wrapEndpointCall (getEndpoint parameter) script $ toMicheline parameter of
      Just result -> result
      Nothing -> error "Improperly constructed ResolvedEndpointCall; use resolveEndpointCall instead of the constructor"

resolveEndpointCall :: IsEndpointCall a => a -> ContractScript -> Maybe (ResolvedEndpointCall a)
resolveEndpointCall parameter script
  = ResolvedEndpointCall script parameter <$ wrapEndpointCall (getEndpoint parameter) script (toMicheline parameter)

inlineResolveEndpointCall :: IsEndpointCall a => a -> Expression -> Maybe Expression
inlineResolveEndpointCall a contractType =
  findInOrTree (getEndpoint a) contractType <*> pure (toMicheline a)

instance FromJSON a => FromJSON (ResolvedEndpointCall a)
instance ToJSON a => ToJSON (ResolvedEndpointCall a)